"""List all channels the bot has access to — helps find notification channel IDs.

Usage:
    python list_channels.py
"""
import asyncio
import os

import discord
from dotenv import load_dotenv


async def main():
    load_dotenv()
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        print("ERROR: DISCORD_TOKEN not found in .env")
        return

    intents = discord.Intents.default()
    intents.guilds = True
    intents.messages = True
    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(f"\nLogged in as: {client.user}")
        print(f"Serving {len(client.guilds)} guild(s):\n")
        for guild in client.guilds:
            print(f"  Guild: {guild.name} (ID: {guild.id})")
            text_channels = [c for c in guild.text_channels]
            for ch in text_channels:
                print(f"    • #{ch.name} (ID: {ch.id})")
            print()
        await client.close()

    await client.start(token)


if __name__ == "__main__":
    asyncio.run(main())
