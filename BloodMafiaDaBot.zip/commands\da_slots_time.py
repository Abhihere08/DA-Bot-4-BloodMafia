from __future__ import annotations

from datetime import UTC, datetime, timedelta

from discord import Interaction, app_commands

from config import DA_SLOTS
from utils.slot_utils import _parse_date_string


def _format_slot_times(date_str: str | None = None) -> str:
    """Build a message showing all 8 DA slots in Discord auto-local timestamps.

    Uses Discord's ``<t:TIMESTAMP:t>`` / ``<t:TIMESTAMP:T>`` syntax so times
    render in each viewer's browser local timezone automatically.
    """
    if date_str:
        base = _parse_date_string(date_str)
    else:
        base = datetime.now(UTC)

    if base is None or base.tzinfo is None:
        base = datetime.now(UTC)
    if base.tzinfo is None:
        base = base.replace(tzinfo=UTC)

    lines = ["**⏰ DA Slot Times (all times auto-local)**", ""]

    for slot_num in sorted(DA_SLOTS):
        start_str, end_str = DA_SLOTS[slot_num]
        sh, sm = map(int, start_str.split(":"))
        eh, em = map(int, end_str.split(":"))

        start_dt = base.replace(hour=sh, minute=sm, second=0, microsecond=0)
        end_dt = base.replace(hour=eh, minute=em, second=0, microsecond=0)

        if sh > eh or (sh == eh and sm > em):
            end_dt += timedelta(days=1)

        start_ts = int(start_dt.timestamp())
        end_ts = int(end_dt.timestamp())

        lines.append(
            f"Slot {slot_num}:  <t:{start_ts}:t> – <t:{end_ts}:t>"
        )

    lines.append("")
    lines.append("*Times shown in your local timezone automatically.*")

    return "\n".join(lines)


@app_commands.command(
    name="da-slot-times",
    description="Show all 8 DA slot times in local time for each viewer",
)
@app_commands.describe(
    date="Date for which to show slots (e.g. 10.02.26). Defaults to today."
)
async def command(interaction: Interaction, date: str | None = None):
    """Post all DA slot times using Discord auto-local timestamps."""
    try:
        msg = _format_slot_times(date)
        await interaction.response.send_message(content=msg[:2000])
    except Exception as err:
        await interaction.response.send_message(
            f"❌ Error: {err}", ephemeral=True
        )
