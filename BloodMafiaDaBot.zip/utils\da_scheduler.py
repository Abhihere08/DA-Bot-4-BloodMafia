"""Automatic DA announcement scheduler.

Polls the spreadsheet every 30 seconds for new sheet tabs (by date).
When a new upcoming DA sheet is detected, schedules an announcement
to be posted 30 minutes before the slot starts in the notification channel.
"""
import asyncio
import json
import os
from datetime import UTC, datetime, timedelta, timezone

from config import ALL_NOTIFICATION_CHANNELS, DA_SHEET_PATTERNS
from sheets import get_range, get_sheet_names
from utils.logger import logger

# Fixed PST (UTC-8) — the game schedule uses PST year-round (no DST).
# 22:00 PST (Slot 1) = 06:00 UTC, and slots are 3h apart in PST.
PST = timezone(timedelta(hours=-8))

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_ANNOUNCED_FILE = os.path.join(_PROJECT_ROOT, "da_announced.json")

_POLL_INTERVAL_SECONDS = 60
_HOURS_BEFORE_SLOT = 0.5  # Reminder fires 30 min before slot start

_announced: set[str] = set()
_pending_tasks: list = []
_bot = None


def _load_announced() -> None:
    global _announced
    try:
        with open(_ANNOUNCED_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
            _announced = set(data.get("announced_sheets", []))
    except (FileNotFoundError, json.JSONDecodeError):
        _announced = set()


def _save_announced() -> None:
    try:
        with open(_ANNOUNCED_FILE, "w", encoding="utf-8") as fh:
            json.dump({"announced_sheets": list(_announced)}, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save announced sheets: %s", err)


def _get_slot_start_datetime(slot_num: int, date_str: str | None) -> datetime | None:
    """Calculate the UTC datetime when a slot starts.

    Sheet dates are in PST and represent the **registration end date** (9 PM PST).
    Slot 1 starts at 10 PM PST on that date (1 hour after registration ends),
    and subsequent slots are 3 hours apart.

    We compute the PST datetime directly from the slot number and convert to UTC
    for comparison against ``datetime.now(UTC)``.
    """
    from utils.slot_utils import _parse_date_string

    if date_str:
        dt = _parse_date_string(date_str)
        if dt is None:
            dt = datetime.now(UTC)
    else:
        dt = datetime.now(UTC)

    # Build PST datetime for Slot 1: 22:00 PST on the sheet date
    sheet_date = dt.replace(hour=22, minute=0, second=0, microsecond=0, tzinfo=PST)

    # Slot 1 is at 22:00 PST, Slot 2 at 01:00 PST (next day), etc.
    slot_start_pst = sheet_date + timedelta(hours=(slot_num - 1) * 3)

    # Convert to UTC for comparison
    return slot_start_pst.astimezone(UTC)


async def _send_new_da_announcement(sheet_tab: str) -> None:
    """Send the new-DA registration announcement to all notification channels."""
    from commands.new_da import _build_da_message
    from utils.slot_utils import parse_slot_date, parse_slot_number

    if not _bot:
        return
    if not ALL_NOTIFICATION_CHANNELS:
        return

    try:
        rows = await get_range(f"'{sheet_tab}'")
        if not rows:
            return

        from commands.send_da_assignments import parse_da_sheet
        parsed = parse_da_sheet(rows)
        if not parsed:
            return

        title = parsed["title"]
        slot_num = parse_slot_number(title)
        date_str = parse_slot_date(title)

        if not slot_num:
            logger.warning("Cannot detect slot number for new-DA announcement")
            return

        message = _build_da_message(sheet_tab, title, slot_num, date_str)
        msg = message[:2000]

        for channel_id in ALL_NOTIFICATION_CHANNELS:
            channel = _bot.get_channel(channel_id)
            if channel:
                try:
                    await channel.send(content=msg, wait=True)
                    logger.info("New-DA announcement sent to channel %d for sheet '%s'", channel_id, sheet_tab)
                except Exception as err:
                    logger.error("Failed to send new-DA announcement to channel %d: %s", channel_id, err)

    except Exception as err:
        logger.error("Failed to send new-DA announcement: %s", err)


async def _send_da_announcement(sheet_tab: str) -> None:
    """Send the DA announcement to all notification channels (one per guild)."""
    from commands.send_da_assignments import _build_section_text, _split_messages, parse_da_sheet
    from utils.slot_utils import format_slot_time_with_tz, parse_slot_date, parse_slot_number

    if not _bot:
        logger.error("Bot not available for announcement")
        return

    if not ALL_NOTIFICATION_CHANNELS:
        logger.warning("No notification channels configured; skipping DA announcement")
        return

    try:
        rows = await get_range(f"'{sheet_tab}'")
        if not rows:
            return

        parsed = parse_da_sheet(rows)
        if not parsed:
            return

        slot_num = parse_slot_number(parsed["title"])
        slot_date = parse_slot_date(parsed["title"])
        slot_time_str = (
            format_slot_time_with_tz(slot_num, slot_date) if slot_num else "Unknown"
        )

        # Determine guild-specific tag based on sheet type
        from commands.new_da import BIG_BM_TAG, LITTLE_BM_TAG, _detect_sheet_type
        sheet_type = _detect_sheet_type(sheet_tab)
        guild_tag = BIG_BM_TAG if sheet_type == "big" else LITTLE_BM_TAG

        # Build sections structure once (shared across channels)
        sections: list[tuple[str, list]] = []
        if parsed["caravanChasers"]:
            sections.append(("🚛  CARAVAN CHASERS & TRANSPORTER HOLDERS", parsed["caravanChasers"]))
        if parsed["topHalf"]:
            sections.append(("🏔️  TEAM A — TOP HALF OF MAP", parsed["topHalf"]))
        if parsed["bottomHalf"]:
            sections.append(("🌊  TEAM A — BOTTOM HALF OF MAP", parsed["bottomHalf"]))

        for channel_id in ALL_NOTIFICATION_CHANNELS:
            channel = _bot.get_channel(channel_id)
            if not channel:
                logger.warning("Notification channel not found: %d", channel_id)
                continue

            guild = channel.guild

            lines: list[str] = []
            lines.append(f"**⏰ DA REMINDER — {parsed['title']}**")
            lines.append(f"📋 Sheet: `{sheet_tab}` • **{slot_time_str}**")
            lines.append("")
            lines.append(f"{guild_tag} — DA starts in 1 hour! Check your assignments:")
            lines.append("")

            for sec_title, assignments in sections:
                lines.append(_build_section_text(sec_title, assignments, guild))
                lines.append("")

            messages = _split_messages(lines)
            for msg in messages:
                try:
                    await channel.send(content=msg[:2000], wait=True)
                except Exception as err:
                    logger.error("Failed to send DA announcement to channel %d: %s", channel_id, err)

            logger.info("DA announcement sent to channel %d (guild %d) for sheet '%s'",
                        channel_id, guild.id if guild else 0, sheet_tab)

    except Exception as err:
        logger.error("Failed to send DA announcement: %s", err)


async def _schedule_announcement(sheet_tab: str, slot_num: int, date_str: str | None) -> None:
    """Schedule the DA announcement to fire 1 hour before the slot starts."""
    slot_start = _get_slot_start_datetime(slot_num, date_str)
    if not slot_start:
        logger.warning("Could not determine slot start time for %s", sheet_tab)
        return

    announce_time = slot_start - timedelta(hours=_HOURS_BEFORE_SLOT)
    now = datetime.now(UTC)

    delay = (announce_time - now).total_seconds()

    if delay <= 0:
        # Slot is within the reminder window — announce immediately
        logger.info(
            "Sheet '%s' is within %dh of slot; sending DA assignment reminder now",
            sheet_tab, _HOURS_BEFORE_SLOT,
        )
        await _send_da_announcement(sheet_tab)
        _announced.add(sheet_tab)
        _save_announced()
    else:
        # Schedule the announcement
        logger.info(
            "Scheduling DA announcement for '%s' in %d seconds (at %s PST)",
            sheet_tab, delay, announce_time.astimezone(PST).strftime("%Y-%m-%d %H:%M PST"),
        )

        async def _delayed_announce():
            await asyncio.sleep(delay)
            await _send_da_announcement(sheet_tab)
            _announced.add(sheet_tab)
            _save_announced()

        task = asyncio.create_task(_delayed_announce())
        _pending_tasks.append(task)


async def run_scheduler_check() -> dict:
    """Run one full scheduler check cycle. Returns a summary dict.

    Used by both the poll loop and the manual ``/da-check`` command.
    """
    from utils.slot_utils import _is_sheet_upcoming, parse_slot_date, parse_slot_number

    result = {"checked": 0, "announced": [], "scheduled": [], "rescheduled": [], "skipped": [], "error": None}

    try:
        sheet_names = await get_sheet_names()
        da_sheets = []
        for name in sheet_names:
            low = name.lower()
            for pattern in DA_SHEET_PATTERNS:
                if pattern.lower() in low:
                    da_sheets.append(name)
                    break

        result["checked"] = len(da_sheets)

        for sheet_name in da_sheets:
            if not _is_sheet_upcoming(sheet_name):
                logger.info("Skipping past sheet (date filter): %s", sheet_name)
                result["skipped"].append(sheet_name)
                continue

            rows = await get_range(f"'{sheet_name}'")
            if not rows:
                continue

            title_row = rows[0][0] if rows and rows[0] else ""
            slot_num = parse_slot_number(title_row)
            date_str = parse_slot_date(title_row)

            if not slot_num:
                continue

            # Check if this is a future slot
            slot_start = _get_slot_start_datetime(slot_num, date_str)
            if not slot_start:
                continue

            now = datetime.now(UTC)
            if slot_start > now:
                # Upcoming slot
                if sheet_name not in _announced:
                    # New DA — send new-DA announcement + schedule DA reminder
                    await _send_new_da_announcement(sheet_name)
                    await _schedule_announcement(sheet_name, slot_num, date_str)
                    _announced.add(sheet_name)
                    _save_announced()
                    result["announced"].append(sheet_name)
                else:
                    # Already announced but reminder may have been lost on restart —
                    # re-schedule the reminder without re-sending new-DA announcement
                    await _schedule_announcement(sheet_name, slot_num, date_str)
                    result["rescheduled"].append(sheet_name)
            else:
                # Past slot — mark as seen so we don't keep re-fetching it
                if sheet_name not in _announced:
                    _announced.add(sheet_name)
                    _save_announced()
                result["skipped"].append(sheet_name)

    except Exception as err:
        logger.error("DA scheduler check error: %s", err)
        result["error"] = str(err)

    return result


async def _da_poll_loop() -> None:
    """Main polling loop — checks for new sheets every 30 seconds."""

    while True:
        await asyncio.sleep(_POLL_INTERVAL_SECONDS)
        result = await run_scheduler_check()
        if result["announced"]:
            logger.info("Scheduled check found %d new DA sheet(s): %s",
                        len(result["announced"]), result["announced"])
        if result["error"]:
            logger.error("DA scheduler poll error: %s", result["error"])


async def _bootstrap_da_scheduler(bot) -> None:
    """Bootstrap the DA scheduler with the bot instance."""
    global _bot
    _bot = bot
    _load_announced()
    logger.info("DA scheduler started — polling every %ds", _POLL_INTERVAL_SECONDS)
    await _da_poll_loop()


def start_da_scheduler(bot) -> None:
    """Start the DA announcement scheduler as a background task."""
    task = asyncio.create_task(_bootstrap_da_scheduler(bot))
    _pending_tasks.append(task)
    logger.info("DA scheduler initialized (30min pre-slot announcements)")


def stop_da_scheduler() -> None:
    """Cancel all pending DA scheduler tasks."""
    for task in _pending_tasks:
        task.cancel()
    _pending_tasks.clear()
    logger.info("DA scheduler stopped")
