from __future__ import annotations

from discord import Interaction, app_commands

from sheets import append_row
from utils.logger import logger


@app_commands.command(name="write", description="Append a new row of data to the Google Sheet")
@app_commands.describe(
    data='Comma-separated values to write, e.g. "John,25,Online"',
    sheet="Sheet/tab name (default: Sheet1)",
)
async def command(interaction: Interaction, data: str, sheet: str = "Sheet1"):
    await interaction.response.defer()
    values = [v.strip() for v in data.split(",")]
    try:
        await append_row(values, sheet)
        formatted = "\n".join(f"Col {i + 1}: {v}" for i, v in enumerate(values))
        return await interaction.edit_original_response(
            content=f"✅ Successfully wrote to `{sheet}`:\n{formatted}"
        )
    except Exception as err:
        logger.error("Error in /write: %s", err)
        return await interaction.edit_original_response(
            content=f"❌ Error writing to sheet: {err}"
        )
