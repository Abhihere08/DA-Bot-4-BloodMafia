"""Fetch Google Sheet data via public CSV export (no authentication required).

The spreadsheet must be shared with "Anyone with the link can view" so that
Google's public CSV export endpoint returns the data.  Tab (sheet) names are
extracted from the HTML view page, and each tab can be fetched as CSV by its
GID (grid id).
"""
import asyncio
import csv
import re
import time
from urllib.request import urlopen

from config import DA_SHEET_PATTERNS, GOOGLE_SHEET_ID
from utils.logger import logger


def _spreadsheet_url() -> str:
    return f"https://docs.google.com/spreadsheets/d/{GOOGLE_SHEET_ID}"


async def _run(func, *args, **kwargs):
    return await asyncio.to_thread(func, *args, **kwargs)


# ---------------------------------------------------------------------------
# Lightweight cache for the HTML view page — Google takes ~3-4s to respond and
# Discord's autocomplete has a hard 3s timeout.  Caching for 25 s stays fresh
# enough for the 30 s scheduler poll while keeping autocomplete responsive.
# ---------------------------------------------------------------------------
_CACHE_TTL_SECONDS = 25
_html_cache: tuple[float, str] | None = None


def _fetch_html() -> str:
    """Fetch the spreadsheet's HTML view page (cached for 25 s)."""
    global _html_cache

    now = time.monotonic()
    if _html_cache is not None and (now - _html_cache[0]) < _CACHE_TTL_SECONDS:
        return _html_cache[1]

    url = _spreadsheet_url()
    with urlopen(url, timeout=30) as resp:
        data = resp.read()
    html = data.decode("utf-8", errors="replace")
    _html_cache = (now, html)
    return html


def _fetch_csv(gid: str) -> list[list[str]]:
    """Fetch a single tab as CSV and return list-of-rows."""
    url = f"{_spreadsheet_url()}/export?format=csv&gid={gid}"
    with urlopen(url, timeout=30) as resp:
        data = resp.read()
    text = data.decode("utf-8-sig", errors="replace")
    reader = csv.reader(text.splitlines())
    return [row for row in reader]


def _parse_tabs_from_html(html: str) -> list[tuple[str, str]]:
    """Extract (sheet_name, gid_string) pairs from the spreadsheet's HTML view page.

    Google embeds sheet metadata inside an escaped JavaScript array.  Each tab
    appears as a segment like::

        ,0,\\"GID\\",[{"1":[[0,0,\\"Sheet Name\\",...

    where ``\\"`` is a literal backslash+quote (the JSON is doubly-escaped inside
    the HTML).  We find each GID occurrence and then search a small window ahead
    for the sheet title.
    """
    results: list[tuple[str, str]] = []

    gid_pattern = re.compile(r',0,\\"(\d+)\\",')
    name_pattern = re.compile(r'\\"1\\":\[\[0,0,\\"([^"\\]+)\\"')

    for g in gid_pattern.finditer(html):
        gid = g.group(1)
        search_area = html[g.end():g.end() + 500]
        name_match = name_pattern.search(search_area)
        if name_match:
            title = name_match.group(1).strip()
            if title and len(title) <= 100:
                results.append((title, gid))
                logger.debug("Found tab: %s (gid=%s)", title, gid)

    if not results:
        logger.warning("Could not extract sheet tabs from HTML")

    return results


async def get_sheet_names() -> list[str]:
    """Return list of all tab names in the spreadsheet (leftmost first)."""

    def _do():
        html = _fetch_html()
        tabs = _parse_tabs_from_html(html)
        return [t[0] for t in tabs]

    return await _run(_do)


async def get_range(range_a1: str):
    """Read a range given in A1 notation. Returns list of rows (list[list[str]]).

    .. deprecated::
       Only the sheet name portion is used; the A1 range is not yet supported
       via CSV export.  Pass a full sheet name (e.g. ``"DA 101"``).
    """
    sheet_name = range_a1.strip("'\"")
    return await get_rows(sheet_name)


async def get_rows(sheet_name: str = "Sheet1") -> list[list[str]]:
    """Get all rows (including header) from a tab by name."""

    def _do():
        html = _fetch_html()
        tabs = _parse_tabs_from_html(html)
        for title, gid in tabs:
            if title.strip().lower() == sheet_name.strip().lower():
                logger.info("Fetching tab '%s' (gid=%s)", title, gid)
                return _fetch_csv(gid)
        # Try the first tab as fallback
        if tabs:
            title, gid = tabs[0]
            logger.warning("Tab '%s' not found; falling back to '%s'", sheet_name, title)
            return _fetch_csv(gid)
        logger.error("No tabs found in spreadsheet")
        return []

    return await _run(_do)


async def get_row(row_num: int, sheet_name: str = "Sheet1"):
    """Get a single 1-based row from a tab."""
    rows = await get_rows(sheet_name)
    return rows[row_num - 1] if 1 <= row_num <= len(rows) else None


async def append_row(values, sheet_name: str = "Sheet1"):
    """Append a row to the end of a tab (via Google Forms redirect not possible here).

    .. note::
       Public CSV export is read-only.  Write operations require authentication.
    """
    logger.error("append_row not available with public CSV export (read-only)")
    raise NotImplementedError(
        "Write operations require Google API authentication, which is not configured."
    )


async def update_cell(cell: str, value: str):
    """Update a single cell via A1 notation.

    .. note::
       Public CSV export is read-only.  Write operations require authentication.
    """
    logger.error("update_cell not available with public CSV export (read-only)")
    raise NotImplementedError(
        "Write operations require Google API authentication, which is not configured."
    )


async def get_row_count(sheet_name: str = "Sheet1"):
    """Return number of populated rows in a tab."""
    rows = await get_rows(sheet_name)
    return len(rows)


async def test_connection():
    """Test the Sheets connection by fetching metadata."""
    try:
        html = await _run(_fetch_html)
        tabs = _parse_tabs_from_html(html)
        return {
            "ok": True,
            "title": _spreadsheet_url(),
            "tabs": [t[0] for t in tabs],
            "error": None,
        }
    except Exception as err:
        return {"ok": False, "title": None, "tabs": [], "error": str(err)}


def get_relevant_da_sheets(sheet_names: list[str]) -> list[str]:
    """Return only the relevant, latest DA sheets for both Big B|M and Little b|M.

    Includes:
    - Any upcoming Big B|M sheets (today or future)
    - Any upcoming Little b|M sheets (today or future)
    - The most recent past Big B|M sheet
    - The most recent past Little b|M sheet
    """
    from datetime import datetime, timezone
    from utils.slot_utils import _parse_date_string, parse_slot_date, _is_sheet_upcoming

    upcoming_big: list[str] = []
    upcoming_little: list[str] = []
    past_big: list[tuple[datetime, str]] = []
    past_little: list[tuple[datetime, str]] = []

    epoch = datetime(1970, 1, 1, tzinfo=timezone.utc)

    for name in sheet_names:
        low = name.lower().strip()
        is_big = "big" in low and ("bm" in low or "b|m" in low or "slot" in low)
        is_little = "little" in low and ("bm" in low or "b|m" in low or "slot" in low)

        if not (is_big or is_little):
            continue

        d_str = parse_slot_date(name)
        dt = _parse_date_string(d_str) if d_str else None

        if d_str and _is_sheet_upcoming(name):
            if is_big:
                upcoming_big.append(name)
            else:
                upcoming_little.append(name)
        else:
            if is_big:
                past_big.append((dt or epoch, name))
            else:
                past_little.append((dt or epoch, name))

    past_big.sort(key=lambda x: x[0], reverse=True)
    past_little.sort(key=lambda x: x[0], reverse=True)

    results: list[str] = []

    # 1. Upcoming sheets
    for n in upcoming_big:
        if n not in results:
            results.append(n)
    for n in upcoming_little:
        if n not in results:
            results.append(n)

    # 2. Latest past sheets for both Big and Little
    if past_big and past_big[0][1] not in results:
        results.append(past_big[0][1])
    if past_little and past_little[0][1] not in results:
        results.append(past_little[0][1])

    return results


async def auto_detect_da_sheet(sheet_names=None):
    """
    Pick the left-most sheet tab that looks like a DA assignment sheet.

    Prioritizes upcoming Big/Little BM sheets, then the latest completed DA sheet.
    """
    if sheet_names is None:
        sheet_names = await get_sheet_names()
    relevant = get_relevant_da_sheets(sheet_names)
    if relevant:
        logger.info("Auto-detected DA sheet tab: %s", relevant[0])
        return relevant[0]
    return None
