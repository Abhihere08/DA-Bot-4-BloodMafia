from discord import Interaction, app_commands

from utils.scheduler import toggle_notifications


@app_commands.command(name="notify", description="Toggle sheet-change notifications on or off")
async def command(interaction: Interaction):
    new_state = toggle_notifications()
    emoji = "🔔" if new_state else "🔕"
    await interaction.response.send_message(
        f"{emoji} Notifications are now **{ 'enabled' if new_state else 'disabled' }**."
    )
