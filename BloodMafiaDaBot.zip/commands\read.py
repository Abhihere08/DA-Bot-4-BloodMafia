from __future__ import annotations

from discord import Interaction, app_commands

from sheets import get_row, get_rows
from utils.logger import logger


@app_commands.command(name="read", description="Read data from the Google Sheet")
@app_commands.describe(
    row="Row number to read (1-based). Omit to see all rows.",
    sheet="Sheet/tab name (default: Sheet1)",
)
async def command(
    interaction: Interaction,
    row: int | None = None,
    sheet: str = "Sheet1",
):
    await interaction.response.defer()
    try:
        if row is not None:
            row_data = await get_row(row, sheet)
            if not row_data:
                return await interaction.edit_original_response(
                    content=f"Row **{row}** is empty or does not exist."
                )
            formatted = "\n".join(
                f"Col {i + 1}: {cell}" for i, cell in enumerate(row_data)
            )
            return await interaction.edit_original_response(
                content=f"📄 **Row {row}** from `{sheet}`:\n{formatted}"
            )

        rows = await get_rows(sheet)
        if not rows:
            return await interaction.edit_original_response(
                content=f"⚠️ Sheet `{sheet}` is empty."
            )

        display = rows[:15]
        lines = "\n".join(f"**{i + 1}.** {' | '.join(r)}" for i, r in enumerate(display))
        msg = (
            f"📊 **{sheet}** ({len(rows)} rows total, showing first "
            f"{len(display)}):\n\n{lines}"
        )
        return await interaction.edit_original_response(content=msg)
    except Exception as err:
        logger.error("Error in /read: %s", err)
        return await interaction.edit_original_response(
            content=f"❌ Error reading sheet: {err}"
        )
