@echo off
setlocal enabledelayedexpansion

REM Set working directory to this script's location
cd /d "%~dp0"

echo ========================================
echo  Discord Sheets Bot - PM2 Setup
echo ========================================
echo.
echo This script will:
echo  1. Check Node.js (required for PM2)
echo  2. Check Python (required to run the bot)
echo  3. Collect your Discord and Google credentials
echo  4. Install Python dependencies
echo  5. Deploy slash commands to Discord
echo  6. Start the bot under PM2 (detached, auto-restart)
echo  7. Register auto-start (boot if admin, login always)
echo.

REM --- Step 0: Node.js ---
echo [0/7] Checking Node.js...
where node >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not found! PM2 requires Node.js.
    echo Download it from: https://nodejs.org/ (LTS version)
    pause
    exit /b 1
)
for /f "delims=" %%v in ('node --version') do set "NODE_VER=%%v"
echo    Node.js !NODE_VER!

REM --- Step 1: PM2 ---
echo [1/7] Checking PM2...
where pm2 >nul 2>&1
if errorlevel 1 (
    echo    PM2 not found - installing globally...
    npm install -g pm2
    if errorlevel 1 (
        echo ERROR: Failed to install PM2.
        pause
        exit /b 1
    )
)
for /f "delims=" %%v in ('pm2 --version') do set "PM2_VER=%%v"
echo    PM2 !PM2_VER!
for /f "delims=" %%i in ('where pm2.cmd') do set "PM2_PATH=%%i"
echo.

REM --- Step 2: Python ---
echo [2/7] Checking Python...
set "PYTHON_EXE="
where python >nul 2>&1
if errorlevel 1 (
    where python3 >nul 2>&1
    if errorlevel 1 (
        echo ERROR: Python not found! Install Python 3.11+ from:
        echo   https://www.python.org/downloads/windows/
        echo Make sure to check "Add Python to PATH" during installation.
        pause
        exit /b 1
    ) else (
        set "PYTHON_EXE=python3"
    )
) else (
    set "PYTHON_EXE=python"
)
for /f "delims=" %%v in ('!PYTHON_EXE! --version 2^>^&1') do set "PY_VER=%%v"
echo    !PY_VER!
echo.

REM --- Step 3: Config ---
echo [3/7] Checking configuration...
if not exist ".env" (
    echo    No .env found - running configuration wizard...
    !PYTHON_EXE! setup_config.py
    if errorlevel 1 (
        echo ERROR: Configuration setup failed.
        pause
        exit /b 1
    )
) else (
    echo    .env already exists - skipping wizard.
)
echo.

REM --- Step 4: Dependencies ---
echo [4/7] Installing dependencies...
!PYTHON_EXE! -m pip install --upgrade pip >nul 2>&1
!PYTHON_EXE! -m pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)
echo.

REM --- Step 5: Deploy commands ---
echo [5/7] Deploying slash commands...
!PYTHON_EXE! deploy_commands.py
if errorlevel 1 (
    echo    WARNING: Command deployment reported an error. Continuing anyway...
)
echo.

REM --- Step 6: Start under PM2 ---
echo [6/7] Starting bot under PM2...
if not exist "logs" mkdir "logs"
pm2 delete da-bot >nul 2>&1
pm2 start ecosystem.config.js
if errorlevel 1 (
    echo ERROR: Failed to start bot under PM2.
    pause
    exit /b 1
)
pm2 save
echo    Bot is now running detached - closing this window will NOT stop it.
echo.

REM --- Step 7: Auto-start ---
echo [7/7] Registering auto-start...
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "STARTUP_VBS=!STARTUP_DIR!\da-bot-autostart.vbs"

REM Always register start-at-login (hidden window, restores saved PM2 processes)
(
    echo Set sh = CreateObject("WScript.Shell"^)
    echo sh.Run """!PM2_PATH!"" resurrect", 0, False
) > "!STARTUP_VBS!"

net session >nul 2>&1
if not errorlevel 1 (
    echo    Administrator detected - also registering start-at-boot...
    pm2 startup
    pm2 save
    echo    Auto-start registered: runs at system boot (24/7) and at login.
) else (
    echo    Auto-start registered: runs when you log into Windows.
    echo    TIP: Re-run bootstrap.bat as Administrator to also start at boot (24/7).
)
echo.

echo ========================================
echo  Setup complete!
echo.
echo  Bot status:   pm2 status
echo  Bot logs:     pm2 logs da-bot
echo  Stop bot:     pm2 stop da-bot
echo  Start bot:    pm2 start da-bot
echo  Restart bot:  pm2 restart da-bot
echo.
echo  bootstrap.bat is the only script you need -
echo  it starts the bot and makes it auto-run.
echo ========================================
pause
