@echo off
setlocal enabledelayedexpansion

REM Set working directory to this script's location
cd /d "%~dp0"

echo ========================================
echo  Discord Sheets Bot - Bootstrap Setup
echo ========================================
echo.
echo This script will:
echo  1. Verify Python installation
echo  2. Collect your Discord and Google credentials
echo  3. Install Python dependencies
echo  4. Deploy slash commands to Discord
echo  5. Configure auto-start (runs 24/7 at boot)
echo  6. Start the bot now
echo.

REM --- Step 0: Verify Python ---
echo [0/6] Checking Python installation...

set "PYTHON_EXE="
where python >nul 2>&1
if errorlevel 1 (
    where python3 >nul 2>&1
    if errorlevel 1 (
        echo ERROR: Python not found! Please install Python 3.11+ from:
        echo   https://www.python.org/downloads/windows/
        echo Make sure to check "Add Python to PATH" during installation.
        echo.
        pause
        exit /b 1
    ) else (
        set "PYTHON_EXE=python3"
    )
) else (
    set "PYTHON_EXE=python"
)

for /f "delims=" %%v in ('!PYTHON_EXE! --version 2^>^&1') do set "PY_VER=%%v"
echo    !PY_VER!
echo.

REM --- Step 1: Collect configuration ---
echo [1/6] Collecting credentials...
!PYTHON_EXE! setup_config.py
if errorlevel 1 (
    echo.
    echo ERROR: Configuration setup failed.
    pause
    exit /b 1
)
echo.

REM --- Step 2: Install dependencies ---
echo [2/6] Installing dependencies...
!PYTHON_EXE! -m pip install --upgrade pip 2>nul
!PYTHON_EXE! -m pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)
echo.

REM --- Step 3: Deploy slash commands ---
echo [3/6] Deploying slash commands...
!PYTHON_EXE! deploy_commands.py
if errorlevel 1 (
    echo WARNING: Command deployment reported an error. Continuing anyway...
)
echo.

REM --- Step 4: Create run_bot.bat ---
echo [4/6] Configuring bot runner...
set "BOT_DIR=%~dp0"
for /f "delims=" %%i in ('!PYTHON_EXE! -c "import sys; print(sys.executable)"') do set "PYTHON_PATH=%%i"

REM Write run_bot.bat safely using a parenthesized block to avoid special-char issues
(
    echo @echo off
    echo cd /d "!BOT_DIR!"
    echo start "DiscordSheetsBot" /min "!PYTHON_PATH!" "!BOT_DIR!main.py"
) > "!BOT_DIR!run_bot.bat"
echo    run_bot.bat created at: !BOT_DIR!run_bot.bat
echo.

REM --- Step 5: Register auto-start ---
echo [5/6] Registering auto-start task...
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "STARTUP_FILE=!STARTUP_DIR!\DiscordSheetsBot.bat"

REM Check if running as Administrator
net session >nul 2>&1
set "IS_ADMIN=0"
if not errorlevel 1 (
    set "IS_ADMIN=1"
)

if "!IS_ADMIN!"=="1" (
    echo    Administrator detected — creating Scheduled Task (runs at system boot, 24/7)...
    REM Remove old Startup folder entry (no longer needed)
    if exist "!STARTUP_FILE!" del "!STARTUP_FILE!"
    REM Remove old Scheduled Task if exists
    schtasks /delete /tn "DiscordSheetsBot" /f >nul 2>&1
    REM Create Scheduled Task that runs at system boot
    schtasks /create /tn "DiscordSheetsBot" /tr "\"!PYTHON_PATH!\" \"!BOT_DIR!main.py\"" /sc ONSTART /ru SYSTEM /rl HIGHEST /f
    if errorlevel 1 (
        echo    Scheduled Task creation failed. Falling back to Startup folder...
        goto :startup_fallback
    )
    echo    Auto-start registered via Scheduled Task (runs at system boot, before login).
) else (
    echo    Not running as Administrator — using Startup folder (runs at login)...
    :startup_fallback
    REM Write startup bat safely using a parenthesized block
    (
        echo @echo off
        echo cd /d "!BOT_DIR!"
        echo start "DiscordSheetsBot" /min "!PYTHON_PATH!" "!BOT_DIR!main.py"
    ) > "!STARTUP_FILE!"
    echo    Auto-start registered via Startup folder: !STARTUP_FILE!
)
echo.

REM --- Step 6: Start the bot now ---
echo [6/6] Starting the bot...
start "DiscordSheetsBot" /min "!PYTHON_PATH!" "!BOT_DIR!main.py"
echo    Bot started in background (PID will appear in Task Manager)
echo.

echo ========================================
echo  Setup complete!
echo  - Bot is running in the background (no console window)
if "!IS_ADMIN!"=="1" (
echo  - It will auto-start when Windows boots (24/7, before login)
echo.
echo  To stop the bot:      schtasks /delete /tn "DiscordSheetsBot" /f
echo  To start manually:    schtasks /run /tn "DiscordSheetsBot"
echo  To check status:      schtasks /query /tn "DiscordSheetsBot"
) else (
echo  - It will auto-start when you log into Windows
echo.
echo  To stop the bot:      taskkill /F /FI "WINDOWTITLE eq DiscordSheetsBot*" /IM python.exe 2^>nul
echo  To remove auto-start: del "!STARTUP_FILE!"
echo.
echo  TIP: Run bootstrap.bat as Administrator for 24/7 auto-start at boot.
)
echo ========================================
pause