"""Persistent storage for DA presets (name -> [preset values] per guild)."""
import json
import os

from utils.logger import logger

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PRESETS_FILE = os.path.join(_PROJECT_ROOT, "da_presets.json")

# Guild identifiers used as top-level keys
GUILD_BIG = "B|M"
GUILD_LITTLE = "b|M"
GUILD_CHOICES = [GUILD_BIG, GUILD_LITTLE]

_presets: dict[str, dict[str, list[str]]] = {}


def _load_presets() -> None:
    global _presets
    try:
        with open(_PRESETS_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
            # Migrate old format {guild: {name: preset_str}} → {guild: {name: [preset_str]}}
            migrated = False
            for guild, entries in data.items():
                for name, val in entries.items():
                    if isinstance(val, str):
                        entries[name] = [val]
                        migrated = True
            if migrated:
                _save_presets()
            _presets = data
    except (FileNotFoundError, json.JSONDecodeError):
        _presets = {}


def _save_presets() -> None:
    try:
        with open(_PRESETS_FILE, "w", encoding="utf-8") as fh:
            json.dump(_presets, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save presets: %s", err)


def save_preset(guild: str, name: str, preset: str) -> bool:
    """Add a preset for *name* under *guild*. Returns True if newly added.

    A name can hold multiple presets; calling this adds a new preset rather
    than overwriting the existing ones.
    """
    _load_presets()
    if guild not in _presets:
        _presets[guild] = {}
    presets_list = _presets[guild].setdefault(name, [])
    if preset in presets_list:
        return False
    presets_list.append(preset)
    _save_presets()
    return True


def get_presets(guild: str) -> dict[str, list[str]]:
    """Return all name→[preset values] mappings for *guild*."""
    _load_presets()
    return _presets.get(guild, {})


def clear_preset(guild: str, name: str, preset: str | None = None) -> bool:
    """Remove a preset entry.

    If *preset* is given, only that preset is removed from the list (the name
    is removed entirely when its list becomes empty).  If *preset* is None, all
    presets for *name* are removed.
    """
    _load_presets()
    if guild not in _presets or name not in _presets[guild]:
        return False
    if preset is None:
        del _presets[guild][name]
    else:
        presets_list = _presets[guild][name]
        if preset in presets_list:
            presets_list.remove(preset)
        if not presets_list:
            del _presets[guild][name]
        else:
            _save_presets()
            return True
    if not _presets[guild]:
        del _presets[guild]
    _save_presets()
    return True


# Load on import
_load_presets()
