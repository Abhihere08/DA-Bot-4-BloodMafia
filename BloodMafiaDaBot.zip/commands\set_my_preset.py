from __future__ import annotations

from discord import Interaction, app_commands

from utils.logger import logger
from utils.presets import GUILD_BIG, save_preset

_GUILD_CHOICE = [
    app_commands.Choice(name="B|M", value=GUILD_BIG),
    app_commands.Choice(name="b|M", value="b|M"),
]


@app_commands.command(
    name="da-set-preset",
    description="Save your preset under your guild (B|M or b|M)",
)
@app_commands.describe(
    name="Your in-game name as it appears on the sheet",
    guild_choice="Which team/guild this preset is for",
    preset="Your preset value (e.g. 695)",
)
@app_commands.choices(
    guild_choice=_GUILD_CHOICE,
)
async def command(
    interaction: Interaction,
    name: str,
    guild_choice: str,
    preset: str,
):
    await interaction.response.send_message(
        content=f"✅ **{name}**'s preset saved for **{guild_choice}** team.\n"
        f"Preset: `{preset}`\n"
        f"View all presets with `/da-presets guild:{guild_choice}`",
        ephemeral=True,
    )
    logger.info(
        "Preset saved by %s: name=%s, guild=%s, preset=%s",
        interaction.user,
        name,
        guild_choice,
        preset,
    )
    save_preset(guild_choice, name, preset)


# Re-export for use by da_preset
__all__ = ["command"]
