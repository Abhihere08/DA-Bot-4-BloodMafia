from __future__ import annotations

from discord import Interaction, app_commands

from utils.logger import logger
from utils.presets import GUILD_BIG, get_presets

_GUILD_CHOICE = [
    app_commands.Choice(name="B|M", value=GUILD_BIG),
    app_commands.Choice(name="b|M", value="b|M"),
]


@app_commands.command(
    name="da-presets",
    description="Show all presets for a guild (B|M or b|M)",
)
@app_commands.describe(
    guild_choice="Which team/guild to show presets for",
)
@app_commands.choices(
    guild_choice=_GUILD_CHOICE,
)
async def command(
    interaction: Interaction,
    guild_choice: str,
):
    presets = get_presets(guild_choice)

    if not presets:
        await interaction.response.send_message(
            content=f"📭 **No presets found for {guild_choice} team.**\n\n"
            f"Be the first to save your preset:\n"
            f"`/da-set-preset name:YourName guild:{guild_choice} preset:695`",
            ephemeral=True,
        )
        return

    lines: list[str] = []
    lines.append(f"📋 **{guild_choice} Team — DA Presets**")
    lines.append("```")
    lines.append(f"{'Preset':>8}  |  {'Name':<24}")
    lines.append("-" * 38)
    flat = []
    for name, preset_list in presets.items():
        for p in preset_list:
            flat.append((p, name))
    for preset, name in sorted(flat, key=lambda x: int(x[0]) if x[0].isdigit() else 0):
        lines.append(f"{preset:>8}  |  {name:<24}")
    lines.append("```")
    lines.append("")
    lines.append(f"**Total: {len(flat)} preset(s) across {len(presets)} player(s)**")
    lines.append("")
    lines.append(
        "⚠️ **These are the presets you need to make for Dragon Arena "
        "for fast filling — please don't fill wrong.**"
    )

    await interaction.response.send_message(content="\n".join(lines)[:2000])
    logger.info(
        "Presets viewed by %s for guild %s (%d entries)",
        interaction.user,
        guild_choice,
        len(presets),
    )


__all__ = ["command"]
