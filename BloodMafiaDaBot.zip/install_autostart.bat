@echo off
setlocal enabledelayedexpansion

REM Check if running as Administrator
net session >nul 2>&1
if errorlevel 1 (
    echo ========================================
    echo  ERROR: Administrator privileges required
    echo ========================================
    echo.
    echo This script needs to run as Administrator to create
    echo a Scheduled Task that starts the bot at system boot.
    echo.
    echo Please right-click this file and select
    echo "Run as administrator".
    echo.
    pause
    exit /b 1
)

REM Set working directory to this script's location
cd /d "%~dp0"

set "BOT_DIR=%~dp0"
for /f "delims=" %%i in ('python -c "import sys; print(sys.executable.replace('python.exe','pythonw.exe'))"') do set "PYTHONW_PATH=%%i"

echo ========================================
echo  DA Bot - Auto-Start Installer
echo ========================================
echo.
echo Bot directory: %BOT_DIR%
echo Python path:   %PYTHONW_PATH%
echo.

REM Remove old Startup folder entry (no longer needed)
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%STARTUP_DIR%\DiscordSheetsBot.bat" (
    del "%STARTUP_DIR%\DiscordSheetsBot.bat"
    echo Removed old Startup folder entry
)

REM Remove old Scheduled Task if exists
schtasks /delete /tn "DiscordSheetsBot" /f >nul 2>&1

REM Create Scheduled Task that runs at system boot (before login)
echo Creating Scheduled Task...
schtasks /create /tn "DiscordSheetsBot" /tr "\"%PYTHONW_PATH%\" \"%BOT_DIR%main.py\"" /sc ONSTART /ru SYSTEM /rl HIGHEST /f
if errorlevel 1 (
    echo.
    echo ERROR: Failed to create Scheduled Task.
    echo Falling back to Startup folder (runs at login)...
    echo @echo off > "%STARTUP_DIR%\DiscordSheetsBot.bat"
    echo cd /d "%BOT_DIR%" >> "%STARTUP_DIR%\DiscordSheetsBot.bat"
    echo start "DiscordSheetsBot" /min "%PYTHONW_PATH%" "%BOT_DIR%main.py" >> "%STARTUP_DIR%\DiscordSheetsBot.bat"
    echo.
    echo Auto-start registered via Startup folder.
    echo The bot will start when you log into Windows.
) else (
    echo.
    echo ========================================
    echo  SUCCESS! Auto-start configured.
    echo ========================================
    echo.
    echo The bot will start automatically when Windows boots,
    echo even before you log in (24/7 operation).
    echo.
    echo To stop the bot:      schtasks /delete /tn "DiscordSheetsBot" /f
    echo To start manually:    schtasks /run /tn "DiscordSheetsBot"
    echo To check status:      schtasks /query /tn "DiscordSheetsBot"
    echo.
)

REM Start the bot now
echo Starting the bot now...
start "DiscordSheetsBot" /min "%PYTHONW_PATH%" "%BOT_DIR%main.py"
echo Bot started.
echo.
pause
