"""Utilities for Dragon Arena slot detection and timezone-aware time display."""
import re
from datetime import UTC, datetime, timedelta, timezone

from config import DA_SLOTS
from utils.logger import logger


# Fixed PST (UTC-8) — game schedule uses PST year-round (no DST).
PST = timezone(timedelta(hours=-8))


def _is_sheet_upcoming(sheet_name: str) -> bool:
    """Return True if the sheet's date is today (PST) or in the future.

    Parses a date (M.D.YY) from the sheet tab name.  If no date is found,
    the sheet is considered upcoming (included) so non-dated sheets like
    "Slot" are never hidden.

    Sheets dated yesterday (PST) are also included because the last slot
    ends at 20:00 PST (= 04:00 UTC next day), so yesterday's sheet may
    still have slots running today.
    """
    from datetime import timedelta

    date_str = parse_slot_date(sheet_name)
    if not date_str:
        return True  # No date in name — can't filter, so include it

    dt = _parse_date_string(date_str)
    if dt is None:
        return True  # Unparseable date — include it

    # Get today's date in PST (game schedule is in PST)
    now_pst = datetime.now(PST)
    today_pst = now_pst.replace(hour=0, minute=0, second=0, microsecond=0)
    yesterday_pst = today_pst - timedelta(days=1)
    sheet_date_pst = dt.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=PST)

    # Include if the sheet date is yesterday or today or in the future
    return sheet_date_pst >= yesterday_pst


def parse_slot_number(title: str) -> int | None:
    """Extract the slot number from a sheet title like 'Dragon Arena ... SLOT 7 - ...'."""
    if not title:
        return None
    match = re.search(r"SLOT\s*(\d+)", title, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None


def parse_slot_date(title: str) -> str | None:
    """Extract a date string like '10.02.26' from a sheet title."""
    if not title:
        return None
    match = re.search(r"(\d{1,2}\.\d{1,2}\.\d{2})", title)
    if match:
        return match.group(1)
    return None


def _parse_date_string(date_str: str) -> datetime | None:
    """Parse 'M.D.YY' or 'D.M.YY' into a timezone-aware UTC datetime.

    Assumes MM.DD.YY format (month first) since sheet tabs use this format.
    """
    try:
        parts = date_str.split(".")
        if len(parts) != 3:
            return None
        month = int(parts[0])
        day = int(parts[1])
        year = int(parts[2])
        if year < 50:
            year += 2000
        else:
            year += 1900
        return datetime(year, month, day, tzinfo=UTC)
    except (ValueError, IndexError):
        return None


def get_slot_time_range(slot_num: int) -> tuple[str, str] | None:
    """Return (start_time, end_time) strings in HH:MM format for a slot."""
    return DA_SLOTS.get(slot_num)


def format_slot_time(slot_num: int, date_str: str | None = None) -> str:
    """Format slot time as Discord timestamps that render in the viewer's local timezone.

    Returns a string like:
        `Slot 7  <t:1763...:t> – <t:1763...:t>`

    Uses Discord's ``<t:TIMESTAMP:FORMAT>`` syntax so the time is displayed
    in each user's local timezone automatically.
    """
    slot = DA_SLOTS.get(slot_num)
    if not slot:
        return f"Slot {slot_num} (unknown time)"

    start_str, end_str = slot

    # Determine the date for the timestamp
    if date_str:
        dt = _parse_date_string(date_str)
    else:
        dt = datetime.now(UTC)

    if dt is None:
        dt = datetime.now(UTC)

    # Parse the UTC times
    start_h, start_m = map(int, start_str.split(":"))
    end_h, end_m = map(int, end_str.split(":"))

    # Handle "next day" slots (Slot 7 starts at 00:00)
    # If the start hour is very early (00:00-04:00), it likely starts on the next day
    # relative to the slot's date. We check if current time is past the start.
    start_dt = dt.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
    end_dt = dt.replace(hour=end_h, minute=end_m, second=0, microsecond=0)

    # If start < end, they're on the same day
    if start_h > end_h or (start_h == end_h and start_m > end_m):
        # End is on the next day (e.g., Slot 7: 00:00 to 01:00)
        end_dt += timedelta(days=1)

    start_ts = int(start_dt.timestamp())
    end_ts = int(end_dt.timestamp())

    # Discord timestamp format 't' = short time (e.g. "3:00 AM")
    # Renders in each viewer's browser local timezone automatically
    return (
        f"Slot {slot_num}  "
        f"<t:{start_ts}:t> – <t:{end_ts}:t>"
    )


def format_slot_time_with_tz(slot_num: int, date_str: str | None = None, tz_name: str | None = None) -> str:
    """Format slot time in a specific timezone (fallback to Discord auto-local).

    If *tz_name* is provided, returns a formatted string like:
        Slot 7  12:00 AM – 1:00 AM (IST)
    Otherwise falls back to Discord's auto-local timestamp format.
    """
    slot = DA_SLOTS.get(slot_num)
    if not slot:
        return f"Slot {slot_num} (unknown time)"

    start_str, end_str = slot
    start_h, start_m = map(int, start_str.split(":"))
    end_h, end_m = map(int, end_str.split(":"))

    if date_str:
        dt = _parse_date_string(date_str)
    else:
        dt = datetime.now(UTC)

    if dt is None:
        dt = datetime.now(UTC)

    start_dt = dt.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
    end_dt = dt.replace(hour=end_h, minute=end_m, second=0, microsecond=0)

    if start_h > end_h or (start_h == end_h and start_m > end_m):
        end_dt += timedelta(days=1)

    if tz_name:
        try:
            from zoneinfo import ZoneInfo
            tz = ZoneInfo(tz_name)
            start_local = start_dt.astimezone(tz)
            end_local = end_dt.astimezone(tz)
            return (
                f"Slot {slot_num}  "
                f"{start_local.strftime('%I:%M %p')} – {end_local.strftime('%I:%M %p')} ({tz_name})"
            )
        except Exception as err:
            logger.debug("TZ formatting failed for %s: %s", tz_name, err)

    # Fallback: Discord auto-local timestamps
    start_ts = int(start_dt.timestamp())
    end_ts = int(end_dt.timestamp())
    return (
        f"Slot {slot_num}  "
        f"<t:{start_ts}:t> – <t:{end_ts}:t>"
    )


def detect_current_slot(now: datetime | None = None) -> int | None:
    """Detect the current active DA slot based on UTC time."""
    if now is None:
        now = datetime.now(UTC)
    elif now.tzinfo is None:
        now = now.replace(tzinfo=UTC)

    utc_hour = now.hour
    utc_minute = now.minute

    for slot_num, (start_str, end_str) in DA_SLOTS.items():
        start_h, start_m = map(int, start_str.split(":"))
        end_h, end_m = map(int, end_str.split(":"))

        start_minutes = start_h * 60 + start_m
        end_minutes = end_h * 60 + end_m
        now_minutes = utc_hour * 60 + utc_minute

        # Handle next-day slots (e.g., 00:00 to 01:00)
        if end_minutes < start_minutes:
            # End is on the next day
            if now_minutes >= start_minutes or now_minutes < end_minutes:
                return slot_num
        else:
            if start_minutes <= now_minutes < end_minutes:
                return slot_num

    return None
