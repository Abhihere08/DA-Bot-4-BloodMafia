from __future__ import annotations

from discord import Interaction, app_commands

from utils.logger import logger
from utils.presets import GUILD_BIG, clear_preset

_GUILD_CHOICE = [
    app_commands.Choice(name="B|M", value=GUILD_BIG),
    app_commands.Choice(name="b|M", value="b|M"),
]


@app_commands.command(
    name="da-remove-preset",
    description="Remove a saved preset by name for a guild",
)
@app_commands.describe(
    guild_choice="Which team/guild the preset belongs to",
    name="The name used when saving the preset",
    preset="Optional: specific preset number to remove. If omitted, removes all presets for this name.",
)
@app_commands.choices(
    guild_choice=_GUILD_CHOICE,
)
async def command(
    interaction: Interaction,
    guild_choice: str,
    name: str,
    preset: str | None = None,
):
    if preset:
        removed = clear_preset(guild_choice, name, preset)
    else:
        removed = clear_preset(guild_choice, name)
    if removed:
        logger.info("Preset removed by %s: name=%s, guild=%s, preset=%s", interaction.user, name, guild_choice, preset)
        if preset:
            await interaction.response.send_message(
                content=f"✅ Removed preset `{preset}` for **{name}** under **{guild_choice}** team.",
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                content=f"✅ Removed all presets for **{name}** under **{guild_choice}** team.",
                ephemeral=True,
            )
    else:
        if preset:
            msg = (
                f"⚠️ No preset `{preset}` found for **{name}** under **{guild_choice}** team.\n"
                f"Check existing presets with `/da-presets guild:{guild_choice}`."
            )
        else:
            msg = (
                f"⚠️ No preset found for **{name}** under **{guild_choice}** team.\n"
                f"Check existing presets with `/da-presets guild:{guild_choice}`."
            )
        await interaction.response.send_message(content=msg, ephemeral=True)


__all__ = ["command"]
