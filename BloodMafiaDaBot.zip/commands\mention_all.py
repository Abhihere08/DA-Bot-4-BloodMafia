from __future__ import annotations

from discord import Interaction, app_commands

from config import DA_SHEET_PATTERNS
from sheets import auto_detect_da_sheet, get_range, get_relevant_da_sheets, get_sheet_names
from utils.discord_utils import mention_member
from utils.logger import logger
from utils.slot_utils import format_slot_time_with_tz, parse_slot_date, parse_slot_number
from utils.tz_prefs import get_user_tz

# Values in data columns that are role headers or labels, not member names
_ROLE_LABELS = frozenset(
    {
        "rally lead 1",
        "leader 2",
        "leader 3",
        "leader 4",
        "rellier",
        "reliever",
        "lead caravan chaser",
    }
)

# Columns to scan for member names (B through F = indices 1-5; skip G = status column)
_SCAN_COLS = range(1, 6)


def _extract_all_names(rows) -> list[str]:
    """Extract unique member names from columns B-F of every row."""
    seen: set[str] = set()
    names: list[str] = []
    for row in rows:
        if not row:
            continue
        for c in _SCAN_COLS:
            if c >= len(row):
                continue
            val = (row[c] or "").strip()
            if not val:
                continue
            low = val.lower()
            if low in _ROLE_LABELS:
                continue
            if low in ("", "team a", "slot", "cheat sheet", "google drive"):
                continue
            if low.startswith(("wow/", "cheat sheet", "google drive", "drive -")):
                continue
            if val.startswith(("http://", "https://", "www.")):
                continue
            if low in seen:
                continue
            seen.add(low)
            names.append(val)
    return names


async def _sheet_autocomplete(interaction: Interaction, current: str):
    """Populate the sheet dropdown with only the relevant, latest DA sheets for Big and Little BM."""
    try:
        names = await get_sheet_names()
        relevant = get_relevant_da_sheets(names)

        query = current.lower().strip() if current else ""
        if query:
            matched = [n for n in relevant if query in n.lower()]
            if not matched:
                matched = [n for n in names if query in n.lower() and any(p.lower() in n.lower() for p in DA_SHEET_PATTERNS)]
            choices = matched[:25]
        else:
            choices = relevant

        return [app_commands.Choice(name=n, value=n) for n in choices]
    except Exception as err:
        logger.error("Error in sheet autocomplete: %s", err)
        return []


@app_commands.command(
    name="da-mention-all",
    description="Mention every member listed in a DA sheet",
)
@app_commands.describe(
    sheet="DA sheet tab (leave blank to auto-detect)"
)
@app_commands.autocomplete(sheet=_sheet_autocomplete)
async def command(interaction: Interaction, sheet: str | None = None):
    await interaction.response.defer()

    try:
        # --- Resolve sheet tab ---
        sheet_tab = sheet
        if not sheet_tab:
            sheet_names = await get_sheet_names()
            sheet_tab = await auto_detect_da_sheet(sheet_names)
            if not sheet_tab and sheet_names:
                sheet_tab = sheet_names[0]

        if not sheet_tab:
            return await interaction.edit_original_response(
                content="⚠️ Could not auto-detect a DA sheet tab."
            )

        # --- Fetch & parse ---
        rows = await get_range(f"'{sheet_tab}'")
        if not rows:
            return await interaction.edit_original_response(
                content=f"⚠️ No data found in sheet tab `{sheet_tab}`."
            )

        names = _extract_all_names(rows)
        if not names:
            return await interaction.edit_original_response(
                content=f"⚠️ No member names found in `{sheet_tab}`."
            )

        # --- Parse slot info ---
        title_row = rows[0][0] if rows and rows[0] else ""
        slot_num = parse_slot_number(title_row)
        slot_date = parse_slot_date(title_row)
        if slot_num:
            user_tz = get_user_tz(interaction.user.id)
            slot_time_str = format_slot_time_with_tz(slot_num, slot_date, user_tz)
        else:
            slot_time_str = "Unknown slot"

        guild = interaction.guild

        # --- Build mention list ---
        mentioned: list[str] = []
        unmapped: list[str] = []
        for name in names:
            mention = mention_member(guild, name)
            if mention.startswith(("<@", "@")):
                mentioned.append(mention)
            else:
                unmapped.append(name)

        lines: list[str] = []
        lines.append("**📢 Mentioning all DA members**")
        lines.append(f"📋 Sheet: `{sheet_tab}` • **{slot_time_str}**")
        lines.append("")
        lines.append(" ".join(mentioned))
        if unmapped:
            lines.append("")
            lines.append(f"_Note: {len(unmapped)} name(s) not matched to Discord users: {', '.join(unmapped)}_\n")
            lines.append("_Use `/da-link @user game_name` to bind a name manually._")
        lines.append("")
        lines.append("**Get ready all !!!**")

        full_msg = "\n".join(lines)

        await interaction.edit_original_response(content=full_msg[:2000])

        logger.info(
            "Mention-all posted by %s from sheet '%s' (%d members)",
            interaction.user,
            sheet_tab,
            len(mentioned),
        )

    except Exception as err:
        logger.error("Error in /da-mention-all: %s", err)
        try:
            await interaction.edit_original_response(
                content=f"❌ Error: {err}"
            )
        except Exception:
            await interaction.followup.send(
                content=f"❌ Error: {err}", ephemeral=True
            )
