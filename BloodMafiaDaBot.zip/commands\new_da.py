from __future__ import annotations

from datetime import UTC, datetime, timedelta, timezone

from discord import Interaction, app_commands

from config import DA_SHEET_PATTERNS
from sheets import auto_detect_da_sheet, get_range, get_relevant_da_sheets, get_sheet_names
from utils.logger import logger
from utils.slot_utils import _parse_date_string, parse_slot_date, parse_slot_number

# Fixed PST (UTC-8) — game schedule uses PST year-round
PST = timezone(timedelta(hours=-8))
REGISTRATION_END_HOUR = 22  # 10:00 PM PST on the sheet date

# Guild-specific tags
LITTLE_BM_TAG = "@b|M Members 🦅"
BIG_BM_TAG = "@B|M Members 👑"


def _detect_sheet_type(sheet_name: str) -> str:
    """Return 'little' or 'big' based on the sheet tab name."""
    low = sheet_name.lower()
    if "little bm" in low or "littlr bm" in low:
        return "little"
    if "big bm" in low:
        return "big"
    return "unknown"


def _get_slot_start_datetime(slot_num: int, date_str: str | None) -> datetime | None:
    """Calculate UTC datetime when the slot starts.

    Slot 1 starts at 22:00 PST on the sheet date (10 PM PST).
    Subsequent slots are 3 hours apart.
    """
    if date_str:
        dt = _parse_date_string(date_str)
        if dt is None:
            dt = datetime.now(UTC)
    else:
        dt = datetime.now(UTC)

    # Slot 1 at 22:00 PST on the sheet date; each subsequent slot +3h
    sheet_date_pst = dt.replace(hour=22, minute=0, second=0, microsecond=0, tzinfo=PST)
    slot_start_pst = sheet_date_pst + timedelta(hours=(slot_num - 1) * 3)
    return slot_start_pst.astimezone(UTC)


def _get_registration_end_datetime(date_str: str | None) -> datetime | None:
    """Calculate UTC datetime when registration ends (10 PM PST on the sheet date)."""
    if date_str:
        dt = _parse_date_string(date_str)
        if dt is None:
            dt = datetime.now(UTC)
    else:
        dt = datetime.now(UTC)

    reg_end_pst = dt.replace(hour=REGISTRATION_END_HOUR, minute=0, second=0, microsecond=0, tzinfo=PST)
    return reg_end_pst.astimezone(UTC)


def _calc_hours_left(reg_end: datetime, slot_start: datetime | None) -> tuple[float, str]:
    """Calculate hours left until registration closes.

    Returns (hours_until_reg_end, status_string).
    """
    now = datetime.now(UTC)
    delta = reg_end - now
    hours = delta.total_seconds() / 3600

    if hours > 24:
        return hours, "registration_not_open"
    elif hours > 1:
        return hours, "registration_open"
    elif hours > 0:
        return hours, "closing_soon"
    else:
        # Registration ended — check if slot has started
        if slot_start and slot_start > now:
            return 0, "registration_closed"
        return 0, "in_progress"


def _build_da_message(
    sheet_name: str,
    title: str,
    slot_num: int,
    date_str: str | None,
) -> str:
    """Build the new-DA announcement message with a live countdown timer."""
    sheet_type = _detect_sheet_type(sheet_name)
    tag = BIG_BM_TAG if sheet_type == "big" else LITTLE_BM_TAG

    reg_end = _get_registration_end_datetime(date_str)
    slot_start = _get_slot_start_datetime(slot_num, date_str)
    if reg_end:
        hours_left, status = _calc_hours_left(reg_end, slot_start)
    else:
        hours_left, status = 0, "in_progress"

    reg_ts = int(reg_end.timestamp()) if reg_end else 0

    lines: list[str] = []
    lines.append(f"{tag}")
    lines.append("")

    if status == "registration_not_open":
        hours_until_reg = hours_left - 24
        if hours_until_reg > 48:
            lines.append(
                f"*Registration not yet open — {int(hours_until_reg)}h until signups begin for Team A in DA!*"
            )
        else:
            lines.append(
                f"*Registration opens in {int(hours_until_reg)}h for Team A in DA!*"
            )
    elif status == "registration_open":
        lines.append(
            f"*Registration ends <t:{reg_ts}:R> ({int(hours_left)}h left) — sign up for Team A in DA!*"
        )
    elif status == "closing_soon":
        lines.append(
            f"*Registration ends <t:{reg_ts}:R> (< 1h left! **Last call!**) — Team A in DA!*"
        )
    elif status == "registration_closed":
        lines.append(
            f"*Registration closed. Slot {slot_num} starts in <t:{int(slot_start.timestamp())}:R>.*"
        )
    else:
        lines.append(
            "*DA is happening now! Join Team A if you haven't already!*"
        )

    lines.append("")
    lines.append(f"For \"Slot {slot_num}\" slot")
    lines.append("")
    lines.append("Choose Team A or Can't Participate in ur game.")
    lines.append("There will be no Team B unless we have 40+ members sign up.")

    return "\n".join(lines)


async def _sheet_autocomplete(interaction: Interaction, current: str):
    """Autocomplete for DA sheet selection (only relevant latest sheets for Big and Little BM)."""
    try:
        names = await get_sheet_names()
        relevant = get_relevant_da_sheets(names)

        query = current.lower().strip() if current else ""
        if query:
            matched = [n for n in relevant if query in n.lower()]
            if not matched:
                matched = [n for n in names if query in n.lower() and any(p.lower() in n.lower() for p in DA_SHEET_PATTERNS)]
            choices = matched[:25]
        else:
            choices = relevant

        return [app_commands.Choice(name=n, value=n) for n in choices]
    except Exception as err:
        logger.error("Error in sheet autocomplete: %s", err)
        return []


@app_commands.command(
    name="da-new",
    description="Announce a new DA event with registration time and slot info",
)
@app_commands.describe(
    sheet="DA sheet tab (leave blank to auto-detect)"
)
@app_commands.autocomplete(sheet=_sheet_autocomplete)
async def command(interaction: Interaction, sheet: str | None = None):
    await interaction.response.defer()

    try:
        # --- Resolve sheet tab ---
        sheet_tab = sheet
        if not sheet_tab:
            sheet_names = await get_sheet_names()
            sheet_tab = await auto_detect_da_sheet(sheet_names)
            if not sheet_tab and sheet_names:
                sheet_tab = sheet_names[0]

        if not sheet_tab:
            return await interaction.edit_original_response(
                content="⚠️ Could not auto-detect a DA sheet tab."
            )

        # --- Fetch & parse ---
        rows = await get_range(f"'{sheet_tab}'")
        if not rows:
            return await interaction.edit_original_response(
                content=f"⚠️ No data found in sheet tab `{sheet_tab}`."
            )

        from commands.send_da_assignments import parse_da_sheet
        parsed = parse_da_sheet(rows)
        if not parsed:
            return await interaction.edit_original_response(
                content="⚠️ Could not parse DA assignments from the sheet."
            )

        title = parsed["title"]
        slot_num = parse_slot_number(title)
        date_str = parse_slot_date(title)

        if not slot_num:
            return await interaction.edit_original_response(
                content=f"⚠️ Could not detect slot number from sheet title: `{title}`"
            )

        # --- Build & send message ---
        message = _build_da_message(sheet_tab, title, slot_num, date_str)
        await interaction.edit_original_response(content=message[:2000])

        logger.info(
            "New-DA announcement by %s for sheet '%s' (slot %d)",
            interaction.user,
            sheet_tab,
            slot_num,
        )

    except Exception as err:
        logger.error("Error in /da-new: %s", err)
        try:
            await interaction.edit_original_response(
                content=f"❌ Error: {err}"
            )
        except Exception:
            await interaction.followup.send(
                content=f"❌ Error: {err}", ephemeral=True
            )
