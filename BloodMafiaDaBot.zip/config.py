import os

from dotenv import load_dotenv

load_dotenv()


def _required(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Missing required env variable: {key}")
    return val


def _optional_int(key: str, default=None):
    val = os.getenv(key)
    if not val:
        return default
    return int(val)


def _extract_sheet_id(url_or_id: str) -> str:
    """Accept either a raw sheet ID or a full Google Sheets URL and return the ID."""
    if not url_or_id:
        return ""
    if "docs.google.com/spreadsheets/d/" in url_or_id:
        after = url_or_id.split("/d/")[1]
        return after.split("/")[0].split("?")[0].split("#")[0]
    return url_or_id


# --- Required ---
DISCORD_TOKEN = _required("DISCORD_TOKEN")

_raw_sheet = _required("GOOGLE_SHEET_ID")
GOOGLE_SHEET_ID = _extract_sheet_id(_raw_sheet)

# --- Optional (nice-to-have, not strictly required) ---
# Single-channel mode (backward compatible)
NOTIFICATION_CHANNEL_ID = _optional_int("NOTIFICATION_CHANNEL_ID")
# Multi-guild mode: comma-separated list of channel IDs (one per guild)
_raw_channels = os.getenv("NOTIFICATION_CHANNEL_IDS", "")
NOTIFICATION_CHANNEL_IDS: list[int] = [
    int(c.strip()) for c in _raw_channels.split(",") if c.strip()
] if _raw_channels else []

# Single-guild mode (backward compatible)
DISCORD_GUILD_ID = _optional_int("DISCORD_GUILD_ID")
# Multi-guild mode: comma-separated list of guild IDs for fast command sync
_raw_guilds = os.getenv("DISCORD_GUILD_IDS", "")
DISCORD_GUILD_IDS: list[int] = [
    int(g.strip()) for g in _raw_guilds.split(",") if g.strip()
] if _raw_guilds else []

POLL_INTERVAL_MS = int(os.getenv("POLL_INTERVAL_MS", "300000"))

# Aggregated list of all notification channel IDs across all modes
ALL_NOTIFICATION_CHANNELS: list[int] = list(
    dict.fromkeys(
        ([NOTIFICATION_CHANNEL_ID] if NOTIFICATION_CHANNEL_ID else [])
        + NOTIFICATION_CHANNEL_IDS
    )
)

# Aggregated list of all guild IDs for command sync
ALL_GUILD_IDS: list[int] = list(
    dict.fromkeys(
        ([DISCORD_GUILD_ID] if DISCORD_GUILD_ID else [])
        + DISCORD_GUILD_IDS
    )
)

# Dragon Arena slot schedule (UTC time ranges).
# Each slot runs daily at the same UTC time.
# PST = UTC-8, so Slot 1 at 22:00 PST = 06:00 UTC, etc.
DA_SLOTS: dict[int, tuple[str, str]] = {
    1: ("06:00", "07:00"),
    2: ("09:00", "10:00"),
    3: ("12:00", "13:00"),
    4: ("15:00", "16:00"),
    5: ("18:00", "19:00"),
    6: ("21:00", "22:00"),
    7: ("00:00", "01:00"),  # Next day
    8: ("03:00", "04:00"),  # Next day
}

# Sheets that contain Dragon Arena assignments.  The bot auto-detects the
# left-most tab whose name best matches one of these patterns so that it can
# pick up the correct assignment sheet without manual configuration.
DA_SHEET_PATTERNS = ["BIG BM", "LITTLE BM", "LITTLR BM", "BIG B|M", "LITTLE B|M", "Slot"]

# Keywords that identify a real assignment row (vs instruction / label rows).
POSITION_KEYWORDS = [
    "citadel",
    "transporter",
    "ancient remains",
    "hot springs",
]
