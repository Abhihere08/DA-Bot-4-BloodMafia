"""Manual trigger to run a DA scheduler check cycle on demand."""
from __future__ import annotations

from discord import Interaction, app_commands

from utils.da_scheduler import _announced, run_scheduler_check
from utils.logger import logger


@app_commands.command(
    name="da-check",
    description="Manually trigger a DA scheduler check — scan for new sheets and fire announcements",
)
@app_commands.describe(
    dry_run="If true, only show what's already announced without sending messages",
)
async def command(
    interaction: Interaction,
    dry_run: bool = False,
):
    await interaction.response.defer(ephemeral=True)

    if dry_run:
        sheet_names: list[str] = [n for n in _announced]
        lines = ["**📊 DA Scheduler Status (Dry Run)**"]
        lines.append(f"_Already announced sheets ({len(sheet_names)}):_")
        if sheet_names:
            for name in sheet_names:
                lines.append(f"  - `{name}`")
        else:
            lines.append("  (none yet)")
        await interaction.edit_original_response(content="\n".join(lines)[:2000])
        return

    result = await run_scheduler_check()

    lines = ["**📊 DA Scheduler Check Complete**"]
    lines.append(f"_Checked {result['checked']} DA-related sheet(s)_")

    if result["announced"]:
        lines.append("\n**New DA announced & scheduled:**")
        for s in result["announced"]:
            lines.append(f"  - `{s}`")

    if result["skipped"]:
        lines.append(f"\n**Skipped ({len(result['skipped'])}):**")
        for s in result["skipped"]:
            lines.append(f"  - `{s}`")

    if not result["announced"] and not result["skipped"]:
        lines.append("\n_(No upcoming or new DA sheets found)_")

    if result["error"]:
        lines.append(f"\n[ERROR] {result['error']}")

    await interaction.edit_original_response(content="\n".join(lines)[:2000])
    logger.info("Manual DA check triggered by %s (dry_run=%s)", interaction.user, dry_run)


__all__ = ["command"]
