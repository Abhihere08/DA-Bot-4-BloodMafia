import os
import sys

# Ensure the script's directory is in sys.path so imports work
# regardless of the working directory
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

import discord
from discord.ext import commands

from config import (
    ALL_GUILD_IDS,
    ALL_NOTIFICATION_CHANNELS,
    DISCORD_TOKEN,
    POLL_INTERVAL_MS,
)
from utils.logger import logger


def create_bot() -> commands.Bot:
    intents = discord.Intents.default()
    intents.message_content = True
    intents.members = True
    bot = commands.Bot(command_prefix="!", intents=intents)

    @bot.event
    async def setup_hook():
        from commands import command_list
        if ALL_GUILD_IDS:
            # Clear any globally-registered commands to avoid duplicates,
            # then register guild-scoped commands only
            bot.tree.clear_commands(guild=None)
            await bot.tree.sync()  # sync empty → clears global commands from Discord
            for cmd in command_list:
                bot.tree.add_command(cmd)
            for gid in ALL_GUILD_IDS:
                bot.tree.copy_global_to(guild=discord.Object(id=gid))
                synced = await bot.tree.sync(guild=discord.Object(id=gid))
                logger.info("Synced %d slash command(s) to guild %s", len(synced), gid)
            logger.info("Command sync complete for %d guild(s)", len(ALL_GUILD_IDS))
        else:
            for cmd in command_list:
                bot.tree.add_command(cmd)
            synced = await bot.tree.sync()
            logger.info("Synced %d global slash command(s)", len(synced))

    @bot.event
    async def on_ready():
        logger.info("Logged in as %s", bot.user)
        logger.info("Serving %d guild(s)", len(bot.guilds))

        # Pre-fetch sheet names to warm the HTML cache — autocomplete has a 3s
        # Discord timeout and the first Google fetch takes ~2-3s.
        from sheets import _fetch_html
        try:
            _fetch_html()
            logger.info("Sheet name cache warmed (autocomplete ready)")
        except Exception as err:
            logger.warning("Cache warm-up failed: %s", err)

        from utils.da_scheduler import start_da_scheduler
        from utils.scheduler import start_polling

        async def _on_new_rows(new_rows):
            if not ALL_NOTIFICATION_CHANNELS:
                logger.info("No notification channels configured; skipping auto-notification")
                return
            for row in new_rows:
                for channel_id in ALL_NOTIFICATION_CHANNELS:
                    channel = bot.get_channel(channel_id)
                    if channel:
                        try:
                            await channel.send(f"New Sheet Entry:\n{' | '.join(row)}")
                        except Exception as err:
                            logger.error("Failed to send notification to channel %d: %s", channel_id, err)

        start_polling(POLL_INTERVAL_MS, _on_new_rows)
        start_da_scheduler(bot)

    @bot.event
    async def on_guild_member_add(member: discord.Member):
        from events.guild_member_add import on_member_join
        await on_member_join(member)

    return bot


async def start_bot(bot: commands.Bot):
    await bot.start(DISCORD_TOKEN)
