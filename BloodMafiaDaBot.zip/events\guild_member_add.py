from datetime import UTC, datetime

import discord

from sheets import append_row
from utils.logger import logger


async def on_member_join(member: discord.Member):
    try:
        timestamp = datetime.now(UTC).isoformat()
        await append_row([timestamp, member.name, str(member.id), "JOINED"], "Sheet1")
        logger.info("Logged new member join: %s", member.name)
    except Exception as err:
        logger.error("Failed to log member join: %s", err)
