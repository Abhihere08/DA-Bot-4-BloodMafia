"""Helpers for resolving sheet usernames to Discord members."""
import re

from utils.mapping import get_mapping, remove_mapping, save_mapping


def _normalise(name: str) -> str:
    return re.sub(r"\s+", " ", name).strip().lower()


def find_member(guild, username: str):
    """Resolve a plain username (from the Google Sheet) to a ``discord.Member``.

    Matching priority:
      1. Persistent mapping (already resolved by caller via ``mention_member``)
      2. Exact (case-insensitive) display-name match
      3. Exact (case-insensitive) username / global-name match
      4. Exact (case-insensitive) nickname match
      5. Partial display-name match
      6. Partial username match
      7. Partial nickname match
    Returns ``None`` when no member can be resolved or *guild* is unavailable.
    """
    if not username or guild is None:
        return None
    key = _normalise(username)

    # Exact matches first
    for member in guild.members:
        if member.bot:
            continue
        if _normalise(member.display_name) == key:
            return member
    for member in guild.members:
        if member.bot:
            continue
        if _normalise(member.name) == key:
            return member
        global_name = getattr(member, "global_name", None)
        if global_name and _normalise(str(global_name)) == key:
            return member
    for member in guild.members:
        if member.bot:
            continue
        nick = member.nick or ""
        if nick and _normalise(nick) == key:
            return member

    # Partial matches (sheet name contained in display name or nickname)
    for member in guild.members:
        if member.bot:
            continue
        if key in _normalise(member.display_name):
            return member
        if key in _normalise(member.name):
            return member
        nick = member.nick or ""
        if nick and key in _normalise(nick):
            return member

    # Try matching individual words from the sheet name
    words = key.split()
    if len(words) > 1:
        for member in guild.members:
            if member.bot:
                continue
            dn = _normalise(member.display_name)
            mn = _normalise(member.name)
            nick = _normalise(member.nick or "")
            for w in words:
                if len(w) > 2 and (w in dn or w in mn or w in nick):
                    return member

    return None


def mention_member(guild, username: str) -> str:
    """
    Return a Discord mention for *username*.

    Resolution order:
      1. **Persistent mapping** — check ``mappings.json`` for a previously
         saved link.  If found, use ``<@id>`` (works even if the member
         left the server).
      2. **Live guild lookup** — search the guild's member cache; if a
         match is found, **auto-save** the mapping so it persists.
      3. **Fallback** — return the bare name.
    """
    if not username:
        return username
    if guild is None:
        return username

    # 1. Check persistent mapping first
    user_id = get_mapping(username)
    if user_id:
        member = guild.get_member(int(user_id)) if user_id.isdigit() else None
        if member:
            return member.mention
        # Member may have left the server — raw ID mention still resolves
        return f"<@{user_id}>"

    # 2. Fall back to live guild lookup (and auto-save)
    member = find_member(guild, username)
    if member is not None:
        save_mapping(username, member.id)
        return member.mention

    return username


def unlink_member(game_name: str) -> bool:
    """Remove a stored name -> Discord mapping."""
    return remove_mapping(game_name)


def link_member(game_name: str, user_id) -> None:
    """Manually save a name -> Discord mapping."""
    save_mapping(game_name, user_id)
