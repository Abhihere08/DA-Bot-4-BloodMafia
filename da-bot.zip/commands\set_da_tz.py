from __future__ import annotations

from zoneinfo import available_timezones

from discord import Interaction, app_commands

from utils.logger import logger
from utils.tz_prefs import remove_user_tz, save_user_tz

# Common timezone shortcuts users can type
_TZ_SHORTCUTS: dict[str, str] = {
    "ist": "Asia/Kolkata",
    "est": "America/New_York",
    "pst": "America/Los_Angeles",
    "cst": "America/Chicago",
    "mst": "America/Denver",
    "gmt": "Etc/GMT",
    "utc": "Etc/UTC",
    "jst": "Asia/Tokyo",
    "kst": "Asia/Seoul",
    "aest": "Australia/Sydney",
    "cet": "Europe/Paris",
    "eet": "Europe/Athens",
}


@app_commands.command(
    name="da-set-tz",
    description="Set your timezone for DA slot time display (optional override)",
)
@app_commands.describe(
    timezone="Your timezone, e.g. 'Asia/Kolkata', 'IST', 'EST', or 'clear' to reset"
)
async def command(interaction: Interaction, timezone: str):
    tz_input = timezone.strip()

    if tz_input.lower() == "clear":
        if remove_user_tz(interaction.user.id):
            await interaction.response.send_message(
                "✅ Your timezone preference has been cleared. Times will use your browser's local timezone.",
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                "⚠️ You have no timezone preference set.",
                ephemeral=True,
            )
        return

    # Resolve timezone
    tz_name = _TZ_SHORTCUTS.get(tz_input.lower())
    if not tz_name:
        # Check if it's a full IANA timezone name
        tz_name = tz_input
        if tz_name not in available_timezones():
            # Try case-insensitive match
            for candidate in available_timezones():
                if candidate.lower() == tz_name.lower():
                    tz_name = candidate
                    break

    if tz_name not in available_timezones():
        valid_examples = "IST, EST, PST, CET, JST, UTC, or full IANA names like 'Asia/Kolkata'"
        await interaction.response.send_message(
            f"❌ Unknown timezone: `{tz_input}`\n\n"
            f"Valid examples: {valid_examples}",
            ephemeral=True,
        )
        return

    save_user_tz(interaction.user.id, tz_name)
    await interaction.response.send_message(
        f"✅ Your timezone is set to `{tz_name}`. DA slot times will display in this timezone.",
        ephemeral=True,
    )
    logger.info("User %s set timezone to %s", interaction.user.id, tz_name)
