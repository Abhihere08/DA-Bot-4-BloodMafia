@echo off
setlocal enabledelayedexpansion

REM Check if running as Administrator
net session >nul 2>&1
if errorlevel 1 (
    echo ========================================
    echo  ERROR: Administrator privileges required
    echo ========================================
    echo.
    echo This script needs Administrator to register
    echo the PM2 auto-start at boot.
    echo.
    echo Please right-click this file and select
    echo "Run as administrator".
    echo.
    pause
    exit /b 1
)

REM Set working directory to this script's location
cd /d "%~dp0"

echo ========================================
echo  DA Bot - Auto-Start Installer (PM2)
echo ========================================
echo.

where pm2 >nul 2>&1
if errorlevel 1 (
    echo ERROR: PM2 not found. Run bootstrap.bat first.
    pause
    exit /b 1
)
for /f "delims=" %%i in ('where pm2.cmd') do set "PM2_PATH=%%i"

if not exist "logs" mkdir "logs"

REM Make sure the bot is running and the process list is saved
pm2 start ecosystem.config.js
pm2 save

REM Register start-at-login (hidden, restores saved PM2 processes)
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "STARTUP_VBS=!STARTUP_DIR!\da-bot-autostart.vbs"
(
    echo Set sh = CreateObject("WScript.Shell"^)
    echo sh.Run """!PM2_PATH!"" resurrect", 0, False
) > "!STARTUP_VBS!"

REM Register PM2 to start at boot
pm2 startup
pm2 save

echo.
echo ========================================
echo  SUCCESS! Auto-start configured.
echo.
echo  The bot will start automatically when
echo  Windows boots, even before you log in.
echo.
echo  Bot status:   pm2 status
echo  Bot logs:     pm2 logs da-bot
echo  Stop bot:     pm2 stop da-bot
echo  Start bot:    pm2 start da-bot
echo ========================================
pause
