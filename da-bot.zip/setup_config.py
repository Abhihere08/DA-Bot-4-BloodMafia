"""Interactive configuration wizard.

Prompts for the *minimal* set of credentials needed to run the bot and
writes a ``.env`` file that ``config.py`` can consume.

Required:
  - Discord bot token
  - Google Sheet URL or ID  (must be shared "Anyone with the link can view")

Optional (enables auto-notifications and guild-scoped commands):
  - Notification channel ID
  - Discord Guild ID
"""


def _prompt(label: str) -> str:
    return input(label).strip()


def _ok(val: str) -> bool:
    return bool(val)


def main() -> int:
    print("=" * 50)
    print("  Discord Sheets Bot - Configuration Setup")
    print("=" * 50)
    print()

    discord_token = _prompt("Discord Bot Token: ")
    if not _ok(discord_token):
        print("ERROR: Discord bot token is required.")
        return 1

    print("\nNotification Channel ID (for auto-announcements):")
    print("  1. In Discord, enable Developer Mode (User Settings → Advanced)")
    print("  2. Right-click your notification channel → Copy Channel ID")
    channel_input = _prompt("Channel ID (press Enter to skip): ")

    print("\nDiscord Guild/Server ID (for guild-scoped commands — faster registration):")
    print("  1. In Discord, enable Developer Mode")
    print("  2. Right-click your server name → Copy Server ID")
    guild_id_input = _prompt("Guild ID (press Enter to skip — commands will be global): ")

    sheet_input = _prompt("Google Sheet URL or ID: ")
    if not _ok(sheet_input):
        print("ERROR: Google Sheet ID or URL is required.")
        return 1

    env_lines = [
        "# Discord",
        f"DISCORD_TOKEN={discord_token}",
    ]

    if channel_input:
        env_lines.append(f"NOTIFICATION_CHANNEL_ID={channel_input}")
    else:
        env_lines.append("# NOTIFICATION_CHANNEL_ID=  (not set — auto-notifications disabled)")

    if guild_id_input:
        env_lines.append(f"DISCORD_GUILD_ID={guild_id_input}")
    else:
        env_lines.append("# DISCORD_GUILD_ID=  (not set — commands will be global)")

    env_lines += [
        "",
        "# Google Sheets",
        "# The sheet must be shared with 'Anyone with the link can view'",
        f"GOOGLE_SHEET_ID={sheet_input}",
        "",
        "# Bot Settings",
        "POLL_INTERVAL_MS=300000",
        "",
    ]

    with open(".env", "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(env_lines) + "\n")

    print("\n.env written successfully!")
    if not channel_input:
        print("NOTE: No notification channel configured. Auto-notifications are disabled.")
    if not guild_id_input:
        print("NOTE: No guild ID configured. Commands will be global (slower to propagate).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
