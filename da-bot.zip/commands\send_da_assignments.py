from __future__ import annotations

from discord import Interaction, app_commands

from config import DA_SHEET_PATTERNS, POSITION_KEYWORDS
from datetime import UTC, datetime, timedelta
from sheets import auto_detect_da_sheet, get_range, get_relevant_da_sheets, get_sheet_names
from utils.discord_utils import mention_member
from utils.logger import logger
from utils.slot_utils import (
    format_slot_time_with_tz,
    get_sheet_date,
    get_slot_start_datetime,
    parse_slot_number,
)
from utils.tz_prefs import get_user_tz

# ---------------------------------------------------------------------------
# Sheet parsing
# ---------------------------------------------------------------------------

_SKIP_PREFIXES = (
    "all caravan",
    "rally lead 1 hold",
    "all members in red",
    "please check",
    "da cheat",
    "wow info",
    "cravan",
    "filler",
    "fast filler",
    "leads make",
    "when we say",
    "use ",
    "those ",
    "send 1 troop",
    "fillers sit",
    "transporters 1-4",
)

_MAX_MSG_LEN = 1900  # leave headroom under Discord's 2000-char limit


def _extract_roles(row):
    """Collect role names from columns B-E (indices 1-4)."""
    roles = []
    for c in range(1, 5):
        val = (row[c] if c < len(row) else "") or ""
        val = val.strip()
        if val:
            roles.append(val)
    return roles


def _role_for_column(roles, col_index):
    """Map a data-column index (1-4) to its role label."""
    idx = col_index - 1
    if idx < len(roles) and roles[idx]:
        return roles[idx]
    fallback = {
        1: "Rally Lead 1",
        2: "Leader 2",
        3: "Leader 3",
        4: "Leader 4",
    }
    return fallback.get(col_index, f"Member {col_index}")


def parse_da_sheet(rows):
    """Parse raw DA assignment rows into structured sections.

    Sheet layout (auto-detected leftmost tab, e.g. *DA*):
      Row 1  : Title + slot  (col A = title, col G = slot label)
      Rows 2-10  : Instructions and Caravan Chasers section
      Rows 11-19: TEAM A - Top Half of Map
      Rows 21-28: TEAM A - Bottom Half of Map
      Col G (index 6): Fast Fillers list
    """
    if not rows:
        return None

    title = (rows[0][0] if rows[0] else "") or "DA Assignments"
    slot = (
        rows[0][6].strip()
        if len(rows[0]) > 6 and rows[0][6]
        else ""
    )

    caravan: list = []
    top_half: list = []
    bottom_half: list = []
    fillers: list = []

    section = None
    roles: list = []

    for i in range(1, len(rows)):
        row = rows[i] or []
        col0 = (row[0] if len(row) > 0 else "") or ""
        col0 = col0.strip()
        col0_lower = col0.lower()

        # Collect fast-fillers from column G (index 6)
        if len(row) > 6:
            f = (row[6] or "").strip()
            if f and len(f) > 1:
                fillers.append(f)

        # --- Section headers (also define roles for top/bottom) ---
        if col0_lower == "top half of map":
            section = "top"
            roles = _extract_roles(row)
            continue
        if col0_lower == "bottom half of map":
            section = "bottom"
            roles = _extract_roles(row)
            continue
        if "caravan chasers" in col0_lower:
            section = "caravan"
            roles = []
            continue

        # --- Empty col0: could be role-header row or TEAM A marker ---
        if col0 == "":
            potential = _extract_roles(row)
            if potential:
                roles = potential
            continue

        # Skip instruction / informational rows
        if col0_lower.startswith(_SKIP_PREFIXES):
            continue

        # --- Assignment rows (col0 starts with a position keyword) ---
        if not any(col0_lower.startswith(kw) for kw in POSITION_KEYWORDS):
            continue

        assignment = {"position": col0, "members": []}
        for c in range(1, 5):
            if c >= len(row):
                break
            name = (row[c] or "").strip()
            if not name:
                continue
            role = _role_for_column(roles, c)
            assignment["members"].append({"name": name, "role": role})

        if assignment["members"]:
            target = {
                "caravan": caravan,
                "top": top_half,
                "bottom": bottom_half,
            }.get(section, caravan)
            target.append(assignment)

    # Deduplicate fillers while preserving order
    seen: set = set()
    unique_fillers: list = []
    for f in fillers:
        if f not in seen:
            seen.add(f)
            unique_fillers.append(f)

    return {
        "title": title,
        "slot": slot,
        "caravanChasers": caravan,
        "topHalf": top_half,
        "bottomHalf": bottom_half,
        "fillers": unique_fillers,
    }


# ---------------------------------------------------------------------------
# Discord rendering helpers
# ---------------------------------------------------------------------------

def _format_member_line(guild, member):
    """Render `@mention (role)` for a single member dict."""
    mention = mention_member(guild, member["name"])
    return f"{mention} **({member['role']})**"


def _split_messages(lines: list[str]) -> list[str]:
    """Split lines into messages no longer than _MAX_MSG_LEN."""
    messages: list[str] = []
    current: list[str] = []
    current_len = 0
    for line in lines:
        line_len = len(line) + 1  # +1 for newline
        if current and current_len + line_len > _MAX_MSG_LEN:
            messages.append("\n".join(current))
            current = []
            current_len = 0
        current.append(line)
        current_len += line_len
    if current:
        messages.append("\n".join(current))
    return messages


def _build_section_text(section_title, assignments, guild):
    """Build a text block for a list of assignments with mentions and roles."""
    if not assignments:
        return f"**{section_title}**\n_No assignments found._"

    lines = [f"**{section_title}**", ""]
    for a in assignments:
        lines.append(f"🏰 **{a['position']}**")
        member_lines = [_format_member_line(guild, m) for m in a["members"]]
        lines.extend(f"  {ml}" for ml in member_lines)
        lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Autocomplete for sheet selection
# ---------------------------------------------------------------------------

async def _sheet_autocomplete(interaction: Interaction, current: str):
    """Populate the sheet dropdown with only the relevant, latest DA sheets for Big and Little BM."""
    try:
        names = await get_sheet_names()
        relevant = get_relevant_da_sheets(names)

        query = current.lower().strip() if current else ""
        if query:
            matched = [n for n in relevant if query in n.lower()]
            if not matched:
                matched = [n for n in names if query in n.lower() and any(p.lower() in n.lower() for p in DA_SHEET_PATTERNS)]
            choices = matched[:25]
        else:
            choices = relevant

        return [app_commands.Choice(name=n, value=n) for n in choices]
    except Exception as err:
        logger.error("Error in sheet autocomplete: %s", err)
        return []


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------

@app_commands.command(
    name="da-send-assignments",
    description="Fetch and display Dragon Arena assignments from the Google Sheet",
)
@app_commands.describe(
    sheet="DA sheet tab (e.g. DA 101, BIG BM 10.02.26). Leave blank to auto-detect."
)
@app_commands.autocomplete(sheet=_sheet_autocomplete)
async def command(interaction: Interaction, sheet: str | None = None):
    await interaction.response.defer()

    try:
        # --- Resolve which sheet tab to read ---
        sheet_tab = sheet

        if not sheet_tab:
            sheet_names = await get_sheet_names()
            logger.info("Available sheets: %s", sheet_names)
            sheet_tab = await auto_detect_da_sheet(sheet_names)
            if not sheet_tab and sheet_names:
                sheet_tab = sheet_names[0]

        if not sheet_tab:
            return await interaction.edit_original_response(
                content="⚠️ Could not auto-detect a DA sheet tab."
            )

        # --- Fetch & parse ---
        rows = await get_range(f"'{sheet_tab}'")

        if not rows:
            return await interaction.edit_original_response(
                content=f"⚠️ No data found in sheet tab `{sheet_tab}`."
            )

        parsed = parse_da_sheet(rows)
        if not parsed:
            return await interaction.edit_original_response(
                content="⚠️ Could not parse DA assignments from the sheet."
            )

        guild = interaction.guild

        # --- Build sections in order ---
        sections: list[tuple[str, list]] = []
        if parsed["caravanChasers"]:
            sections.append(("🚛  CARAVAN CHASERS & TRANSPORTER HOLDERS", parsed["caravanChasers"]))
        if parsed["topHalf"]:
            sections.append(("🏔️  TEAM A — TOP HALF OF MAP", parsed["topHalf"]))
        if parsed["bottomHalf"]:
            sections.append(("🌊  TEAM A — BOTTOM HALF OF MAP", parsed["bottomHalf"]))

        if not sections:
            return await interaction.edit_original_response(
                content=f"⚠️ No assignment data found in `{sheet_tab}`."
            )

        slot_num = parse_slot_number(parsed["title"])
        slot_date_str = get_sheet_date(parsed["title"], sheet_tab)
        reminder_line = ""
        if slot_num:
            user_tz = get_user_tz(interaction.user.id)
            slot_time_str = format_slot_time_with_tz(slot_num, slot_date_str, user_tz)
            slot_start = get_slot_start_datetime(slot_num, slot_date_str)
            if slot_start:
                reminder_time = slot_start - timedelta(minutes=30)
                if reminder_time > datetime.now(UTC):
                    reminder_line = (
                        "**⏰ Assignments auto-send 30 min before slot — "
                        f"fires <t:{int(reminder_time.timestamp())}:R>**"
                    )
        else:
            slot_time_str = "Unknown"

        # --- Build the full message content ---
        all_lines: list[str] = []
        all_lines.append(f"**{parsed['title']}**")
        all_lines.append(f"📋 Sheet: `{sheet_tab}` • **{slot_time_str}**")
        if reminder_line:
            all_lines.append(reminder_line)
        all_lines.append("")
        all_lines.append("**Check your assignments below:**")
        all_lines.append("")

        for sec_title, assignments in sections:
            all_lines.append(_build_section_text(sec_title, assignments, guild))
            all_lines.append("")

        # --- Split into chunks if needed ---
        messages = _split_messages(all_lines)

        if not messages:
            return await interaction.edit_original_response(
                content=f"⚠️ No assignment data found in `{sheet_tab}`."
            )

        # --- Send messages ---
        await interaction.edit_original_response(content=messages[0])

        for msg in messages[1:]:
            await interaction.followup.send(content=msg, wait=True)

        logger.info(
            "DA assignments posted by %s from sheet '%s' (%d sections, %d messages)",
            interaction.user,
            sheet_tab,
            len(sections),
            len(messages),
        )

    except Exception as err:
        logger.error("Error in /da-send-assignments: %s", err)
        try:
            await interaction.edit_original_response(
                content=f"❌ Error fetching assignments: {err}"
            )
        except Exception:
            await interaction.followup.send(
                content=f"❌ Error fetching assignments: {err}", ephemeral=True
            )
