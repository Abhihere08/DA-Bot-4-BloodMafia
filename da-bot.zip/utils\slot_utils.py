"""Utilities for Dragon Arena slot detection and timezone-aware time display."""
import re
from datetime import UTC, datetime, timedelta, timezone

from utils.logger import logger


# Game schedule uses a permanently fixed GMT-5 clock (no DST adjustments).
# Sheet tab date = day slots begin. Registration ends at REGISTRATION_END_HOUR
# (GMT-5) on the sheet date (midnight = 00:00 GMT-5 start of sheet date).
# Slot 1 starts 1 hour after registration ends.
GMT5 = timezone(timedelta(hours=-5), "GMT-5")
PST = GMT5  # legacy alias used by older code paths
REGISTRATION_END_HOUR = 0   # 00:00 (Midnight) GMT-5 — registration closes at start of sheet date
SLOT_HOURS_APART = 3        # distance between slot *starts* (slots begin every 3h)
SLOT_DURATION_HOURS = 1     # each slot lasts 1 hour (2h gap between slots)

# Sheets whose tab date is *MAX_RELEVANT_PAST_DAYS or more* old are hidden from
# command sheet-selection so that only recent past + upcoming sheets appear.
MAX_RELEVANT_PAST_DAYS = 5


def _is_sheet_upcoming(sheet_name: str) -> bool:
    """Return True if the sheet's date is today (PST) or in the future.

    Parses a date (M.D.YY) from the sheet tab name.  If no date is found,
    the sheet is considered upcoming (included) so non-dated sheets like
    "Slot" are never hidden.

    Sheets whose tab date is yesterday (PST) are also included because the
    last slot ends at 20:00 PST (= 04:00 UTC next day), so yesterday's sheet
    may still have slots running today.
    """
    from datetime import timedelta as _td

    date_str = parse_slot_date(sheet_name)
    if not date_str:
        return True  # No date in name — can't filter, so include it

    dt = _parse_date_string(date_str)
    if dt is None:
        return True  # Unparseable date — include it

    now_pst = datetime.now(PST)
    today_pst = now_pst.replace(hour=0, minute=0, second=0, microsecond=0)
    yesterday_pst = today_pst - _td(days=1)
    sheet_date_pst = dt.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=PST)

    return sheet_date_pst >= yesterday_pst


def is_sheet_stale(date_str: str | None, max_days: int = MAX_RELEVANT_PAST_DAYS) -> bool:
    """Return True if the sheet date is *max_days* or more old (in PST).

    Used by command sheet-selection (``get_relevant_da_sheets``) to hide very
    old DA sheets so that only sheets from the last ``max_days`` days (or in
    the future) are shown.
    """
    dt = _parse_date_string(date_str) if date_str else None
    if dt is None:
        return False  # can't determine age — don't flag as stale
    now_pst = datetime.now(PST)
    today_pst = now_pst.replace(hour=0, minute=0, second=0, microsecond=0)
    sheet_date_pst = dt.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=PST)
    cutoff_pst = today_pst - timedelta(days=max_days)
    return sheet_date_pst <= cutoff_pst


def parse_slot_number(title: str) -> int | None:
    """Extract the slot number from a sheet title like 'Dragon Arena ... SLOT 7 - ...'."""
    if not title:
        return None
    match = re.search(r"SLOT\s*(\d+)", title, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None


def parse_slot_date(title: str) -> str | None:
    """Extract a date string like '10.02.26' (MM.DD.YY) from a sheet title or A1 text."""
    if not title:
        return None
    match = re.search(r"(\d{1,2}\.\d{1,2}\.\d{2})", title)
    if match:
        return match.group(1)
    return None


def get_sheet_date(title: str | None, tab_name: str | None = None) -> str | None:
    """Resolve the DA date (MM.DD.YY, PST).

    The **tab name** is the reliable source — the user renames each sheet tab
    with the full date (e.g. ``BIG BM 10.11.26``).  The date written into A1
    (line 1) can drift/stale (it currently still says ``10.08.26`` for some
    sheets), so it is only used as a fallback when the tab name carries no
    date.  The slot *number* is always read separately from A1 via
    ``parse_slot_number``.
    """
    d = parse_slot_date(tab_name) if tab_name else None
    if d:
        return d
    return parse_slot_date(title) if title else None


def _parse_date_string(date_str: str) -> datetime | None:
    """Parse 'M.D.YY' (sheet tab date, written in PST) into calendar components.

    Returns a naive-midnight UTC carrier datetime holding those components; the
    game clock is applied in GMT-5 by ``_game_anchor`` (sheet date is treated as
    the GMT-5 calendar date for reg-end/slot math).
    """
    try:
        parts = date_str.split(".")
        if len(parts) != 3:
            return None
        month = int(parts[0])
        day = int(parts[1])
        year = int(parts[2])
        if year < 50:
            year += 2000
        else:
            year += 1900
        return datetime(year, month, day, tzinfo=UTC)
    except (ValueError, IndexError):
        return None


def _game_anchor(date_str: str | None) -> datetime | None:
    """Midnight GMT-5 on the sheet date (registration ends here).

    Sheet tab date (``MM.DD.YY``) is written in PST but represents the game day
    in the official fixed GMT-5 clock. Registration ends at
    ``REGISTRATION_END_HOUR`` GMT-5 on that sheet date (00:00 = midnight/start
    of sheet date). Slot 1 starts 1 hour later. All internal scheduling uses
    GMT-5 and is converted to UTC instants for storage/Discord timestamps.
    """
    if not date_str:
        return None
    dt = _parse_date_string(date_str)
    if dt is None:
        return None
    return datetime(dt.year, dt.month, dt.day, tzinfo=GMT5)


def get_registration_end_datetime(date_str: str | None) -> datetime | None:
    """UTC datetime when registration ends: REGISTRATION_END_HOUR GMT-5 on the sheet date."""
    base = _game_anchor(date_str)
    if base is None:
        return None
    reg_end = base.replace(hour=REGISTRATION_END_HOUR, minute=0, second=0, microsecond=0)
    return reg_end.astimezone(UTC)


def get_registration_open_datetime(date_str: str | None) -> datetime | None:
    """UTC datetime when registration opens (24 hours before registration ends)."""
    reg_end = get_registration_end_datetime(date_str)
    if reg_end is None:
        return None
    return reg_end - timedelta(hours=24)


def get_slot_start_datetime(slot_num: int, date_str: str | None) -> datetime | None:
    """UTC datetime when slot N starts.

    Registration ends at REGISTRATION_END_HOUR GMT-5 on the sheet date;
    slot 1 starts 1 hour later and each subsequent slot is 3 hours apart.
    """
    base = _game_anchor(date_str)
    if base is None:
        return None
    start_gmt5 = base + timedelta(
        hours=REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART
    )
    return start_gmt5.astimezone(UTC)


def get_slot_end_datetime(slot_num: int, date_str: str | None) -> datetime | None:
    """UTC datetime when slot N ends (start + 1h)."""
    start = get_slot_start_datetime(slot_num, date_str)
    if start is None:
        return None
    return start + timedelta(hours=SLOT_DURATION_HOURS)


def get_slot_time_range(slot_num: int) -> tuple[str, str] | None:
    """Return (start_time, end_time) as GMT-5 hour strings for a slot."""
    if not 1 <= slot_num <= 8:
        return None
    start_hour = (REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART) % 24
    end_hour = (start_hour + SLOT_DURATION_HOURS) % 24
    return (f"{start_hour:02d}:00", f"{end_hour:02d}:00")


def format_slot_time(slot_num: int, date_str: str | None = None) -> str:
    """Format slot start/end as Discord auto-local timestamps (shown in each user's local timezone)."""
    start = get_slot_start_datetime(slot_num, date_str)
    if start is None:
        return f"Slot {slot_num} (unknown time)"
    end = start + timedelta(hours=SLOT_DURATION_HOURS)
    start_ts = int(start.timestamp())
    end_ts = int(end.timestamp())
    return f"Slot {slot_num}  <t:{start_ts}:t> – <t:{end_ts}:t>"


def format_slot_time_with_tz(slot_num: int, date_str: str | None = None, tz_name: str | None = None) -> str:
    """Format slot time for display.

    Slots are defined in GMT-5 (fixed, no DST). By default returns Discord
    auto-local timestamps (``<t:...:t>``) so every viewer sees the time in
    their own local timezone. If *tz_name* (IANA) is provided, renders
    explicitly in that timezone.
    """
    start = get_slot_start_datetime(slot_num, date_str)
    if start is None:
        return f"Slot {slot_num} (unknown time)"
    end = start + timedelta(hours=SLOT_DURATION_HOURS)

    if tz_name:
        try:
            from zoneinfo import ZoneInfo
            tz = ZoneInfo(tz_name)
            start_local = start.astimezone(tz)
            end_local = end.astimezone(tz)
            return (
                f"Slot {slot_num}  "
                f"{start_local.strftime('%I:%M %p')} – {end_local.strftime('%I:%M %p')} ({tz_name})"
            )
        except Exception as err:
            logger.debug("TZ formatting failed for %s: %s", tz_name, err)

    start_ts = int(start.timestamp())
    end_ts = int(end.timestamp())
    return f"Slot {slot_num}  <t:{start_ts}:t> – <t:{end_ts}:t>"


def detect_current_slot(now: datetime | None = None) -> int | None:
    """Detect the current active DA slot based on the current time.

    Slot times are fixed in GMT-5 (no DST adjustments). Registration ends at
    00:00 GMT-5 on the sheet date; slot 1 starts 01:00 GMT-5.

    Slot schedule (GMT-5, 3 h apart, 1 h duration each):
        Slot 1: 01:00 – 02:00  (sheet date)
        Slot 2: 04:00 – 05:00
        Slot 3: 07:00 – 08:00
        Slot 4: 10:00 – 11:00
        Slot 5: 13:00 – 14:00
        Slot 6: 16:00 – 17:00
        Slot 7: 19:00 – 20:00
        Slot 8: 22:00 – 23:00
    """
    if now is None:
        now = datetime.now(UTC)
    elif now.tzinfo is None:
        now = now.replace(tzinfo=UTC)

    now_g = now.astimezone(GMT5)
    g_hour = now_g.hour
    g_minute = now_g.minute

    # Slot N starts at GMT-5 hour = (REGISTRATION_END_HOUR + 1 + (N-1) * 3) % 24
    for slot_num in range(1, 9):
        start_hour = (REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART) % 24
        end_hour = (start_hour + SLOT_DURATION_HOURS) % 24

        now_minutes = g_hour * 60 + g_minute
        start_minutes = start_hour * 60
        end_minutes = end_hour * 60

        if end_minutes <= start_minutes:
            # Wraps past midnight (e.g. 23:00 – 00:00)
            if now_minutes >= start_minutes or now_minutes < end_minutes:
                return slot_num
        else:
            if start_minutes <= now_minutes < end_minutes:
                return slot_num

    return None
