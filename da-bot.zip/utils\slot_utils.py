"""Utilities for Dragon Arena slot detection and timezone-aware time display."""
import re
from datetime import UTC, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from utils.logger import logger


# Game schedule uses Pacific Time which observes DST (PST in winter = UTC-8,
# PDT in summer = UTC-7). Using ZoneInfo so all calculations automatically
# handle the spring-forward / fall-back transitions each year.
PST = ZoneInfo("America/Los_Angeles")

# The sheet tab date represents the day slots begin. Registration ends the
# day *before* the sheet date at REGISTRATION_END_HOUR PST.
REGISTRATION_END_HOUR = 22  # 10:00 PM PST — registration closes the day before the sheet date
SLOT_HOURS_APART = 3        # distance between slot *starts* (slots begin every 3h)
SLOT_DURATION_HOURS = 1     # each slot lasts 1 hour (2h gap between slots)

# Sheets whose tab date is *MAX_RELEVANT_PAST_DAYS or more* old are hidden from
# command sheet-selection so that only recent past + upcoming sheets appear.
MAX_RELEVANT_PAST_DAYS = 5


def _is_sheet_upcoming(sheet_name: str) -> bool:
    """Return True if the sheet's date is today (PST) or in the future.

    Parses a date (M.D.YY) from the sheet tab name.  If no date is found,
    the sheet is considered upcoming (included) so non-dated sheets like
    "Slot" are never hidden.

    Sheets whose tab date is yesterday (PST) are also included because the
    last slot ends at 20:00 PST (= 04:00 UTC next day), so yesterday's sheet
    may still have slots running today.
    """
    from datetime import timedelta as _td

    date_str = parse_slot_date(sheet_name)
    if not date_str:
        return True  # No date in name — can't filter, so include it

    dt = _parse_date_string(date_str)
    if dt is None:
        return True  # Unparseable date — include it

    now_pst = datetime.now(PST)
    today_pst = now_pst.replace(hour=0, minute=0, second=0, microsecond=0)
    yesterday_pst = today_pst - _td(days=1)
    sheet_date_pst = dt.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=PST)

    return sheet_date_pst >= yesterday_pst


def is_sheet_stale(date_str: str | None, max_days: int = MAX_RELEVANT_PAST_DAYS) -> bool:
    """Return True if the sheet date is *max_days* or more old (in PST).

    Used by command sheet-selection (``get_relevant_da_sheets``) to hide very
    old DA sheets so that only sheets from the last ``max_days`` days (or in
    the future) are shown.
    """
    dt = _parse_date_string(date_str) if date_str else None
    if dt is None:
        return False  # can't determine age — don't flag as stale
    now_pst = datetime.now(PST)
    today_pst = now_pst.replace(hour=0, minute=0, second=0, microsecond=0)
    sheet_date_pst = dt.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=PST)
    cutoff_pst = today_pst - timedelta(days=max_days)
    return sheet_date_pst <= cutoff_pst


def parse_slot_number(title: str) -> int | None:
    """Extract the slot number from a sheet title like 'Dragon Arena ... SLOT 7 - ...'."""
    if not title:
        return None
    match = re.search(r"SLOT\s*(\d+)", title, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None


def parse_slot_date(title: str) -> str | None:
    """Extract a date string like '10.02.26' (MM.DD.YY) from a sheet title or A1 text."""
    if not title:
        return None
    match = re.search(r"(\d{1,2}\.\d{1,2}\.\d{2})", title)
    if match:
        return match.group(1)
    return None


def get_sheet_date(title: str | None, tab_name: str | None = None) -> str | None:
    """Resolve the DA date (MM.DD.YY, PST).

    The **tab name** is the reliable source — the user renames each sheet tab
    with the full date (e.g. ``BIG BM 10.11.26``).  The date written into A1
    (line 1) can drift/stale (it currently still says ``10.08.26`` for some
    sheets), so it is only used as a fallback when the tab name carries no
    date.  The slot *number* is always read separately from A1 via
    ``parse_slot_number``.
    """
    d = parse_slot_date(tab_name) if tab_name else None
    if d:
        return d
    return parse_slot_date(title) if title else None


def _parse_date_string(date_str: str) -> datetime | None:
    """Parse 'M.D.YY' into a timezone-aware UTC datetime at midnight.

    Assumes MM.DD.YY format (month first) since sheet dates use this format.
    The returned UTC date components are used to build PST-anchored times.
    """
    try:
        parts = date_str.split(".")
        if len(parts) != 3:
            return None
        month = int(parts[0])
        day = int(parts[1])
        year = int(parts[2])
        if year < 50:
            year += 2000
        else:
            year += 1900
        return datetime(year, month, day, tzinfo=UTC)
    except (ValueError, IndexError):
        return None


def _pst_midnight(date_str: str | None) -> datetime | None:
    """Midnight PST on the day slot 1 starts (sheet date minus 1 day).

    The sheet tab date represents when slots begin (e.g. 10.23.26 means
    slots start on Oct 23). Registration closes the day before the sheet
    date at 21:00 PST.
    """
    if not date_str:
        return None
    dt = _parse_date_string(date_str)
    if dt is None:
        return None
    # Sheet date is the slot-start day; registration end is the prior day
    slot_start_date = datetime(dt.year, dt.month, dt.day, tzinfo=PST)
    return slot_start_date - timedelta(days=1)


def get_registration_end_datetime(date_str: str | None) -> datetime | None:
    """UTC datetime when registration ends: 22:00 PST on the day before the sheet date.

    The sheet date represents when slots begin. Registration closes at 22:00 PST
    (REGISTRATION_END_HOUR) on the day before the sheet date.
    """
    base = _pst_midnight(date_str)
    if base is None:
        return None
    reg_end_pst = base.replace(hour=REGISTRATION_END_HOUR, minute=0, second=0, microsecond=0)
    return reg_end_pst.astimezone(UTC)


def get_registration_open_datetime(date_str: str | None) -> datetime | None:
    """UTC datetime when registration opens: 22:00 PST two days before the sheet date.

    Registration is a 24-hour window ending at REGISTRATION_END_HOUR PST on the
    day before the sheet date.  Thus it opens 24 hours earlier.
    """
    reg_end = get_registration_end_datetime(date_str)
    if reg_end is None:
        return None
    return reg_end - timedelta(hours=24)


def get_slot_start_datetime(slot_num: int, date_str: str | None) -> datetime | None:
    """UTC datetime when slot N starts.

    The sheet date represents when slot 1 begins. Registration ends at 21:00 PST
    the day before the sheet date; slot 1 starts 1 hour later (22:00 PST) and
    each subsequent slot is 3 hours apart, rolling past midnight into the next
    PST day as required (e.g. slot 2 = 01:00 PST the next day). Times are
    computed in PST then converted to UTC so the PST day boundary is handled
    correctly.
    """
    base = _pst_midnight(date_str)
    if base is None:
        return None
    start_pst = base + timedelta(
        hours=REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART
    )
    return start_pst.astimezone(UTC)


def get_slot_end_datetime(slot_num: int, date_str: str | None) -> datetime | None:
    """UTC datetime when slot N ends (start + 1h)."""
    start = get_slot_start_datetime(slot_num, date_str)
    if start is None:
        return None
    return start + timedelta(hours=SLOT_DURATION_HOURS)


def get_slot_time_range(slot_num: int) -> tuple[str, str] | None:
    """Return (start_time, end_time) as PST hour strings for a slot."""
    if not 1 <= slot_num <= 8:
        return None
    start_hour = (REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART) % 24
    end_hour = (start_hour + SLOT_DURATION_HOURS) % 24
    return (f"{start_hour:02d}:00", f"{end_hour:02d}:00")


def format_slot_time(slot_num: int, date_str: str | None = None) -> str:
    """Format slot start/end as Discord auto-local timestamps."""
    start = get_slot_start_datetime(slot_num, date_str)
    if start is None:
        return f"Slot {slot_num} (unknown time)"
    end = start + timedelta(hours=SLOT_DURATION_HOURS)
    start_ts = int(start.timestamp())
    end_ts = int(end.timestamp())
    return f"Slot {slot_num}  <t:{start_ts}:t> – <t:{end_ts}:t>"


def format_slot_time_with_tz(slot_num: int, date_str: str | None = None, tz_name: str | None = None) -> str:
    """Format slot time in a specific timezone (fallback to Discord auto-local).

    If *tz_name* is provided, returns e.g. ``Slot 7  12:00 AM – 1:00 AM (IST)``.
    Otherwise falls back to Discord's auto-local timestamp format.
    """
    start = get_slot_start_datetime(slot_num, date_str)
    if start is None:
        return f"Slot {slot_num} (unknown time)"
    end = start + timedelta(hours=SLOT_DURATION_HOURS)

    if tz_name:
        try:
            from zoneinfo import ZoneInfo
            tz = ZoneInfo(tz_name)
            start_local = start.astimezone(tz)
            end_local = end.astimezone(tz)
            return (
                f"Slot {slot_num}  "
                f"{start_local.strftime('%I:%M %p')} – {end_local.strftime('%I:%M %p')} ({tz_name})"
            )
        except Exception as err:
            logger.debug("TZ formatting failed for %s: %s", tz_name, err)

    start_ts = int(start.timestamp())
    end_ts = int(end.timestamp())
    return f"Slot {slot_num}  <t:{start_ts}:t> – <t:{end_ts}:t>"


def detect_current_slot(now: datetime | None = None) -> int | None:
    """Detect the current active DA slot based on the current time.

    Slot times are defined in Pacific Time (PST/PDT).  Using ZoneInfo
    ensures DST transitions are handled automatically — unlike the old
    static UTC table which was off by 1 hour during summer (PDT).

    Slot schedule (Pacific Time, 3 h apart, 1 h duration each):
        Slot 1: 22:00 – 23:00  (day before sheet date)
        Slot 2: 01:00 – 02:00
        Slot 3: 04:00 – 05:00
        Slot 4: 07:00 – 08:00
        Slot 5: 10:00 – 11:00
        Slot 6: 13:00 – 14:00
        Slot 7: 16:00 – 17:00
        Slot 8: 19:00 – 20:00
    """
    if now is None:
        now = datetime.now(UTC)
    elif now.tzinfo is None:
        now = now.replace(tzinfo=UTC)

    now_pst = now.astimezone(PST)
    pst_hour = now_pst.hour
    pst_minute = now_pst.minute

    # Slot N starts at PST hour = (22 + (N-1) * 3) % 24, lasts 1 hour
    for slot_num in range(1, 9):
        start_hour = (REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART) % 24
        end_hour = (start_hour + SLOT_DURATION_HOURS) % 24

        now_minutes = pst_hour * 60 + pst_minute
        start_minutes = start_hour * 60
        end_minutes = end_hour * 60

        if end_minutes <= start_minutes:
            # Wraps past midnight (e.g. 23:00 – 00:00)
            if now_minutes >= start_minutes or now_minutes < end_minutes:
                return slot_num
        else:
            if start_minutes <= now_minutes < end_minutes:
                return slot_num

    return None
