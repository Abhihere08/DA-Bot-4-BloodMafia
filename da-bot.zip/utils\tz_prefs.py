"""Persistent timezone preferences for Discord users.

Users can set their preferred timezone with `/da-set-tz` so that DA slot
times are displayed in that timezone instead of the browser's local time.
"""
import json
import os

from utils.logger import logger

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_TZ_FILE = os.path.join(_PROJECT_ROOT, "tz_preferences.json")

_preferences: dict[str, str] = {}


def _load() -> None:
    global _preferences
    try:
        with open(_TZ_FILE, encoding="utf-8") as fh:
            _preferences = json.load(fh)
    except FileNotFoundError:
        _preferences = {}
    except (json.JSONDecodeError, OSError) as err:
        logger.error("Failed to load timezone preferences: %s", err)
        _preferences = {}


def _save() -> None:
    try:
        with open(_TZ_FILE, "w", encoding="utf-8") as fh:
            json.dump(_preferences, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save timezone preferences: %s", err)


def get_user_tz(user_id: int | str) -> str | None:
    """Return the stored timezone name for *user_id*, or ``None``."""
    return _preferences.get(str(user_id))


def save_user_tz(user_id: int | str, tz_name: str) -> None:
    """Persist *tz_name* for *user_id*."""
    _preferences[str(user_id)] = tz_name
    _save()
    logger.info("Saved timezone '%s' for user %s", tz_name, user_id)


def remove_user_tz(user_id: int | str) -> bool:
    """Remove a stored timezone preference. Returns True if one was removed."""
    key = str(user_id)
    if key in _preferences:
        del _preferences[key]
        _save()
        logger.info("Removed timezone preference for user %s", user_id)
        return True
    return False


def get_all_tz_preferences() -> dict[str, str]:
    """Return a shallow copy of all timezone preferences."""
    return dict(_preferences)


_load()
