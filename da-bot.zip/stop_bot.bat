@echo off
cd /d "%~dp0"
pm2 stop da-bot
pm2 status
pause
