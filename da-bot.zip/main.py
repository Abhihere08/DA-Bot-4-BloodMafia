import asyncio
import os
import sys

# Ensure the script's directory is in sys.path so imports work
# regardless of the working directory
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

from bot import create_bot, start_bot
from utils.logger import logger

logger.info("Starting Discord Sheets Bot...")

bot = create_bot()
asyncio.run(start_bot(bot))
