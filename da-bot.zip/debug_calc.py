from utils.slot_utils import REGISTRATION_END_HOUR, SLOT_HOURS_APART, _pst_midnight, get_slot_start_datetime, PST
from zoneinfo import ZoneInfo
from datetime import datetime, timedelta

tz = ZoneInfo('America/Los_Angeles')
now = datetime.now(tz)
print(f'Current time: {now}')
print()

# For BIG BM 10.29.26, Slot 7
date_str = '10.29.26'
slot_num = 7

# Step 1: _pst_midnight returns the day BEFORE the sheet date
base = _pst_midnight(date_str)
print(f'1. _pst_midnight({date_str}) = {base}')
print(f'   This is the "registration day" = sheet date minus 1 day')
print()

# Step 2: Registration end = base + REGISTRATION_END_HOUR (22 = 10 PM)
reg_end_pst = base.replace(hour=REGISTRATION_END_HOUR, minute=0, second=0, microsecond=0)
print(f'2. REGISTRATION_END_HOUR = {REGISTRATION_END_HOUR} (10 PM)')
print(f'   Registration ends: {reg_end_pst} PST/PDT')
print()

# Step 3: Slot start = REGISTRATION_END_HOUR + 1 (10 PM + 1 = 11 PM) + (slot-1)*3
# This is where the problem is! Slot 7 would be:
# 22 + 1 + (7-1)*3 = 22 + 1 + 18 = 41 hours from midnight of reg day
# That would be 41 hours = 1 day + 17 hours = next day 5 PM
# But wait, let me check what the code actually does

slot_start = get_slot_start_datetime(slot_num, date_str)
print(f'3. get_slot_start_datetime({slot_num}, {date_str}) = {slot_start}')
print(f'   In PST: {slot_start.astimezone(PST)}')
print()

# The math in get_slot_start_datetime:
# start_pst = base + timedelta(hours=REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART)
hours_from_base = REGISTRATION_END_HOUR + 1 + (slot_num - 1) * SLOT_HOURS_APART
print(f'4. Hours from registration day midnight: {REGISTRATION_END_HOUR} + 1 + ({slot_num}-1)*{SLOT_HOURS_APART} = {hours_from_base}')
print(f'   = {hours_from_base} hours = {hours_from_base//24} days + {hours_from_base%24} hours')
start_pst = base + timedelta(hours=hours_from_base)
print(f'   Slot start: {start_pst.astimezone(PST)}')
print()

# Registration window is 24 hours before slot start
# So registration opens = slot_start - 24 hours
reg_open = slot_start - timedelta(hours=24)
print(f'5. Registration opens (slot - 24h): {reg_open.astimezone(PST)}')
print()

# But the code says _REGISTRATION_WINDOW_HOURS = 24
# The new-DA announcement fires when within 24h of slot start
# That means reg_open = slot_start - 24h
print(f'   REGISTRATION_WINDOW = 24 hours')
print(f'   Announcement fires at slot_start - 24h = {reg_open.astimezone(PST)}')
