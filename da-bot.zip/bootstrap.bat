@echo off
setlocal enabledelayedexpansion

cd /d "%~dp0"
set "BOT_DIR=%~dp0"
if "%BOT_DIR:~-1%"=="\" set "BOT_DIR=%BOT_DIR:~0,-1%"

net session >nul 2>&1
set "IS_ADMIN=0"
if not errorlevel 1 set "IS_ADMIN=1"

echo ========================================
echo  Discord Sheets Bot - Setup / Run
echo ========================================
echo.

echo [1/6] Checking Python...
set "PYTHON_CMD="
where python >nul 2>&1 && set "PYTHON_CMD=python"
if not defined PYTHON_CMD where py >nul 2>&1 && set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYTHON_CMD=%LocalAppData%\Programs\Python\Python312\python.exe"
  if not defined PYTHON_CMD if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set "PYTHON_CMD=%LocalAppData%\Programs\Python\Python311\python.exe"
)
if not defined PYTHON_CMD (
  echo ERROR: Python 3.11+ not found. Install from https://www.python.org/downloads/
  pause
  exit /b 1
)
for /f "delims=" %%v in ('!PYTHON_CMD! --version 2^>^&1') do set "PY_VER=%%v"
echo    !PY_VER!
echo.

echo [2/6] Checking PM2 (optional)...
set "HAVE_PM2=0"
set "PM2_PATH="
set "PM2_HEALTHY=0"
where pm2 >nul 2>&1
if not errorlevel 1 (
  set "HAVE_PM2=1"
  for /f "delims=" %%i in ('where pm2.cmd 2^>nul') do if not defined PM2_PATH set "PM2_PATH=%%i"
  if not defined PM2_PATH for /f "delims=" %%i in ('where pm2 2^>nul') do if not defined PM2_PATH set "PM2_PATH=%%i"
  pm2 ping >nul 2>&1
  if not errorlevel 1 (set "PM2_HEALTHY=1" & echo    PM2 healthy.) else (echo    PM2 unhealthy - using direct start.)
) else (
  echo    PM2 not found - using direct start.
)
echo.

echo [3/6] Checking configuration...
if not exist ".env" (
  echo    No .env - running configuration wizard...
  !PYTHON_CMD! setup_config.py
  if errorlevel 1 (echo ERROR: Configuration failed.& pause& exit /b 1)
) else (
  echo    .env exists.
)
echo.

echo [4/6] Installing dependencies...
!PYTHON_CMD! -m pip install --upgrade pip >nul 2>&1
!PYTHON_CMD! -m pip install -r requirements.txt
if errorlevel 1 (echo ERROR: Dependency install failed.& pause& exit /b 1)
!PYTHON_CMD! -m pip install tzdata >nul 2>&1
echo    Done.
echo.

echo [5/6] Deploying slash commands...
if exist "deploy_commands.py" (
  !PYTHON_CMD! deploy_commands.py
  if errorlevel 1 echo    WARNING: deploy reported an error (continuing).
) else (
  echo    deploy_commands.py missing - skipping.
)
echo.

echo [6/6] Starting bot...
if not exist "logs" mkdir "logs"

(
  echo @echo off
  echo cd /d "%BOT_DIR%"
  echo if not exist "logs" mkdir "logs"
  echo !PYTHON_CMD! main.py ^>^> "logs\out.log" 2^>^> "logs\err.log"
) > "%BOT_DIR%\start_da_bot_direct.bat"

set "STARTED=0"
if "!PM2_HEALTHY!"=="1" (
  pm2 delete da-bot >nul 2>&1
  pm2 start ecosystem.config.js
  if not errorlevel 1 (pm2 save >nul 2>&1 & set "STARTED=PM2")
)

if "!STARTED!"=="0" (
  powershell -NoProfile -Command "$r=Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'main\.py' -and $_.CommandLine -match [regex]::Escape('%BOT_DIR%') }; if($r){exit 0}else{exit 1}" >nul 2>&1
  if not errorlevel 1 (echo    Bot already running.& set "STARTED=ALREADY")
)

if "!STARTED!"=="0" (
  echo    Starting directly (detached)...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%BOT_DIR%\_start_da.ps1" -BotDir "%BOT_DIR%" -PythonCmd "%PYTHON_CMD%"
  if not errorlevel 1 (
    set "STARTED=DIRECT"
  ) else (
    echo    WARNING: Direct start may have failed. See logs\err.log
  )
)

if "!STARTED!"=="0" (
  echo ERROR: Failed to start bot.
  pause
  exit /b 1
)
echo    Started: !STARTED!
echo.

echo Registering auto-start...
set "STARTUP_VBS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\da-bot-autostart.vbs"
if "!PM2_HEALTHY!"=="1" if defined PM2_PATH (
  echo Set sh = CreateObject("WScript.Shell"^) > "!STARTUP_VBS!"
  echo sh.Run "cmd /c cd /d ""%BOT_DIR%"" && ""!PM2_PATH!"" resurrect", 0, False >> "!STARTUP_VBS!"
  echo    Login: PM2 resurrect.
) else (
  echo Set sh = CreateObject("WScript.Shell"^) > "!STARTUP_VBS!"
  echo sh.Run "cmd /c ""%BOT_DIR%\start_da_bot_direct.bat""", 0, False >> "!STARTUP_VBS!"
  echo    Login: direct Python.
)

if "!IS_ADMIN!"=="1" (
  if "!PM2_HEALTHY!"=="1" if defined PM2_PATH (
    (echo @echo off& echo cd /d "%BOT_DIR%"& echo "!PM2_PATH!" resurrect) > "%BOT_DIR%\start_pm2_resurrect.bat"
  ) else (
    copy /y "%BOT_DIR%\start_da_bot_direct.bat" "%BOT_DIR%\start_pm2_resurrect.bat" >nul
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ac=New-ScheduledTaskAction -Execute 'cmd.exe' -Argument '/c ""%BOT_DIR%\start_pm2_resurrect.bat""'; $tr=New-ScheduledTaskTrigger -AtStartup; $st=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable; $pr=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; Register-ScheduledTask -TaskName 'DA-Bot-PM2-Resurrect' -Action $ac -Trigger $tr -Settings $st -Principal $pr -Force | Out-Null" >nul 2>&1
  if errorlevel 1 (echo    Boot task: failed) else (echo    Boot task: registered)
) else (
  echo    Boot task: skipped (run as Admin)
)

echo.
echo ========================================
echo  Complete [!STARTED!]
if "!HAVE_PM2!"=="1" echo  PM2: pm2 status / pm2 logs da-bot
echo ========================================
pause
