@echo off
setlocal enabledelayedexpansion

REM Set working directory to this script's location
cd /d "%~dp0"

REM Check Administrator status
net session >nul 2>&1
set "IS_ADMIN=0"
if not errorlevel 1 set "IS_ADMIN=1"

echo ========================================
echo  Discord Sheets Bot - PM2 Setup
echo ========================================
echo.
echo This script will:
echo  1. Install Node.js + Python if missing (Admin required for auto-install)
echo  2. Install PM2 if missing
echo  3. Collect your Discord and Google credentials
echo  4. Install Python dependencies
echo  5. Deploy slash commands to Discord
echo  6. Start the bot under PM2 (detached, auto-restart)
echo  7. Register auto-start (boot if admin, login always)
echo.

REM --- Step 0: Node.js ---
echo [0/7] Checking Node.js...
where node >nul 2>&1
if errorlevel 1 (
    if "!IS_ADMIN!"=="1" (
        echo    Node.js not found - installing via winget...
        winget install OpenJS.NodeJS --silent --accept-source-agreements --accept-package-agreements
        if errorlevel 1 (
            echo    winget install failed - trying direct download...
            powershell -Command "try { iwr 'https://nodejs.org/dist/latest/node-v20.11.1-x64.msi' -OutFile '%TEMP%\node.msi' -ErrorAction Stop; Start-Process msiexec -ArgumentList '/i','%TEMP%\node.msi','/quiet','/norestart' -Wait } catch { exit 1 }"
            if errorlevel 1 (
                echo ERROR: Could not install Node.js automatically.
                echo Download Node.js LTS manually from: https://nodejs.org/
                pause
                exit /b 1
            )
        )
        set "PATH=!PATH!;%ProgramFiles%\nodejs"
        where node >nul 2>&1
        if errorlevel 1 (
            echo    Node.js installed but not yet on PATH in this session.
            echo    Please re-run bootstrap.bat once setup completes.
            pause
            exit /b 1
        )
    ) else (
        echo    Node.js not found! Please install Node.js LTS:
        echo      https://nodejs.org/
        echo    (Run this script as Administrator to auto-install.)
        pause
        exit /b 1
    )
)
for /f "delims=" %%v in ('node --version') do set "NODE_VER=%%v"
echo    Node.js !NODE_VER!
echo.

REM --- Step 1: PM2 ---
echo [1/7] Checking PM2...
where pm2 >nul 2>&1
if errorlevel 1 (
    echo    PM2 not found - installing globally...
    npm install -g pm2
    if errorlevel 1 (
        echo ERROR: Failed to install PM2.
        pause
        exit /b 1
    )
)
for /f "delims=" %%v in ('pm2 --version') do set "PM2_VER=%%v"
echo    PM2 !PM2_VER!
for /f "delims=" %%i in ('where pm2.cmd') do set "PM2_PATH=%%i"
echo.

REM --- Step 2: Python ---
echo [2/7] Checking Python...
set "PYTHON_EXE="
where python >nul 2>&1
if errorlevel 1 (
    where python3 >nul 2>&1
    if errorlevel 1 (
        if "!IS_ADMIN!"=="1" (
            echo    Python not found - installing via winget...
            winget install Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
            if errorlevel 1 (
                echo    winget install failed - trying direct download...
                powershell -Command "try { iwr 'https://www.python.org/ftp/python/3.12.3/python-3.12.3-amd64.exe' -OutFile '%TEMP%\python.exe' -ErrorAction Stop; Start-Process '%TEMP%\python.exe' -ArgumentList '/quiet','InstallAllUsers=1','PrependPath=1','Include_test=0' -Wait } catch { exit 1 }"
                if errorlevel 1 (
                    echo ERROR: Could not install Python automatically.
                    echo Download Python 3.12+ manually from: https://www.python.org/downloads/
                    pause
                    exit /b 1
                )
            )
            REM Refresh PATH so this session picks up the new Python
            set "PATH=!PATH!;%ProgramFiles%\Python312;%ProgramFiles%\Python312\Scripts;%LocalAppData%\Programs\Python\Python312;%LocalAppData%\Programs\Python\Python312\Scripts;%ProgramFiles%\Python313;%ProgramFiles%\Python313\Scripts;%LocalAppData%\Programs\Python\Python313;%LocalAppData%\Programs\Python\Python313\Scripts"
            where python >nul 2>&1
            if errorlevel 1 (
                echo    Python installed but not yet on PATH in this session.
                echo    Please re-run bootstrap.bat once setup completes.
                pause
                exit /b 1
            )
        ) else (
            echo    Python not found! Install Python 3.11+ from:
            echo      https://www.python.org/downloads/windows/
            echo    (Run this script as Administrator to auto-install.)
            pause
            exit /b 1
        )
    ) else (
        set "PYTHON_EXE=python3"
    )
) else (
    set "PYTHON_EXE=python"
)
for /f "delims=" %%v in ('!PYTHON_EXE! --version 2^>^&1') do set "PY_VER=%%v"
echo    !PY_VER!
echo.

REM --- Step 3: Config ---
echo [3/7] Checking configuration...
if not exist ".env" (
    echo    No .env found - running configuration wizard...
    !PYTHON_EXE! setup_config.py
    if errorlevel 1 (
        echo ERROR: Configuration setup failed.
        pause
        exit /b 1
    )
) else (
    echo    .env already exists - skipping wizard.
)
echo.

REM --- Step 4: Dependencies ---
echo [4/7] Installing dependencies...
!PYTHON_EXE! -m pip install --upgrade pip >nul 2>&1
!PYTHON_EXE! -m pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)
!PYTHON_EXE! -m pip install tzdata
if errorlevel 1 (
    echo WARNING: Failed to install tzdata. Timezone calculations may fail.
    echo          Continuing anyway...
)
echo.

REM --- Step 5: Deploy commands ---
echo [5/7] Deploying slash commands...
!PYTHON_EXE! deploy_commands.py
if errorlevel 1 (
    echo    WARNING: Command deployment reported an error. Continuing anyway...
)
echo.

REM --- Step 6: Start under PM2 ---
echo [6/7] Starting bot under PM2...
if not exist "logs" mkdir "logs"
pm2 delete da-bot >nul 2>&1
pm2 start ecosystem.config.js
if errorlevel 1 (
    echo ERROR: Failed to start bot under PM2.
    pause
    exit /b 1
)
pm2 save
echo    Bot is now running detached - closing this window will NOT stop it.
echo.

REM --- Step 7: Auto-start ---
echo [7/7] Registering auto-start...
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "STARTUP_VBS=!STARTUP_DIR!\da-bot-autostart.vbs"

REM Always register start-at-login (hidden window, restores saved PM2 processes)
REM The VBS script changes to the project directory before running pm2 resurrect
(
    echo Set sh = CreateObject("WScript.Shell"^)
    echo sh.Run "cmd /c cd /d ""%~dp0"" && ""!PM2_PATH!"" resurrect", 0, False
) > "!STARTUP_VBS!"
echo    Login auto-start: registered (startup folder).

net session >nul 2>&1
if not errorlevel 1 (
    echo    Administrator detected - registering boot-level auto-start via Task Scheduler...
    REM Use Task Scheduler to run pm2 resurrect at system startup
    set "RESURRECT_SCRIPT=%~dp0start_pm2_resurrect.bat"
    (
        echo @echo off
        echo cd /d "%~dp0"
        echo "!PM2_PATH!" resurrect
    ) > "!RESURRECT_SCRIPT!"

    powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $action = New-ScheduledTaskAction -Execute 'cmd' -Argument '/c ""!RESURRECT_SCRIPT!""'; $trigger = New-ScheduledTaskTrigger -AtStartup; $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable; $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; Register-ScheduledTask -TaskName 'DA-Bot-PM2-Resurrect' -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force }"
    if errorlevel 1 (
        echo    WARNING: Task Scheduler registration failed. Login auto-start is still active.
    ) else (
        echo    Boot auto-start: registered via Task Scheduler (^>24/7^).
    )
    echo    Auto-start registered: runs at system boot and login.
) else (
    echo    Auto-start registered: runs when you log into Windows.
    echo    TIP: Re-run bootstrap.bat as Administrator to also start at boot (^>24/7^).
)
echo.

echo ========================================
echo  Setup complete!
echo.
echo  Bot status:   pm2 status
echo  Bot logs:     pm2 logs da-bot
echo  Stop bot:     pm2 stop da-bot
echo  Start bot:    pm2 start da-bot
echo  Restart bot:  pm2 restart da-bot
echo.
echo  bootstrap.bat is the only script you need -
echo  it installs everything and starts the bot.
echo ========================================
pause
