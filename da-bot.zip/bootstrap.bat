@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
if not exist "%ROOT%\logs" mkdir "%ROOT%\logs"
set "BLOG=%ROOT%\logs\bootstrap.log"
echo ========================================>> "%BLOG%"
echo bootstrap %date% %time%>> "%BLOG%"

echo ========================================
echo  DA Bot - Setup / Start
echo ========================================
echo  Folder: %ROOT%
echo  Log:    %ROOT%\logs\bootstrap.log
echo.

echo [1/5] Checking Python...
set "PYEXE="
set "PYARG="
where python >nul 2>&1
if %errorlevel%==0 (set "PYEXE=python"& goto :gotpy)
where py >nul 2>&1
if %errorlevel%==0 (set "PYEXE=py"& set "PYARG=-3"& goto :gotpy)
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"& goto :gotpy)
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (set "PYEXE=%LocalAppData%\Programs\Python\Python311\python.exe"& goto :gotpy)
if exist "%ProgramFiles%\Python312\python.exe" (set "PYEXE=%ProgramFiles%\Python312\python.exe"& goto :gotpy)
echo ERROR: Python 3.11+ not found. Install from https://www.python.org/downloads/
echo [FAIL] python>> "%BLOG%"
pause
exit /b 1

:gotpy
if "%PYARG%"=="-3" ("%PYEXE%" -3 --version) else ("%PYEXE%" --version)
echo [OK] python %PYEXE% %PYARG%>> "%BLOG%"
echo.

echo [2/5] Configuration...
if not exist "%ROOT%\.env" (
  echo    No .env found - running setup_config.py
  if "%PYARG%"=="-3" (call "%PYEXE%" -3 "%ROOT%\setup_config.py") else (call "%PYEXE%" "%ROOT%\setup_config.py")
  if errorlevel 1 (
    echo ERROR: Configuration failed.
    echo [FAIL] config>> "%BLOG%"
    pause
    exit /b 1
  )
) else (
  echo    .env exists.
)
echo [OK] config>> "%BLOG%"
echo.

echo [3/5] Installing dependencies...
if "%PYARG%"=="-3" (call "%PYEXE%" -3 -m pip install --upgrade pip >nul 2>&1) else (call "%PYEXE%" -m pip install --upgrade pip >nul 2>&1)
echo    Installing requirements.txt...
if "%PYARG%"=="-3" (call "%PYEXE%" -3 -m pip install -r "%ROOT%\requirements.txt") else (call "%PYEXE%" -m pip install -r "%ROOT%\requirements.txt")
if errorlevel 1 (
  echo ERROR: pip install failed.
  echo [FAIL] deps>> "%BLOG%"
  pause
  exit /b 1
)
if "%PYARG%"=="-3" (call "%PYEXE%" -3 -m pip install tzdata >nul 2>&1) else (call "%PYEXE%" -m pip install tzdata >nul 2>&1)
echo    Dependencies OK.
echo [OK] deps>> "%BLOG%"
echo.

echo [4/5] Deploying slash commands - optional...
echo [INFO] deploy>> "%BLOG%"
if exist "%ROOT%\deploy_commands.py" (
  echo    Running deploy_commands.py - errors here do not stop startup
  if "%PYARG%"=="-3" (call "%PYEXE%" -3 "%ROOT%\deploy_commands.py") else (call "%PYEXE%" "%ROOT%\deploy_commands.py")
  if errorlevel 1 (
    echo    WARNING: Deploy failed. Bot will still try to start.
    echo [WARN] deploy>> "%BLOG%"
  ) else (
    echo    Deploy finished.
    echo [OK] deploy>> "%BLOG%"
  )
) else (
  echo    deploy_commands.py not found - skipping.
)
echo.

echo [5/5] Starting bot...
echo [INFO] start>> "%BLOG%"

echo    Preflight...
if "%PYARG%"=="-3" (
  call "%PYEXE%" -3 -c "import config, discord, requests" >"%ROOT%\logs\preflight.log" 2>&1
) else (
  call "%PYEXE%" -c "import config, discord, requests" >"%ROOT%\logs\preflight.log" 2>&1
)
if errorlevel 1 (
  echo ERROR: Preflight failed. Required modules or config missing.
  echo --- logs\preflight.log ---
  type "%ROOT%\logs\preflight.log"
  echo --------------------------
  echo [FAIL] preflight>> "%BLOG%"
  pause
  exit /b 1
)
echo    Preflight OK.
echo [OK] preflight>> "%BLOG%"

REM Stop existing da-bot managed by PM2 (best effort)
where pm2 >nul 2>&1
if %errorlevel%==0 (
  call pm2 delete da-bot >nul 2>&1
)

REM Detect existing main.py (avoid duplicates)
powershell -NoProfile -Command "$r=Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" -EA SilentlyContinue | Where-Object { $_.CommandLine -match 'main\.py' }; if($r){exit 0}else{exit 1}" >nul 2>&1
if %errorlevel%==0 (
  echo    main.py is already running. Not starting a duplicate.
  echo [OK] already>> "%BLOG%"
  goto :done
)

echo    Launching main.py in background...
if "%PYARG%"=="-3" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$wd='%ROOT%'; $out=Join-Path $wd 'logs\out.log'; $errf=Join-Path $wd 'logs\err.log'; $p=Start-Process -FilePath 'py' -ArgumentList @('-3','main.py') -WorkingDirectory $wd -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $errf -PassThru -EA Stop; Start-Sleep 5; if(Get-Process -Id $p.Id -EA SilentlyContinue){exit 0}else{exit 1}" >nul 2>&1
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$wd='%ROOT%'; $out=Join-Path $wd 'logs\out.log'; $errf=Join-Path $wd 'logs\err.log'; $p=Start-Process -FilePath '%PYEXE%' -ArgumentList @('main.py') -WorkingDirectory $wd -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $errf -PassThru -EA Stop; Start-Sleep 5; if(Get-Process -Id $p.Id -EA SilentlyContinue){exit 0}else{exit 1}" >nul 2>&1
)

if errorlevel 1 (
  echo    Background start failed or exited early. Recent logs\err.log:
  if exist "%ROOT%\logs\err.log" (
    echo    --------------------------
    powershell -NoProfile -Command "Get-Content '%ROOT%\logs\err.log' -Tail 60 -EA SilentlyContinue"
    echo    --------------------------
  )
  echo    Manual test (shows live errors):
  if "%PYARG%"=="-3" (echo      py -3 main.py) else (echo      "%PYEXE%" main.py)
  echo [FAIL] start>> "%BLOG%"
  pause
  exit /b 1
)

echo    Bot started in background.
echo [OK] started>> "%BLOG%"

:done
echo.
echo ========================================
echo  Setup finished
echo  Logs: %ROOT%\logs\bootstrap.log
echo        %ROOT%\logs\err.log
echo ========================================
echo [OK] done>> "%BLOG%"
pause
exit /b 0
