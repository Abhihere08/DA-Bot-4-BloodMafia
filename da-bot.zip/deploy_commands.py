"""
Deploy / sync slash commands to the configured Discord guild (or globally).

Usage:
    python deploy_commands.py
"""
import asyncio
import os
import sys

# Ensure the script's directory is in sys.path so imports work
# regardless of the working directory
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

import discord
from discord.ext import commands

from commands import command_list
from config import ALL_GUILD_IDS, DISCORD_TOKEN
from utils.logger import logger


async def _deploy():
    intents = discord.Intents.default()
    intents.members = True
    bot = commands.Bot(command_prefix="!", intents=intents)

    async def _sync_and_close():
        await bot.wait_until_ready()
        if ALL_GUILD_IDS:
            # Add commands, clear global to prevent duplicates, then sync guild-only
            for cmd in command_list:
                bot.tree.add_command(cmd)
            bot.tree.clear_commands(guild=None)
            await bot.tree.sync()  # clears global commands from Discord
            for cmd in command_list:
                bot.tree.add_command(cmd)
            total = 0
            for gid in ALL_GUILD_IDS:
                bot.tree.copy_global_to(guild=discord.Object(id=gid))
                synced = await bot.tree.sync(guild=discord.Object(id=gid))
                total += len(synced)
                logger.info("Deployed %d slash command(s) to guild %s", len(synced), gid)
            logger.info("Total: %d command(s) across %d guild(s)", total, len(ALL_GUILD_IDS))
        else:
            for cmd in command_list:
                bot.tree.add_command(cmd)
            synced = await bot.tree.sync()
            logger.info("Deployed %d global slash command(s) (may take up to 1 h to propagate)", len(synced))
        await bot.close()

    asyncio.create_task(_sync_and_close())
    await bot.start(DISCORD_TOKEN)


def main():
    asyncio.run(_deploy())


if __name__ == "__main__":
    main()
