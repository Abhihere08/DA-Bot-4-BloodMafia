"""List all channels the bot has access to — helps find notification channel IDs.

Usage:
    python list_channels.py
"""
import asyncio
import os

import discord
from dotenv import load_dotenv


async def main():
    load_dotenv()
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        print("ERROR: DISCORD_TOKEN not found in .env")
        return

    intents = discord.Intents.default()
    intents.guilds = True
    intents.messages = True
    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(f"\nLogged in as: {client.user}")
        print(f"Serving {len(client.guilds)} guild(s):\n")
        for guild in client.guilds:
            print(f"  Guild: {guild.name} (ID: {guild.id})")
            text_channels = [c for c in guild.text_channels]
            for ch in text_channels:
                print(f"    • #{ch.name} (ID: {ch.id})")
            print()

            # Print roles for the notification channel (first text channel)
            # or all channels if none match
            notify_channel_id = int(os.getenv("NOTIFICATION_CHANNEL_ID", "") or 0)
            target_channel = None
            for c in guild.text_channels:
                if c.id == notify_channel_id:
                    target_channel = c
                    break
            if not target_channel and text_channels:
                target_channel = text_channels[0]

            if target_channel:
                # Get roles that can see this channel
                overwrites = target_channel.overwrites
                readable_roles = []
                for target, overwrite in overwrites.items():
                    if target == guild.default_role:
                        if overwrite.read_messages is not False:
                            readable_roles.append(("@everyone", target.id))
                    elif isinstance(target, discord.Role):
                        if overwrite.read_messages is not False:
                            readable_roles.append((target.name, target.id))

                print(f"    Roles with access to #{target_channel.name}:")
                for role_name, role_id in readable_roles:
                    print(f"      • {role_name} (ID: {role_id})")
                print()
            else:
                print("    No text channels found.\n")
        await client.close()

    await client.start(token)


if __name__ == "__main__":
    asyncio.run(main())
