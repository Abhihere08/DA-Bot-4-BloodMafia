import discord
from discord import Interaction, app_commands

from utils.discord_utils import link_member
from utils.logger import logger


@app_commands.command(name="da-map", description="Link a Discord user to a game name from the Google Sheet")
@app_commands.describe(
    user="Discord user to link (select from the picker)",
    game_name="Name exactly as it appears in the Google Sheet",
)
async def command(interaction: Interaction, user: discord.User, game_name: str):
    link_member(game_name, user.id)
    logger.info("User %s linked '%s' to Discord %s", interaction.user, game_name, user.id)
    await interaction.response.send_message(
        f"{user.mention} is now linked to **{game_name}** ✅\n"
        "They will be @mentioned in future DA assignment posts."
    )
