"""Persistent mapping between Google Sheet names and Discord user IDs.

The mapping is stored in ``mappings.json`` in the project root so that
once a sheet name is linked to a Discord user, the association survives
bot restarts.
"""
import json
import os

from utils.logger import logger

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MAPPINGS_FILE = os.path.join(_PROJECT_ROOT, "mappings.json")

# name (normalised, lower-cased) -> discord user id (str)
_mappings: dict[str, str] = {}


def _key(name: str) -> str:
    return name.strip().lower() if name else ""


def _load() -> None:
    global _mappings
    try:
        with open(_MAPPINGS_FILE, encoding="utf-8") as fh:
            _mappings = json.load(fh)
    except FileNotFoundError:
        _mappings = {}
    except (json.JSONDecodeError, OSError) as err:
        logger.error("Failed to load mappings: %s", err)
        _mappings = {}


def _save() -> None:
    try:
        with open(_MAPPINGS_FILE, "w", encoding="utf-8") as fh:
            json.dump(_mappings, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save mappings: %s", err)


def get_mapping(name: str):
    """Return the stored Discord user-id for *name*, or ``None``."""
    if not name:
        return None
    return _mappings.get(_key(name))


def save_mapping(name: str, user_id) -> None:
    """Persist *name* -> *user_id* so the mapping survives restarts."""
    key = _key(name)
    if key:
        _mappings[key] = str(user_id)
        _save()
        logger.info("Mapped '%s' -> %s", name, user_id)


def remove_mapping(name: str) -> bool:
    """Remove a stored mapping.  Returns ``True`` if one was removed."""
    key = _key(name)
    if key in _mappings:
        del _mappings[key]
        _save()
        logger.info("Removed mapping for '%s'", name)
        return True
    return False


def get_all_mappings() -> dict:
    """Return a shallow copy of all mappings."""
    return dict(_mappings)


# Load at import time
_load()
