# Discord x Google Sheets Bot (Python)

A Discord bot that reads from and syncs with a Google Sheet — plus sends automatic notifications when new rows appear.

## Features

| Command                    | Description                                              |
| -------------------------- | -------------------------------------------------------- |
| `/status`                  | Show Discord & Sheets connection status                  |
| `/send-da-assignments`     | Fetch DA assignments & `@mention` every member with role |
| `/mention-all`             | Mention every member listed in a DA sheet                |
| `/link`                    | Link a Discord user to a game name (persists across restarts) |
| `/unlink`                  | Remove a saved name-to-Discord mapping                   |
| `/auto-scan-da`            | Scan a DA sheet and auto-map members to Discord users    |
| `/new-da`                  | Manually announce a new DA event with guild tags & slot info |
| `/set-da-tz`               | Set your timezone for DA slot time display               |
| `/da-slots-time`           | Show all 8 DA slot times in local time                   |
| `/set-my-preset`           | Save your preset under B\|M or b\|m team                  |
| `/da-preset`               | Display all presets for a guild                          |
| `/remove-my-preset`        | Remove a saved preset by name                            |

**Automatic features:**
- Polls the sheet every 5 minutes and sends a Discord message when new rows are detected
- Polls for new DA sheets every 30 seconds and auto-announces assignments 1 hour before slot starts
- Guild-tagged announcements (`@B|M Members 👑` for Big BM, `@b|M Members 🦅` for Little bM) instead of `@everyone`
- Multi-guild support: configure multiple notification channels and guild IDs for cross-server announcements

---

## Quick Start (Windows)

**Requirements:** Windows 10/11 with Administrator access (for auto-install of Node.js + Python).

Double-click **`bootstrap.bat`** to:

1. Install Node.js + Python automatically (via winget, with direct-download fallback) if missing
2. Install PM2 globally if missing
3. Interactively collect your Discord & Google credentials and write `.env`
4. Install Python dependencies
5. Deploy slash commands
6. Start the bot under PM2 (detached — closing any console window will NOT stop it)
7. Register auto-start: at login (always) and at boot (when run as Administrator)

The bot then runs 24/7, restarts automatically if it crashes, and starts again after a reboot.

**PM2 commands:**

| Command | Action |
| ------- | ------ |
| `pm2 status` | Check bot status |
| `pm2 logs da-bot` | View live logs |
| `pm2 stop da-bot` / `pm2 start da-bot` / `pm2 restart da-bot` | Control the bot |

`start_bot.bat` / `stop_bot.bat` wrap the start/stop commands. `install_autostart.bat` (run as Administrator) re-registers boot-time auto-start.

---

## `/send-da-assignments`

This command auto-detects the **leftmost** sheet tab whose name matches `BIG BM` or `LITTLE BM`, reads the assignment layout, and posts a message that:

1. Mentions every member with `@mention (role)` by resolving their sheet name to a Discord user — **auto-mapping is saved to `mappings.json`** so the link persists across restarts
2. Shows the fort/position name (e.g. **🏰 Citadel 1**)
3. Includes an optional `sheet` parameter with autocomplete to select a specific tab

When the sheet changes (new DA date / updated member names), run the command again — it always fetches the latest data live from Google Sheets.

### Sheet selection

Both `/send-da-assignments` and `/mention-all` accept an optional `sheet` parameter with autocomplete. Tab-complete to select from all DA-related tabs (e.g., `BIG BM 10.02.26`, `LITTLE bM 10.02.26`). If omitted, the bot auto-detects the leftmost assignment sheet.

| Command | Description |
|---------|-------------|
| `/link @user game_name` | Manually link a Discord user to a game name as it appears in the sheet |
| `/unlink game_name` | Remove a previously-saved link |
| `/mention-all` (optional sheet) | Mention every member found in a DA sheet |
| `/auto-scan-da` (optional sheet) | Scan sheet & auto-map members to Discord users; shows unmapped |
| `/new-da` (optional sheet) | Manually announce a new DA event with guild tags & slot time |
| `/set-da-tz` | Set your timezone for DA slot time display (optional override) |
| `/da-slots-time` (optional date) | Show all 8 DA slot times in local time (Discord auto-local timestamps) |
| `/set-my-preset` (name, guild, preset) | Save your preset under B|M or b|m team |
| `/da-preset` (guild) | Display all presets for a guild (B|M or b|m) |
| `/remove-my-preset` (guild, name) | Remove a saved preset by name |

**Auto-Announcement Scheduler:**
- Polls the spreadsheet every 30 seconds for new DA sheet tabs (BIG BM, LITTLE bM)
- When a new future sheet is detected, automatically sends the "new-DA" announcement with guild-specific tags (`@B|M Members 👑` for Big BM, `@b|M Members 🦅` for Little BM) and registration time
- Schedules a DA assignment reminder 2 hours before the slot starts (1 hour before registration closes)
- Registration window: opens 25 hours before slot starts, closes 1 hour before slot (24-hour registration period + 1h gap before slot per timing pattern)
- Time displayed in Discord's `<t:TIMESTAMP:t>` format — auto-renders in each viewer's local timezone
- Announced sheets are tracked in `da_announced.json` to avoid duplicates

Links are stored in `mappings.json` (project root). On each `/send-da-assignments` and `/mention-all`, the bot first checks saved mappings, then live-guild lookups (display name, username, nickname, partial matches), and **auto-saves** any new matches it finds.

---

## Setup Guide

### 1. Create a Discord Bot

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Click **New Application** → give it a name → **Create**
3. Go to **Bot** → click **Add Bot**
4. Copy the **Token** → `DISCORD_TOKEN`
5. Under **Privileged Gateway Intents**, enable:
   - **Server Members Intent**
   - **Message Content Intent**
   6. Go to **OAuth2 → URL Generator**:
      - Scopes: `bot`, `applications.commands`
      - Bot Permissions: `Send Messages`, `Embed Links`, `Read Message History`
   6. Open the generated URL and invite the bot to your server
   7. Right-click your notification channel → **Copy Channel ID** → `NOTIFICATION_CHANNEL_ID` (optional — only for auto new-row notifications)

### 2. Set Up Google Sheets

1. Open your Google Sheet
2. **Share** it with **"Anyone with the link can view"** (no service account needed)
3. Copy the Sheet **URL** or **ID** from the URL → `GOOGLE_SHEET_ID`

### 3. Configure

**Option A — Quick (Windows):**

```bat
:: Run as Administrator
bootstrap.bat
```

**Option B — Manual:**

```bash
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate      # macOS/Linux

pip install -r requirements.txt

# Interactive wizard (writes .env for you):
python setup_config.py

# Or copy & edit manually:
cp .env.example .env
```

#### Multi-Guild / Multi-Channel Configuration

The bot supports announcing to multiple guilds/channels:

```env
# Single guild (backward compatible):
NOTIFICATION_CHANNEL_ID=123456789012345678
DISCORD_GUILD_ID=111222333444555666

# Multiple guilds:
NOTIFICATION_CHANNEL_IDS=guild1-channel-id,guild2-channel-id
DISCORD_GUILD_IDS=guild1-id,guild2-id
```

Sheet tabs are prefixed with `BIG BM` or `LITTLE bM` to identify the team. The bot automatically uses the correct guild tag:
- `@B|M Members 👑` for Big BM sheets
- `@b|M Members 🦅` for Little BM sheets


### 4. Deploy & Run

```bash
# Deploy slash commands (run once or after adding new commands)
python deploy_commands.py

# Start the bot under PM2 (detached, auto-restart)
pm2 start ecosystem.config.js
pm2 save
```

Or simply run `bootstrap.bat` — it does all of the above and registers auto-start.

---

## Project Structure

```
Project r/
├── config.py              # Environment-based configuration loader
├── sheets.py              # Google Sheets API service (async)
├── bot.py                 # discord.py client setup & event wiring
├── main.py                # Entry point
├── deploy_commands.py     # Register slash commands with Discord
├── setup_config.py        # Interactive credentials wizard (called by bootstrap.bat)
├── ecosystem.config.js    # PM2 process config (detached, auto-restart)
├── bootstrap.bat          # One-click setup: config, deps, deploy, PM2 start, auto-start
├── install_autostart.bat  # Re-register boot-time auto-start (run as Administrator)
├── start_bot.bat          # Start the bot under PM2
├── stop_bot.bat           # Stop the bot
├── pyproject.toml         # Ruff linter config
├── requirements.txt       # Python dependencies
├── .env.example           # Environment variable template
├── mappings.json          # Persistent name -> Discord ID links (auto-created)
├── tz_preferences.json    # User timezone preferences (auto-created)
├── da_announced.json      # Track announced sheets (auto-created)
├── da_presets.json        # Guild presets (auto-created)
├── commands/
│   ├── __init__.py        # Command registry
│   ├── status.py          # /status
│   ├── link.py            # /link  (name -> Discord user)
│   ├── unlink.py          # /unlink
│   ├── mention_all.py     # /mention-all
│   ├── auto_scan_da.py    # /auto-scan-da
│   ├── da_slots_time.py   # /da-slots-time
│   ├── new_da.py          # /new-da
│   ├── set_da_tz.py       # /set-da-tz
│   ├── set_my_preset.py   # /set-my-preset
│   ├── da_preset.py       # /da-preset
│   ├── remove_my_preset.py # /remove-my-preset
│   └── send_da_assignments.py  # /send-da-assignments
├── events/
│   ├── __init__.py
│   ├── ready.py           # on_ready
│   └── guild_member_add.py  # Log member joins
└── utils/
    ├── __init__.py
    ├── logger.py          # UTC timestamped logger
    ├── scheduler.py       # Sheet-polling scheduler
    ├── da_scheduler.py    # Auto-announcement scheduler (30s + 1hr pre-slot)
    ├── discord_utils.py   # Member lookup + persistent mention mapping
    ├── mapping.py         # mappings.json load/save
    ├── tz_prefs.py        # Timezone preferences storage
    └── slot_utils.py      # DA slot detection & timezone formatting
```

---

## Troubleshooting

| Issue | Fix |
| --- | --- |
| `Missing required env variable` | Fill in all values in `.env` |
| Commands not showing | Run `python deploy_commands.py` and wait ~1 minute |
| Bot not detecting new rows | Notifications are always on — check sheet tab name and `NOTIFICATION_CHANNEL_ID` in `.env` |
| No DA announcements | Ensure `NOTIFICATION_CHANNEL_ID` is set in `.env`; use `list_channels.py` to find channel IDs |
| Names not mentioned with `@` | Ensure the bot has the **Server Members Intent** enabled; use `/link` to manually bind a name if auto-detection fails |
| Guild sync returns 0 | Run `python deploy_commands.py` to force a fresh sync |
| `mappings.json` issues | Delete the file to reset all name links; re-run `/send-da-assignments` to re-discover |
| `Node.js not found` | Install Node.js LTS from https://nodejs.org/ — PM2 requires it |
| Bot dies when closing CMD | It must run under PM2 — run `bootstrap.bat` (or `pm2 start ecosystem.config.js`) |
| Bot not auto-starting | Run `bootstrap.bat` (or `install_autostart.bat`) as Administrator for boot-time start |
| `pm2` not recognized | Run `npm install -g pm2`, then `pm2 save` |
