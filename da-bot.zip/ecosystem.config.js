const path = require("path");

module.exports = {
  apps: [
    {
      name: "da-bot",
      script: path.join(__dirname, "main.py"),
      interpreter: process.env.PM2_PYTHON || "python",
      cwd: __dirname,
      autorestart: true,
      max_restarts: 10,
      restart_delay: 5000,
      min_uptime: "10s",
      watch: false,
      windowsHide: true,
      merge_logs: true,
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      error_file: path.join(__dirname, "logs", "err.log"),
      out_file: path.join(__dirname, "logs", "out.log"),
    },
  ],
};
