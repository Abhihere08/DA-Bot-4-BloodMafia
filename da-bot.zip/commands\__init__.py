from . import (
    auto_scan_da,
    da_preset,
    da_slots_time,
    link,
    mention_all,
    new_da,
    remove_my_preset,
    send_da_assignments,
    set_da_tz,
    set_my_preset,
    status,
    stop_da,
    unlink,
)

command_list = [
    status.command,
    send_da_assignments.command,
    link.command,
    mention_all.command,
    auto_scan_da.command,
    new_da.command,
    set_da_tz.command,
    unlink.command,
    da_slots_time.command,
    set_my_preset.command,
    da_preset.command,
    remove_my_preset.command,
    stop_da.command,
    stop_da.start_command,
]

__all__ = ["command_list"]
