from discord import Interaction, app_commands

from config import ALL_NOTIFICATION_CHANNELS


@app_commands.command(name="da-message", description="Send a custom message to all DA notification channels")
@app_commands.describe(
    message="The message to send to notification channels"
)
@app_commands.checks.has_permissions(administrator=True)
async def command(interaction: Interaction, message: str):
    """Send a custom message to all configured notification channels."""
    await interaction.response.defer(ephemeral=True)

    if not ALL_NOTIFICATION_CHANNELS:
        await interaction.edit_original_response(
            content="❌ No notification channels configured."
        )
        return

    bot = interaction.client
    sent_count = 0
    for channel_id in ALL_NOTIFICATION_CHANNELS:
        channel = bot.get_channel(channel_id)
        if channel:
            try:
                await channel.send(content=message)
                sent_count += 1
            except Exception as err:
                await interaction.edit_original_response(
                    content=f"❌ Failed to send to channel {channel_id}: {err}"
                )
                return
        else:
            await interaction.edit_original_response(
                content=f"❌ Channel {channel_id} not found."
            )
            return

    await interaction.edit_original_response(
        content=f"✅ Message sent to {sent_count} notification channel(s)."
    )
