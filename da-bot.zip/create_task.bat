@echo off
schtasks /create /tn "DA-Bot-PM2-Resurrect" /tr "C:\Users\Dell\Desktop\Project r\start_pm2_resurrect.bat" /sc onstart /ru SYSTEM /rl HIGHEST /f 2>&1
schtasks /query /tn "DA-Bot-PM2-Resurrect" /fo LIST 2>&1
pause
