@echo off
cd /d "%~dp0"
"C:\Users\Dell\AppData\Roaming\npm\pm2.cmd" resurrect

