"""Persistent storage for DA presets (name -> preset value per guild)."""
import json
import os

from utils.logger import logger

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PRESETS_FILE = os.path.join(_PROJECT_ROOT, "da_presets.json")

# Guild identifiers used as top-level keys
GUILD_BIG = "B|M"
GUILD_LITTLE = "b|M"
GUILD_CHOICES = [GUILD_BIG, GUILD_LITTLE]

_presets: dict[str, dict[str, str]] = {}


def _load_presets() -> None:
    global _presets
    try:
        with open(_PRESETS_FILE, encoding="utf-8") as fh:
            _presets = json.load(fh)
    except (FileNotFoundError, json.JSONDecodeError):
        _presets = {}


def _save_presets() -> None:
    try:
        with open(_PRESETS_FILE, "w", encoding="utf-8") as fh:
            json.dump(_presets, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save presets: %s", err)


def save_preset(guild: str, name: str, preset: str) -> None:
    """Save or update a preset for *name* under *guild*."""
    _load_presets()
    if guild not in _presets:
        _presets[guild] = {}
    _presets[guild][name] = preset
    _save_presets()


def get_presets(guild: str) -> dict[str, str]:
    """Return all name→preset mappings for *guild*."""
    _load_presets()
    return _presets.get(guild, {})


def clear_preset(guild: str, name: str) -> bool:
    """Remove a preset entry. Returns True if something was removed."""
    _load_presets()
    if guild in _presets and name in _presets[guild]:
        del _presets[guild][name]
        if not _presets[guild]:
            del _presets[guild]
        _save_presets()
        return True
    return False


# Load on import
_load_presets()
