from __future__ import annotations

from discord import Interaction, app_commands

from utils.logger import logger
from utils.presets import GUILD_BIG, clear_preset

_GUILD_CHOICE = [
    app_commands.Choice(name="B|M", value=GUILD_BIG),
    app_commands.Choice(name="b|M", value="b|M"),
]


@app_commands.command(
    name="da-remove-preset",
    description="Remove a saved preset by name for a guild",
)
@app_commands.describe(
    guild_choice="Which team/guild the preset belongs to",
    name="The name used when saving the preset",
)
@app_commands.choices(
    guild_choice=_GUILD_CHOICE,
)
async def command(
    interaction: Interaction,
    guild_choice: str,
    name: str,
):
    removed = clear_preset(guild_choice, name)
    if removed:
        logger.info("Preset removed by %s: name=%s, guild=%s", interaction.user, name, guild_choice)
        await interaction.response.send_message(
            content=f"✅ Removed preset for **{name}** under **{guild_choice}** team.",
            ephemeral=True,
        )
    else:
        await interaction.response.send_message(
            content=f"⚠️ No preset found for **{name}** under **{guild_choice}** team.\n"
            f"Check existing presets with `/da-presets guild:{guild_choice}`.",
            ephemeral=True,
        )


__all__ = ["command"]
