param([string]$BotDir,[string]$PythonCmd)
$ErrorActionPreference = "Stop"
$out = Join-Path $BotDir "logs\out.log"
$err = Join-Path $BotDir "logs\err.log"
if ($PythonCmd -eq "py -3") { $exe = "py"; $a = @("-3","main.py") }
elseif ($PythonCmd -eq "python") { $exe = "python"; $a = @("main.py") }
else { $exe = $PythonCmd; $a = @("main.py") }
$p = Start-Process -FilePath $exe -ArgumentList $a -WorkingDirectory $BotDir -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
Start-Sleep -Seconds 3
$alive = Get-Process -Id $p.Id -ErrorAction SilentlyContinue
if ($alive) { exit 0 } else { exit 1 }
