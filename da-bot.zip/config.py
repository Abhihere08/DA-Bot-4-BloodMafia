import os
from dotenv import load_dotenv

load_dotenv()


def _required(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Missing required env variable: {key}")
    return val.strip()


def _optional_int(key: str, default: int) -> int:
    val = os.getenv(key)
    if not val:
        return default
    return int(val)


def _extract_sheet_id(url_or_id: str) -> str:
    """Extract the Google Sheet ID from a URL or return the raw ID."""
    if not url_or_id:
        return ""
    if "docs.google.com/spreadsheets/d/" in url_or_id:
        after = url_or_id.split("/d/")[1]
        return after.split("/")[0].split("?")[0].split("#")[0]
    return url_or_id


# --- Required ---
DISCORD_TOKEN: str = _required("DISCORD_TOKEN")
_raw_sheet: str = _required("GOOGLE_SHEET_ID").strip()
GOOGLE_SHEET_ID: str = _extract_sheet_id(_raw_sheet)

# --- Optional ---
_raw_channels: str = os.getenv("NOTIFICATION_CHANNEL_ID", "")
NOTIFICATION_CHANNEL_IDS: list[int] = [
    int(c.strip()) for c in _raw_channels.split(",") if c.strip()
]
NOTIFICATION_CHANNEL_ID: int | None = (
    NOTIFICATION_CHANNEL_IDS[0] if NOTIFICATION_CHANNEL_IDS else None
)

_raw_guilds: str = os.getenv("DISCORD_GUILD_ID", "")
DISCORD_GUILD_IDS: list[int] = [
    int(g.strip()) for g in _raw_guilds.split(",") if g.strip()
]

POLL_INTERVAL_MS: int = _optional_int("POLL_INTERVAL_MS", 300000)

ALL_NOTIFICATION_CHANNELS: list[int] = NOTIFICATION_CHANNEL_IDS
ALL_GUILD_IDS: list[int] = DISCORD_GUILD_IDS

# --- Game-specific constants ---
BIG_BM_ROLE_ID: int = 1358605559326052680
LITTLE_BM_ROLE_ID: int = 1358605559326052681

DA_SLOTS: dict[int, tuple[str, str]] = {
    1: ("07:00", "08:00"),
    2: ("10:00", "11:00"),
    3: ("13:00", "14:00"),
    4: ("16:00", "17:00"),
    5: ("19:00", "20:00"),
    6: ("22:00", "23:00"),  # Next day (end rolls past UTC midnight)
    7: ("01:00", "02:00"),  # Next day
    8: ("04:00", "05:00"),  # Next day
}

# Patterns used to auto-detect DA sheet tabs by name.
DA_SHEET_PATTERNS: tuple[str, ...] = (
    "BIG BM", "LITTLE BM", "LITTLR BM", "BIG B|M", "LITTLE B|M", "Slot",
)

# Keywords used for position classification in DA sheets.
POSITION_KEYWORDS: tuple[str, ...] = (
    "citadel", "transporter", "ancient remains", "hot springs",
)
