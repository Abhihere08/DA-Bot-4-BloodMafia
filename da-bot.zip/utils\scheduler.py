import asyncio

from sheets import auto_detect_da_sheet, get_row_count, get_rows
from utils.logger import logger

notifications_enabled = True
_last_known_row_count = 0
_task = None
_sheet_tab = None


def toggle_notifications() -> bool:
    global notifications_enabled
    notifications_enabled = not notifications_enabled
    return notifications_enabled


def is_notifications_enabled() -> bool:
    return notifications_enabled


async def _poll_loop(interval_ms: int, on_new_rows):
    global _last_known_row_count
    while True:
        await asyncio.sleep(interval_ms / 1000)
        if not notifications_enabled:
            continue
        try:
            current = await get_row_count(_sheet_tab)
            if current > _last_known_row_count:
                all_rows = await get_rows(_sheet_tab)
                new_rows = all_rows[_last_known_row_count:current]
                _last_known_row_count = current
                logger.info("Detected %d new row(s)", len(new_rows))
                await on_new_rows(new_rows)
        except Exception as err:
            logger.error("Polling error: %s", err)


async def _bootstrap(interval_ms, on_new_rows):
    global _last_known_row_count, _sheet_tab
    try:
        _sheet_tab = await auto_detect_da_sheet()
        if not _sheet_tab:
            _sheet_tab = "Sheet1"
        _last_known_row_count = await get_row_count(_sheet_tab)
        logger.info("Scheduler seeded with %d existing rows", _last_known_row_count)
    except Exception as err:
        logger.error("Failed to seed row count: %s", err)
    await _poll_loop(interval_ms, on_new_rows)


def start_polling(interval_ms: int, on_new_rows):
    global _task
    _task = asyncio.create_task(_bootstrap(interval_ms, on_new_rows))
    logger.info("Scheduler started - polling every %ss", interval_ms / 1000)


def stop_polling():
    global _task
    if _task:
        _task.cancel()
        _task = None
        logger.info("Scheduler stopped")
