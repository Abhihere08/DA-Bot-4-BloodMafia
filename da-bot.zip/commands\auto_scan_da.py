from __future__ import annotations

from discord import Interaction, app_commands

from commands.mention_all import _extract_all_names, _sheet_autocomplete
from sheets import auto_detect_da_sheet, get_range, get_sheet_names
from utils.discord_utils import find_member, mention_member
from utils.logger import logger
from utils.mapping import get_all_mappings, save_mapping
from utils.slot_utils import format_slot_time_with_tz, get_sheet_date, parse_slot_number
from utils.tz_prefs import get_user_tz


@app_commands.command(
    name="da-auto-scan",
    description="Scan a DA sheet and auto-map members to Discord users",
)
@app_commands.describe(
    sheet="DA sheet tab (leave blank to auto-detect)"
)
@app_commands.autocomplete(sheet=_sheet_autocomplete)
async def command(interaction: Interaction, sheet: str | None = None):
    await interaction.response.defer()

    try:
        # --- Resolve sheet tab ---
        sheet_tab = sheet
        if not sheet_tab:
            sheet_names = await get_sheet_names()
            sheet_tab = await auto_detect_da_sheet(sheet_names)
            if not sheet_tab and sheet_names:
                sheet_tab = sheet_names[0]

        if not sheet_tab:
            return await interaction.edit_original_response(
                content="⚠️ Could not auto-detect a DA sheet tab."
            )

        # --- Fetch & parse ---
        rows = await get_range(f"'{sheet_tab}'")
        if not rows:
            return await interaction.edit_original_response(
                content=f"⚠️ No data found in sheet tab `{sheet_tab}`."
            )

        names = _extract_all_names(rows)
        if not names:
            return await interaction.edit_original_response(
                content=f"⚠️ No member names found in `{sheet_tab}`."
            )

        guild = interaction.guild

        # --- Scan & map ---
        mapped: list[tuple[str, str]] = []
        unmapped: list[str] = []

        for name in names:
            mention = mention_member(guild, name)
            if mention.startswith("<@"):
                mapped.append((name, mention))
            else:
                # Try one more live lookup
                member = find_member(guild, name)
                if member is not None:
                    save_mapping(name, member.id)
                    mapped.append((name, member.mention))
                else:
                    unmapped.append(name)

        matched_count = len(mapped)
        total = len(names)

        # --- Parse slot info ---
        title_row = rows[0][0] if rows and rows[0] else ""
        slot_num = parse_slot_number(title_row)
        slot_date = get_sheet_date(title_row, sheet_tab)
        if slot_num:
            user_tz = get_user_tz(interaction.user.id)
            slot_time_str = format_slot_time_with_tz(slot_num, slot_date, user_tz)
        else:
            slot_time_str = "Unknown slot"

        # --- Build output ---
        lines: list[str] = []
        lines.append(f"**🔍 Auto-Scan Results for `{sheet_tab}`**")
        lines.append("")
        lines.append(f"📋 **{slot_time_str}**")
        lines.append("")
        lines.append(f"Total names found: **{total}** | Mapped: **{matched_count}** | Not mapped: **{len(unmapped)}**")
        lines.append("")

        if mapped:
            lines.append("**✅ Mapped members:**")
            lines.append("")
            for name, mention in mapped:
                lines.append(f"  • {mention} ← `{name}`")
            lines.append("")

        if unmapped:
            lines.append("**❌ Not mapped (use `/da-map @user game_name`):**")
            lines.append("")
            lines.append("  " + ", ".join(f"`{n}`" for n in unmapped))
            lines.append("")

        # Also show existing saved mappings
        saved = get_all_mappings()
        if saved:
            saved_in_sheet = {n: m for n, m in saved.items() if any(n.lower() == s.lower() for s in names)}
            if saved_in_sheet and not mapped:
                lines.append("**💾 Existing saved mappings:**")
                lines.append("")
                for name, mid in saved_in_sheet.items():
                    member = guild.get_member(int(mid)) if mid.isdigit() else None
                    tag = member.mention if member else f"<@{mid}>"
                    lines.append(f"  • {tag} ← `{name}`")
                lines.append("")

        full_msg = "\n".join(lines)

        await interaction.edit_original_response(content=full_msg[:2000])

        logger.info(
            "Auto-scan completed by %s on sheet '%s': %d/%d mapped",
            interaction.user,
            sheet_tab,
            matched_count,
            total,
        )

    except Exception as err:
        logger.error("Error in /da-auto-scan: %s", err)
        try:
            await interaction.edit_original_response(
                content=f"❌ Error: {err}"
            )
        except Exception:
            await interaction.followup.send(
                content=f"❌ Error: {err}", ephemeral=True
            )
