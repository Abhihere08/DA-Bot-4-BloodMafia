schtasks /create /tn "DA-Bot-PM2-Resurrect" /tr "\"C:\Users\Dell\Desktop\Project r\start_pm2_resurrect.bat\"" /sc onstart /ru SYSTEM /rl HIGHEST /f
echo EXIT_CODE=%ERRORLEVEL%
schtasks /query /tn "DA-Bot-PM2-Resurrect"
echo DONE
