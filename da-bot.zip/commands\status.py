import discord
from discord import Interaction, app_commands

from sheets import get_sheet_names, test_connection


@app_commands.command(name="da-status", description="Show bot and Google Sheets connection status")
async def command(interaction: Interaction):
    await interaction.response.defer()
    sheets_status = await test_connection()
    sheet_names = await get_sheet_names() if sheets_status["ok"] else []

    embed = discord.Embed(
        title="Bot Status",
        color=0x00AE86 if sheets_status["ok"] else 0xFF0000,
    )
    embed.add_field(name="Discord", value="Connected", inline=True)
    embed.add_field(
        name="Google Sheets",
        value=(
            f"Connected - {sheets_status['title']}"
            if sheets_status["ok"]
            else f"Error: {sheets_status['error']}"
        ),
        inline=True,
    )
    embed.add_field(
        name="Notifications",
        value="Always On",
        inline=True,
    )
    embed.add_field(
        name="Sheets/Tabs",
        value=", ".join(sheet_names) if sheet_names else "N/A",
        inline=False,
    )
    embed.timestamp = interaction.created_at
    return await interaction.edit_original_response(embeds=[embed])
