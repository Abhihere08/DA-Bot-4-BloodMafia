import logging
import os
from datetime import UTC, datetime

level = logging.DEBUG if os.getenv("DEBUG", "").lower() == "true" else logging.INFO


class _UTCFormatter(logging.Formatter):
    converter = datetime.fromtimestamp  # type: ignore[assignment]

    def formatTime(self, record, datefmt=None):
        dt = datetime.fromtimestamp(record.created, tz=UTC)
        return dt.strftime(datefmt or "%Y-%m-%dT%H:%M:%SZ")


_handler = logging.StreamHandler()
_handler.setFormatter(_UTCFormatter("[%(asctime)s] [%(levelname)s] %(message)s"))

logger = logging.getLogger("discord_sheets_bot")
logger.handlers = [_handler]
logger.setLevel(level)
logger.propagate = False
