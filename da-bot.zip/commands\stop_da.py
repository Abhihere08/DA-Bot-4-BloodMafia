import discord
from discord import Interaction, app_commands

from utils.da_scheduler import (
    _announcement_sent,
    _reg_scheduled,
    _reminder_sent,
    _scheduled,
    _pending_tasks,
    _save_announcement_sent,
    _save_reminder_sent,
    stop_da_scheduler,
)
from utils.scheduler import stop_polling


@app_commands.command(name="da-stop", description="Stop all DA announcements and scheduled reminders immediately")
async def command(interaction: Interaction):
    await interaction.response.defer()

    # Stop all pending scheduler tasks
    stop_da_scheduler()
    stop_polling()

    # Clear all in-memory tracking sets
    _reg_scheduled.clear()
    _scheduled.clear()
    _announcement_sent.clear()
    _reminder_sent.clear()

    # Cancel any pending asyncio tasks
    import asyncio
    for task in _pending_tasks:
        if isinstance(task, asyncio.Task) and not task.done():
            task.cancel()

    # Save cleared state
    _save_announcement_sent()
    _save_reminder_sent()

    embed = discord.Embed(
        title="DA Bot Paused",
        description="All DA announcements and reminders have been stopped.\n\nUse `/da-start` to resume.",
        color=0xFF9900,
    )
    embed.add_field(name="Cancelled", value="All pending announcement tasks", inline=False)
    embed.add_field(name="Status", value="Notifications disabled", inline=True)

    await interaction.edit_original_response(embeds=[embed])


@app_commands.command(name="da-start", description="Resume DA announcements and scheduler (restarts bot process)")
async def start_command(interaction: Interaction):
    await interaction.response.defer()

    # Re-enable notifications
    from utils.da_scheduler import start_da_scheduler
    from utils.scheduler import start_polling
    from config import POLL_INTERVAL_MS
    from sheets import get_row_count, get_rows

    async def _on_new_rows(new_rows):
        from config import ALL_NOTIFICATION_CHANNELS
        if not ALL_NOTIFICATION_CHANNELS:
            return
        for row in new_rows:
            for channel_id in ALL_NOTIFICATION_CHANNELS:
                channel = interaction.client.get_channel(channel_id)
                if channel:
                    try:
                        await channel.send(f"New Sheet Entry:\n{' | '.join(row)}")
                    except Exception:
                        pass

    # Start the schedulers again
    start_polling(POLL_INTERVAL_MS, _on_new_rows)
    start_da_scheduler(interaction.client)

    embed = discord.Embed(
        title="DA Bot Resumed",
        description="DA announcements and reminders have been re-enabled.",
        color=0x00AE86,
    )
    embed.add_field(name="Status", value="Notifications active", inline=True)

    await interaction.edit_original_response(embeds=[embed])
