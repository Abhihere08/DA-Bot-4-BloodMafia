from __future__ import annotations

from datetime import datetime

from discord import Interaction, app_commands

from utils.slot_utils import PST, get_slot_end_datetime, get_slot_start_datetime


def _format_slot_times(date_str: str | None = None) -> str:
    """Build a message showing all 8 DA slots in Discord auto-local timestamps.

    Times are anchored to the sheet date in PST (registration ends 22:00 PST;
    slot 1 starts 23:00 PST) and converted to Discord auto-local timestamps,
    so each viewer sees them in their own timezone.
    """
    if not date_str:
        now_pst = datetime.now(PST)
        date_str = f"{now_pst.month}.{now_pst.day}.{now_pst.year % 100:02d}"

    lines = ["**⏰ DA Slot Times (all times auto-local)**", ""]

    for slot_num in range(1, 9):
        start = get_slot_start_datetime(slot_num, date_str)
        if start is None:
            continue
        end = get_slot_end_datetime(slot_num, date_str)
        start_ts = int(start.timestamp())
        end_ts = int(end.timestamp()) if end else 0
        lines.append(
            f"Slot {slot_num}:  <t:{start_ts}:t> – <t:{end_ts}:t>"
        )

    lines.append("")
    lines.append("*Times shown in your local timezone automatically.*")

    return "\n".join(lines)


@app_commands.command(
    name="da-slot-times",
    description="Show all 8 DA slot times in local time for each viewer",
)
@app_commands.describe(
    date="Date for which to show slots (e.g. 10.02.26). Defaults to today."
)
async def command(interaction: Interaction, date: str | None = None):
    """Post all DA slot times using Discord auto-local timestamps."""
    try:
        msg = _format_slot_times(date)
        await interaction.response.send_message(content=msg[:2000])
    except Exception as err:
        await interaction.response.send_message(
            f"❌ Error: {err}", ephemeral=True
        )
