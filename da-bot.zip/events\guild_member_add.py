import discord

from utils.logger import logger

_warned_once = False


async def on_member_join(member: discord.Member):
    global _warned_once
    # Sheet writes require Google API auth which is not configured (CSV export
    # is read-only).  Log the event instead of calling append_row() which would
    # always raise NotImplementedError.
    logger.info("New member joined: %s (ID: %s)", member.name, member.id)
    if not _warned_once:
        logger.info(
            "Member-join sheet logging is disabled (read-only CSV mode). "
            "Configure Google API auth to enable write operations."
        )
        _warned_once = True
