from discord import Interaction, app_commands

from utils.discord_utils import unlink_member
from utils.logger import logger


@app_commands.command(name="da-unlink", description="Remove a saved game-name to Discord mapping")
@app_commands.describe(game_name="The game name to unlink (as written in the Google Sheet)")
async def command(interaction: Interaction, game_name: str):
    removed = unlink_member(game_name)
    if removed:
        logger.info("User %s unlinked '%s'", interaction.user, game_name)
        await interaction.response.send_message(
            f"Removed the link for **{game_name}** ✅"
        )
    else:
        await interaction.response.send_message(
            f"No mapping found for **{game_name}**", ephemeral=True
        )
