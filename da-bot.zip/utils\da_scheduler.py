"""Automatic DA announcement scheduler.

Polls the spreadsheet every 60 seconds for new sheet tabs (by date).
When a new upcoming DA sheet is detected, posts a new-DA registration
announcement and schedules a 30-minute pre-slot assignment reminder.
"""
import asyncio
import json
import os
from datetime import UTC, datetime, timedelta, timezone

# Slot/registration times are fixed in GMT-5 (no DST).
from config import ALL_NOTIFICATION_CHANNELS, DA_SHEET_PATTERNS
from sheets import get_range, get_sheet_names
from utils.logger import logger
from utils.slot_utils import get_sheet_date, get_slot_start_datetime, get_registration_end_datetime, get_registration_open_datetime


# Lock to prevent race conditions when multiple scheduler polls run concurrently
_announcement_lock = asyncio.Lock()

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_ANNOUNCED_FILE = os.path.join(_PROJECT_ROOT, "da_announced.json")

_POLL_INTERVAL_SECONDS = 60
_HOURS_BEFORE_SLOT = 0.5  # Reminder fires 30 min before slot start

_announced: set[str] = set()
_announcement_sent: set[str] = set()  # tracks "sheet_tab#slot_num" for new-DA announcements
_reminder_sent: set[str] = set()  # tracks "sheet_tab#slot_num" for assignment reminders
_pending_tasks: list = []
_scheduled: set[str] = set()
_reg_scheduled: set[str] = set()  # tracks pending registration announcement tasks
_sheet_slots: dict[str, int] = {}  # sheet_tab -> last seen slot_num (for detecting slot changes)
_SLOT_SLOTS_FILE = os.path.join(_PROJECT_ROOT, "da_sheet_slots.json")
_bot = None



def _load_sheet_slots() -> None:
    global _sheet_slots
    try:
        with open(_SLOT_SLOTS_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
            _sheet_slots = {k: int(v) for k, v in data.items()}
    except (FileNotFoundError, json.JSONDecodeError):
        _sheet_slots = {}


def _save_sheet_slots() -> None:
    try:
        with open(_SLOT_SLOTS_FILE, "w", encoding="utf-8") as fh:
            json.dump(_sheet_slots, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save sheet slots tracking: %s", err)


def _get_sheet_slot(sheet_tab: str) -> int | None:
    return _sheet_slots.get(sheet_tab)


def _set_sheet_slot(sheet_tab: str, slot_num: int) -> None:
    if _sheet_slots.get(sheet_tab) != slot_num:
        _sheet_slots[sheet_tab] = slot_num
        _save_sheet_slots()


def _load_announced() -> None:
    global _announced
    try:
        with open(_ANNOUNCED_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
            _announced = set(data.get("announced_sheets", []))
    except (FileNotFoundError, json.JSONDecodeError):
        _announced = set()


def _save_announced() -> None:
    try:
        with open(_ANNOUNCED_FILE, "w", encoding="utf-8") as fh:
            json.dump({"announced_sheets": list(_announced)}, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save announced sheets: %s", err)


_ANNOUNCEMENT_SENT_FILE = os.path.join(_PROJECT_ROOT, "da_announcement_sent.json")


def _load_announcement_sent() -> None:
    global _announcement_sent
    try:
        with open(_ANNOUNCEMENT_SENT_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
            _announcement_sent = set(data.get("announcement_sent_sheets", []))
    except (FileNotFoundError, json.JSONDecodeError):
        _announcement_sent = set()


def _save_announcement_sent() -> None:
    try:
        with open(_ANNOUNCEMENT_SENT_FILE, "w", encoding="utf-8") as fh:
            json.dump({"announcement_sent_sheets": list(_announcement_sent)}, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save announcement-sent sheets: %s", err)


_REMINDER_SENT_FILE = os.path.join(_PROJECT_ROOT, "da_reminder_sent.json")


def _load_reminder_sent() -> None:
    global _reminder_sent
    try:
        with open(_REMINDER_SENT_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
            _reminder_sent = set(data.get("reminder_sent_sheets", []))
    except (FileNotFoundError, json.JSONDecodeError):
        _reminder_sent = set()


def _save_reminder_sent() -> None:
    try:
        with open(_REMINDER_SENT_FILE, "w", encoding="utf-8") as fh:
            json.dump({"reminder_sent_sheets": list(_reminder_sent)}, fh, indent=2)
    except OSError as err:
        logger.error("Failed to save reminder-sent sheets: %s", err)


def _announcement_key(sheet_tab: str, slot_num: int) -> str:
    """Build a unique key for a sheet+slot pair so that slot changes re-trigger."""
    return f"{sheet_tab}#{slot_num}"


def _scheduled_key(sheet_tab: str, slot_num: int) -> str:
    """Build a unique key for a scheduled sheet+slot pair."""
    return f"{sheet_tab}#{slot_num}"


# Slot-start math is centralized in utils.slot_utils (GMT-5 anchored).  This
# module imports get_slot_start_datetime rather than keeping a stale local copy.


async def _send_new_da_announcement(sheet_tab: str) -> bool:
    """Send the new-DA registration announcement to all notification channels.

    Returns True if the announcement was delivered to at least one channel.
    """
    from commands.new_da import _build_da_message
    from utils.slot_utils import parse_slot_number

    if not _bot:
        return False
    if not ALL_NOTIFICATION_CHANNELS:
        return False

    try:
        rows = await get_range(f"'{sheet_tab}'")
        if not rows:
            return False

        from commands.send_da_assignments import parse_da_sheet
        parsed = parse_da_sheet(rows)
        if not parsed:
            return False

        title = parsed["title"]
        slot_num = parse_slot_number(title)
        date_str = get_sheet_date(title, sheet_tab)

        if not slot_num:
            logger.warning("Cannot detect slot number for new-DA announcement")
            return False

        message = _build_da_message(sheet_tab, title, slot_num, date_str)
        msg = message[:2000]

        success = False
        for channel_id in ALL_NOTIFICATION_CHANNELS:
            channel = _bot.get_channel(channel_id)
            if channel:
                try:
                    await channel.send(content=msg)
                    logger.info("New-DA announcement sent to channel %d for sheet '%s'", channel_id, sheet_tab)
                    success = True
                except Exception as err:
                    logger.error("Failed to send new-DA announcement to channel %d: %s", channel_id, err)

        return success

    except Exception as err:
        logger.error("Failed to send new-DA announcement: %s", err)
        return False


async def _send_da_announcement(sheet_tab: str) -> bool:
    """Send the DA assignment reminder to all notification channels.

    Returns True if the reminder was delivered to at least one channel.
    """
    from commands.send_da_assignments import _build_section_text, _split_messages, parse_da_sheet
    from utils.slot_utils import format_slot_time_with_tz, parse_slot_number

    if not _bot:
        logger.error("Bot not available for announcement")
        return False

    if not ALL_NOTIFICATION_CHANNELS:
        logger.warning("No notification channels configured; skipping DA announcement")
        return False

    try:
        rows = await get_range(f"'{sheet_tab}'")
        if not rows:
            return False

        parsed = parse_da_sheet(rows)
        if not parsed:
            return False

        slot_num = parse_slot_number(parsed["title"])
        slot_date = get_sheet_date(parsed["title"], sheet_tab)
        slot_time_str = (
            format_slot_time_with_tz(slot_num, slot_date) if slot_num else "Unknown"
        )
        slot_start = get_slot_start_datetime(slot_num, slot_date) if slot_num else None

        # Determine guild-specific tag based on sheet type
        from commands.new_da import BIG_BM_TAG, LITTLE_BM_TAG, _detect_sheet_type
        sheet_type = _detect_sheet_type(sheet_tab)
        guild_tag = BIG_BM_TAG if sheet_type == "big" else LITTLE_BM_TAG

        # Build sections structure once (shared across channels)
        sections: list[tuple[str, list]] = []
        if parsed["caravanChasers"]:
            sections.append(("🚛  CARAVAN CHASERS & TRANSPORTER HOLDERS", parsed["caravanChasers"]))
        if parsed["topHalf"]:
            sections.append(("🏔️  TEAM A — TOP HALF OF MAP", parsed["topHalf"]))
        if parsed["bottomHalf"]:
            sections.append(("🌊  TEAM A — BOTTOM HALF OF MAP", parsed["bottomHalf"]))

        success = False
        for channel_id in ALL_NOTIFICATION_CHANNELS:
            channel = _bot.get_channel(channel_id)
            if not channel:
                logger.warning("Notification channel not found: %d", channel_id)
                continue

            guild = channel.guild

            lines: list[str] = []
            lines.append(f"**⏰ DA REMINDER — {parsed['title']}**")
            lines.append(f"📋 Sheet: `{sheet_tab}` • **{slot_time_str}**")
            lines.append("")
            if slot_start:
                slot_ts = int(slot_start.timestamp())
                lines.append(f"{guild_tag} — **🎯 DA starts in <t:{slot_ts}:R>** — check your assignments:")
            else:
                lines.append(f"{guild_tag} — DA starts soon! Check your assignments:")
            lines.append("")

            for sec_title, assignments in sections:
                lines.append(_build_section_text(sec_title, assignments, guild))
                lines.append("")

            messages = _split_messages(lines)
            delivered = True
            for msg in messages:
                try:
                    await channel.send(content=msg[:2000])
                except Exception as err:
                    logger.error("Failed to send DA announcement to channel %d: %s", channel_id, err)
                    delivered = False
            if delivered:
                success = True

            logger.info("DA announcement sent to channel %d (guild %d) for sheet '%s'",
                        channel_id, guild.id if guild else 0, sheet_tab)

        return success

    except Exception as err:
        logger.error("Failed to send DA announcement: %s", err)
        return False


async def _schedule_announcement(sheet_tab: str, slot_num: int, date_str: str | None) -> None:
    """Schedule the DA assignment reminder to fire 30 minutes before the slot starts."""
    sched_key = _scheduled_key(sheet_tab, slot_num)
    if sched_key in _reminder_sent:
        logger.debug("Reminder already sent for '%s' (slot %d); not re-scheduling", sheet_tab, slot_num)
        return
    if sched_key in _scheduled:
        logger.debug("Announcement already pending for '%s' (slot %d); not re-scheduling", sheet_tab, slot_num)
        return
    slot_start = get_slot_start_datetime(slot_num, date_str)
    if not slot_start:
        logger.warning("Could not determine slot start time for %s", sheet_tab)
        return

    announce_time = slot_start - timedelta(hours=_HOURS_BEFORE_SLOT)
    now = datetime.now(UTC)

    delay = (announce_time - now).total_seconds()

    if delay <= 0:
        # Slot is within the reminder window — announce immediately
        # Mark as sent BEFORE sending to prevent duplicates from concurrent polls
        _reminder_sent.add(sched_key)
        _scheduled.add(sched_key)
        _save_reminder_sent()
        logger.info(
            "Sheet '%s' is within %.1fh of slot; sending DA assignment reminder now",
            sheet_tab, _HOURS_BEFORE_SLOT,
        )
        sent = await _send_da_announcement(sheet_tab)
        if not sent:
            # Remove from sent set if sending failed, so it can retry next poll
            _reminder_sent.discard(sched_key)
            _save_reminder_sent()
    else:
        # Schedule the announcement
        logger.info(
            "Scheduling DA announcement for '%s' in %d seconds (at %s)",
            sheet_tab, delay, announce_time.strftime("%Y-%m-%d %H:%M UTC"),
        )

        async def _delayed_announce():
            try:
                await asyncio.sleep(delay)
                # Re-check after waking — another path may have already sent
                if sched_key in _reminder_sent:
                    logger.debug("DA announcement already sent for '%s' (slot %d) by another path; skipping", sheet_tab, slot_num)
                    return
                # Mark as sent BEFORE sending to prevent duplicates
                _reminder_sent.add(sched_key)
                _save_reminder_sent()
                sent = await _send_da_announcement(sheet_tab)
                if not sent:
                    _reminder_sent.discard(sched_key)
                    _save_reminder_sent()
            finally:
                _scheduled.discard(sched_key)

        task = asyncio.create_task(_delayed_announce())
        _pending_tasks.append(task)
        _scheduled.add(sched_key)


async def _schedule_registration_announcement(sheet_tab: str, slot_num: int, date_str: str | None, old_slot_num: int | None = None) -> None:
    """Schedule the new-DA registration announcement to fire when registration opens.

    Registration opens 24 hours before registration ends (at REGISTRATION_END_HOUR GMT-5
    on the sheet date; midnight GMT-5 = 00:00).  The new-DA announcement fires when:
    - A new sheet is detected and we're within the registration window
    - The slot number changes on an existing sheet (fires immediately)
    """
    async with _announcement_lock:
        now = datetime.now(UTC)

        # Handle slot change: clear old announcement and send new one immediately
        if old_slot_num is not None and old_slot_num != slot_num:
            old_ann_key = _announcement_key(sheet_tab, old_slot_num)
            if old_ann_key in _announcement_sent:
                logger.info(
                    "Slot changed for '%s' (%d -> %d); sending new DA announcement",
                    sheet_tab, old_slot_num, slot_num,
                )
                _announcement_sent.discard(old_ann_key)
                _save_announcement_sent()
            # Cancel any pending scheduled task for the old slot
            _reg_scheduled.discard(old_ann_key)

        ann_key = _announcement_key(sheet_tab, slot_num)
        if ann_key in _announcement_sent:
            logger.debug("New-DA announcement already sent for '%s' (slot %d); skipping", sheet_tab, slot_num)
            return

        # Guard: don't create duplicate delayed tasks for the same sheet+slot
        if ann_key in _reg_scheduled:
            logger.debug("Registration announcement already pending for '%s' (slot %d); not re-scheduling", sheet_tab, slot_num)
            return

        reg_open_time = get_registration_open_datetime(date_str)
        reg_end_time = get_registration_end_datetime(date_str)

        if reg_open_time and reg_end_time:
            if now >= reg_open_time:
                # Registration window is open — send new-DA announcement now
                # Mark as sent BEFORE sending to prevent duplicates from concurrent scheduler polls
                _announcement_sent.add(ann_key)
                _save_announcement_sent()
                logger.info(
                    "Sheet '%s' (slot %d) registration window is open; sending new-DA announcement now",
                    sheet_tab, slot_num,
                )
                sent = await _send_new_da_announcement(sheet_tab)
                if not sent:
                    # Remove from sent set if sending failed, so it can retry next poll
                    _announcement_sent.discard(ann_key)
                    _save_announcement_sent()
            else:
                # Schedule the new-DA announcement to fire when registration opens
                delay = (reg_open_time - now).total_seconds()
                logger.info(
                    "Scheduling new-DA announcement for '%s' (slot %d) in %d seconds (registration opens %s)",
                    sheet_tab, slot_num, delay, reg_open_time.strftime("%Y-%m-%d %H:%M UTC"),
                )

                _reg_scheduled.add(ann_key)

                async def _delayed_registration_announce():
                    try:
                        await asyncio.sleep(delay)
                        # Re-check after waking — another path may have already sent
                        if ann_key in _announcement_sent:
                            logger.debug("New-DA announcement already sent for '%s' (slot %d) by another path; skipping", sheet_tab, slot_num)
                            return
                        sent = await _send_new_da_announcement(sheet_tab)
                        if sent:
                            _announcement_sent.add(ann_key)
                            _save_announcement_sent()
                    except Exception as err:
                        logger.error("Failed to send delayed new-DA announcement for '%s': %s", sheet_tab, err)
                    finally:
                        _reg_scheduled.discard(ann_key)

                task = asyncio.create_task(_delayed_registration_announce())
                _pending_tasks.append(task)
        else:
            logger.warning("Could not determine registration times for %s", sheet_tab)



async def run_scheduler_check() -> dict:
    """Run one full scheduler check cycle. Returns a summary dict.

    Used by both the poll loop and the manual ``/da-check`` command.
    """
    from utils.slot_utils import _is_sheet_upcoming, parse_slot_number

    result = {"checked": 0, "announced": [], "scheduled": [], "rescheduled": [], "skipped": [], "error": None}

    try:
        sheet_names = await get_sheet_names()
        da_sheets = []
        for name in sheet_names:
            low = name.lower()
            for pattern in DA_SHEET_PATTERNS:
                if pattern.lower() in low:
                    da_sheets.append(name)
                    break

        result["checked"] = len(da_sheets)

        for sheet_name in da_sheets:
            if not _is_sheet_upcoming(sheet_name):
                logger.info("Skipping past sheet (date filter): %s", sheet_name)
                result["skipped"].append(sheet_name)
                continue

            rows = await get_range(f"'{sheet_name}'")
            if not rows:
                continue

            title_row = rows[0][0] if rows and rows[0] else ""
            slot_num = parse_slot_number(title_row)
            date_str = get_sheet_date(title_row, sheet_name)

            if not slot_num:
                continue

            # Check if this is a future slot
            slot_start = get_slot_start_datetime(slot_num, date_str)
            if not slot_start:
                continue

            now = datetime.now(UTC)
            if slot_start > now:
                # Upcoming slot — check if announcement is needed (new or slot-changed)
                old_slot_num = _get_sheet_slot(sheet_name)
                slot_changed = old_slot_num is not None and old_slot_num != slot_num
                _set_sheet_slot(sheet_name, slot_num)

                # Send new-DA announcement if needed (new sheet or slot changed)
                await _schedule_registration_announcement(sheet_name, slot_num, date_str, old_slot_num)
                if slot_changed or old_slot_num is None:
                    result["announced"].append(sheet_name)
                # Always (re)schedule the assignment reminder
                await _schedule_announcement(sheet_name, slot_num, date_str)
            else:
                # Past slot — mark as seen so we don't keep re-fetching it
                if sheet_name not in _announced:
                    _announced.add(sheet_name)
                    _save_announced()
                result["skipped"].append(sheet_name)

    except Exception as err:
        logger.error("DA scheduler check error: %s", err)
        result["error"] = str(err)

    return result


async def _da_poll_loop() -> None:
    """Main polling loop — checks for new sheets every 60 seconds."""

    while True:
        await asyncio.sleep(_POLL_INTERVAL_SECONDS)
        result = await run_scheduler_check()
        if result["announced"]:
            logger.info("Scheduled check found %d new DA sheet(s): %s",
                        len(result["announced"]), result["announced"])
        if result["error"]:
            logger.error("DA scheduler poll error: %s", result["error"])


async def _bootstrap_da_scheduler(bot) -> None:
    """Bootstrap the DA scheduler with the bot instance."""
    global _bot
    _bot = bot
    _load_announced()
    _load_announcement_sent()
    _load_sheet_slots()
    _load_reminder_sent()
    logger.info("DA scheduler started - polling every %ds", _POLL_INTERVAL_SECONDS)
    await _da_poll_loop()


def start_da_scheduler(bot) -> None:
    """Start the DA announcement scheduler as a background task."""
    task = asyncio.create_task(_bootstrap_da_scheduler(bot))
    _pending_tasks.append(task)
    logger.info("DA scheduler initialized (30min pre-slot announcements)")


def stop_da_scheduler() -> None:
    """Cancel all pending DA scheduler tasks."""
    for task in _pending_tasks:
        task.cancel()
    _pending_tasks.clear()
    _scheduled.clear()
    _reg_scheduled.clear()
    logger.info("DA scheduler stopped")
