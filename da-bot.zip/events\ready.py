from utils.logger import logger


def on_ready(bot):
    logger.info("Logged in as %s", bot.user)
    logger.info("Serving %d guild(s)", len(bot.guilds))
